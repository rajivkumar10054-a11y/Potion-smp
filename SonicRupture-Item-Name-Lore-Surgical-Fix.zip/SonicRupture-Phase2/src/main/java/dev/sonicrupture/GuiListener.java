package dev.sonicrupture;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class GuiListener implements Listener {

    private final SonicRupturePlugin plugin;

    public GuiListener(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof SonicGui)) return;
        e.setCancelled(true); // blocks shift-click, hotbar swap, double-click collect, etc.

        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (e.getSlot() != SonicGui.SWORD_SLOT) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (!p.getInventory().addItem(plugin.items().create()).isEmpty()) {
            p.sendMessage(plugin.cfg().inventoryFullMessage());
            return;
        }
        p.sendMessage(plugin.cfg().receivedMessage());
        p.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof SonicGui) {
            e.setCancelled(true);
        }
    }
}
