package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

public final class SonicCommand implements TabExecutor {

    private final SonicRupturePlugin plugin;

    public SonicCommand(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("gui")) {
            new SonicGui().open(p);
            return true;
        }
        p.sendMessage(Component.text("Usage: /sonic gui", NamedTextColor.RED));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1 && "gui".startsWith(args[0].toLowerCase())) return List.of("gui");
        return List.of();
    }
}
