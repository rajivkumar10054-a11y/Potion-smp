package dev.sonicrupture;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.ArmorStand;
import org.bukkit.GameMode;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Owns Sonic Boom charge/cooldown state and the independent Inferno Burst state.
 * Gameplay mechanics remain separate from the Phase 2 presentation layer.
 */
public final class AbilityManager {

    public enum State { IDLE, CHARGING }

    private static final class Data {
        State state = State.CHARGING;
        BukkitTask chargeTask;

        void cancelTasks() {
            if (chargeTask != null) chargeTask.cancel();
            chargeTask = null;
        }
    }

    private final SonicRupturePlugin plugin;
    private final Map<UUID, Data> charging = new HashMap<>();
    private final Map<UUID, Long> sonicCooldowns = new HashMap<>();
    private final Map<UUID, Long> infernoCooldowns = new HashMap<>();
    private final Map<UUID, BukkitTask> infernoTasks = new HashMap<>();

    public AbilityManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public State stateOf(UUID id) {
        Data d = charging.get(id);
        return d == null ? State.IDLE : d.state;
    }

    public void tryStartCharge(Player p) {
        UUID id = p.getUniqueId();
        if (charging.containsKey(id)) return;

        long now = System.currentTimeMillis();
        Long end = sonicCooldowns.get(id);
        if (end != null) {
            if (end <= now) {
                sonicCooldowns.remove(id);
            } else {
                double left = (end - now) / 1000.0;
                p.sendActionBar(plugin.cfg().cooldownMessage(String.format(Locale.ROOT, "%.1f", left)));
                return;
            }
        }

        Data d = new Data();
        charging.put(id, d);
        int total = plugin.cfg().chargeTicks();
        plugin.fx().onChargeStart(p);

        d.chargeTask = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                elapsed++;
                tickCharge(id, d, elapsed, total);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void tickCharge(UUID id, Data d, int elapsed, int total) {
        Player p = Bukkit.getPlayer(id);
        if (p == null || !p.isOnline() || p.isDead()
                || !plugin.items().isSonic(p.getInventory().getItemInMainHand())) {
            cancelCharge(id, p);
            return;
        }
        plugin.fx().onChargeTick(p, elapsed, total);
        if (elapsed >= total) release(id, d, p);
    }

    private void cancelCharge(UUID id, Player p) {
        Data d = charging.remove(id);
        if (d == null) return;
        d.cancelTasks();
        if (p != null) plugin.fx().onChargeCancel(p);
    }

    private void release(UUID id, Data d, Player p) {
        if (d.chargeTask != null) d.chargeTask.cancel();
        d.chargeTask = null;
        charging.remove(id, d);

        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        plugin.fx().onRelease(p, eye, dir);
        plugin.projectiles().launch(p, eye, dir);

        int cd = plugin.cfg().sonicCooldownTicks();
        if (cd > 0) sonicCooldowns.put(id, System.currentTimeMillis() + cd * 50L);
    }

    /** SHIFT + LEFT CLICK: independent from Sonic Boom charge/cooldown. */
    public void tryInfernoBurst(Player p) {
        UUID id = p.getUniqueId();
        if (!plugin.items().isSonic(p.getInventory().getItemInMainHand()) || !p.isSneaking()) return;

        BukkitTask existingTask = infernoTasks.get(id);
        if (existingTask != null && !existingTask.isCancelled()) return;

        long now = System.currentTimeMillis();
        Long end = infernoCooldowns.get(id);
        if (end != null) {
            if (end <= now) {
                infernoCooldowns.remove(id);
            } else {
                p.sendActionBar(plugin.cfg().infernoCooldownMessage(String.format(Locale.ROOT, "%.1f", (end - now) / 1000.0)));
                return;
            }
        }

        int cooldown = plugin.cfg().infernoCooldownTicks();
        if (cooldown > 0) infernoCooldowns.put(id, now + cooldown * 50L);

        p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
                plugin.cfg().infernoFireResistanceTicks(), 0, false, false, true));

        final double maxRadius = plugin.cfg().infernoRange();
        final double step = plugin.cfg().infernoExpansionPerTick();
        BukkitTask task = new BukkitRunnable() {
            double radius = 0.0;
            final Set<UUID> hitEntities = new HashSet<>();

            @Override
            public void run() {
                Player caster = Bukkit.getPlayer(id);
                if (caster == null || !caster.isOnline() || caster.isDead()
                        || !plugin.items().isSonic(caster.getInventory().getItemInMainHand())) {
                    cancelInferno(id);
                    return;
                }

                radius = Math.min(maxRadius, radius + step);
                renderInferno(caster, radius);
                damageInferno(caster, radius, hitEntities);

                if (radius >= maxRadius - 1.0E-6) cancelInferno(id);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        infernoTasks.put(id, task);

        if (plugin.cfg().sounds()) {
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_FIRECHARGE_USE,
                    SoundCategory.PLAYERS, plugin.cfg().infernoSoundVolume(), plugin.cfg().infernoSoundPitch());
        }
    }

    private void renderInferno(Player p, double radius) {
        Location center = p.getLocation().clone().add(0, 0.15, 0);
        int points = Math.max(24, (int) Math.ceil(radius * 10.0));
        for (int i = 0; i < points; i++) {
            double angle = (Math.PI * 2.0 * i) / points;
            double x = Math.cos(angle) * radius;
            double z = Math.sin(angle) * radius;
            Location at = center.clone().add(x, 0, z);
            p.getWorld().spawnParticle(Particle.FLAME, at, 1, 0.04, 0.05, 0.04, 0.005);
            if (i % 4 == 0) p.getWorld().spawnParticle(Particle.LAVA, at, 1, 0, 0, 0, 0);
            if (i % 5 == 0) p.getWorld().spawnParticle(Particle.SMOKE, at, 1, 0.03, 0.03, 0.03, 0.01);
        }
    }

    private void damageInferno(Player caster, double radius, Set<UUID> hitEntities) {
        double inner = Math.max(0.0, radius - Math.max(0.75, plugin.cfg().infernoRingThickness()));
        double outer = radius + 0.9;
        double innerSq = inner * inner;
        double outerSq = outer * outer;

        for (Entity entity : caster.getWorld().getNearbyEntities(caster.getLocation(), outer, outer, outer)) {
            if (!(entity instanceof LivingEntity target)) continue;
            if (!isValidInfernoTarget(entity, caster)) continue;
            Vector delta = target.getLocation().toVector().subtract(caster.getLocation().toVector());
            double horizontalSq = delta.getX() * delta.getX() + delta.getZ() * delta.getZ();
            if (horizontalSq < innerSq || horizontalSq > outerSq) continue;
            if (!hitEntities.add(target.getUniqueId())) continue;

            target.damage(plugin.cfg().infernoDamage(), caster);
            Vector kb = delta.setY(0);
            if (kb.lengthSquared() > 1.0E-6) kb.normalize().multiply(plugin.cfg().infernoKnockbackHorizontal());
            kb.setY(plugin.cfg().infernoKnockbackVertical());
            target.setVelocity(target.getVelocity().add(kb));
        }
    }

    private boolean isValidInfernoTarget(Entity entity, Player caster) {
        if (!(entity instanceof LivingEntity living)) return false;
        if (entity.getUniqueId().equals(caster.getUniqueId())) return false;
        if (!living.isValid() || living.isDead() || living.isInvulnerable()) return false;
        if (entity instanceof ArmorStand) return false;
        if (entity instanceof Player player) {
            GameMode mode = player.getGameMode();
            if (mode == GameMode.SPECTATOR || mode == GameMode.CREATIVE) return false;
        }
        return true;
    }

    private void cancelInferno(UUID id) {
        BukkitTask task = infernoTasks.remove(id);
        if (task != null) task.cancel();
    }

    public void reset(Player p) {
        UUID id = p.getUniqueId();
        Data d = charging.remove(id);
        if (d != null) {
            d.cancelTasks();
            plugin.fx().onChargeCancel(p);
        }
        cancelInferno(id);
        sonicCooldowns.remove(id);
        infernoCooldowns.remove(id);
    }

    public void resetAll() {
        for (Data d : charging.values()) d.cancelTasks();
        for (BukkitTask task : infernoTasks.values()) task.cancel();
        charging.clear();
        sonicCooldowns.clear();
        infernoCooldowns.clear();
        infernoTasks.clear();
    }
}
