package dev.sonicrupture;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderDragon;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;

public final class ProjectileManager {

    private final SonicRupturePlugin plugin;
    private final List<SonicBolt> bolts = new ArrayList<>();
    private BukkitTask task; // runs only while at least one bolt is alive

    public ProjectileManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public void launch(Player shooter, Location origin, Vector direction) {
        bolts.add(new SonicBolt(shooter.getUniqueId(), origin.getWorld(), origin.toVector(), direction));
        if (task == null) {
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        }
    }

    /** Marks the shooter's bolts CANCELLED; the tick loop removes them. */
    public void cancelFor(UUID shooterId) {
        for (SonicBolt b : bolts) {
            if (b.state() == SonicBolt.State.TRAVELLING && b.shooterId().equals(shooterId)) {
                b.setState(SonicBolt.State.CANCELLED);
                plugin.fx().onCancel(b, b.position().toLocation(b.world()));
            }
        }
    }

    public void shutdown() {
        for (SonicBolt b : bolts) {
            if (b.state() == SonicBolt.State.TRAVELLING) {
                b.setState(SonicBolt.State.CANCELLED);
                plugin.fx().onCancel(b, b.position().toLocation(b.world()));
            }
        }
        bolts.clear();
        stopTask();
    }

    private void stopTask() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        Iterator<SonicBolt> it = bolts.iterator();
        while (it.hasNext()) {
            SonicBolt b = it.next();
            if (b.state() == SonicBolt.State.TRAVELLING) step(b);
            if (b.state() != SonicBolt.State.TRAVELLING) it.remove();
        }
        if (bolts.isEmpty()) stopTask();
    }

    private void step(SonicBolt b) {
        ConfigManager cfg = plugin.cfg();
        Player shooter = Bukkit.getPlayer(b.shooterId());
        if (shooter == null || !shooter.isOnline()) {
            b.setState(SonicBolt.State.CANCELLED);
            plugin.fx().onCancel(b, b.position().toLocation(b.world()));
            return;
        }

        Location start = b.position().toLocation(b.world());
        if (!b.world().isChunkLoaded(start.getBlockX() >> 4, start.getBlockZ() >> 4)) {
            b.setState(SonicBolt.State.CANCELLED);
            plugin.fx().onCancel(b, start);
            return;
        }

        double dist = Math.min(cfg.speed(), cfg.maxRange() - b.travelled());
        if (dist <= 0) {
            expire(b, start);
            return;
        }

        b.tickAge();
        Predicate<Entity> filter = e -> isValidTarget(e, shooter);
        RayTraceResult r = cfg.stopOnBlocks()
                ? b.world().rayTrace(start, b.direction(), dist, FluidCollisionMode.NEVER, true, cfg.hitbox(), filter)
                : b.world().rayTraceEntities(start, b.direction(), dist, cfg.hitbox(), filter);

        if (r != null) {
            Location hitLoc = r.getHitPosition().toLocation(b.world());
            if (r.getHitEntity() instanceof LivingEntity target) {
                hit(b, shooter, target, hitLoc);
            } else {
                expire(b, hitLoc); // solid block
            }
            return;
        }

        b.advance(dist);
        Location now = b.position().toLocation(b.world());
        plugin.fx().onProjectileTick(b, now);
        if (b.travelled() >= cfg.maxRange() - 1.0E-6 || b.age() >= cfg.lifetimeTicks()) {
            expire(b, now);
        }
    }

    private boolean isValidTarget(Entity e, Player shooter) {
        if (!(e instanceof LivingEntity le)) return false;
        if (e.getUniqueId().equals(shooter.getUniqueId())) return false;
        if (!le.isValid() || le.isDead() || le.isInvulnerable()) return false;
        if (e instanceof ArmorStand) return false;
        if (e instanceof Player p) {
            GameMode gm = p.getGameMode();
            if (gm == GameMode.SPECTATOR || gm == GameMode.CREATIVE) return false;
        }
        return true;
    }

    private void hit(SonicBolt b, Player shooter, LivingEntity target, Location hitLoc) {
        ConfigManager cfg = plugin.cfg();
        b.setState(SonicBolt.State.HIT); // set first: no second hit, no duplicate damage

        double before = target.getHealth() + target.getAbsorptionAmount();
        target.damage(cfg.damage(), shooter);
        if (target.isValid() && !target.isDead()) {
            // Sonic Boom is the lethal damage path. Keep this here rather than
            // in the generic melee listener so normal sword hits stay normal.
            target.setHealth(0.0);
        }
        boolean damaged = target.isDead() || target.getHealth() + target.getAbsorptionAmount() < before;

        if (damaged) {
            Vector kb = b.direction().clone().setY(0);
            if (kb.lengthSquared() > 1.0E-6) kb.normalize().multiply(cfg.kbHorizontal());
            kb.setY(cfg.kbVertical());
            target.setVelocity(target.getVelocity().add(kb));
        }
        plugin.fx().onHit(b, target, hitLoc);
    }

    private void expire(SonicBolt b, Location at) {
        b.setState(SonicBolt.State.EXPIRED);
        plugin.fx().onExpire(b, at);
    }
}
