package dev.sonicrupture;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Presentation layer. Gameplay owns all mechanics; this interface only receives
 * lifecycle callbacks so visual effects can be implemented independently.
 */
public interface SonicFx {
    default void onChargeStart(Player player) {}
    default void onChargeTick(Player player, int elapsed, int total) {}
    default void onChargeCancel(Player player) {}
    default void onRelease(Player player, Location origin, Vector direction) {}
    default void onProjectileTick(SonicBolt bolt, Location position) {}
    default void onHit(SonicBolt bolt, LivingEntity target, Location position) {}
    default void onExpire(SonicBolt bolt, Location position) {}
    default void onCancel(SonicBolt bolt, Location position) {}
}
