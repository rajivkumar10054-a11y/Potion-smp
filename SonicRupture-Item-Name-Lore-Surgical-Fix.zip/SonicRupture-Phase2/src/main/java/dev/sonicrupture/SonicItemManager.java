package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import java.util.List;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class SonicItemManager {

    public static final String ITEM_ID = "sonic_rupture";
    public static final int CUSTOM_MODEL_DATA = 1001;

    private final NamespacedKey key;

    public SonicItemManager(SonicRupturePlugin plugin) {
        this.key = new NamespacedKey(plugin, "item_id");
    }

    public ItemStack create() {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("SONIC RUPTURE", NamedTextColor.DARK_AQUA)
                .decorate(TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Warden-forged sonic weapon", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("⚡ SONIC BOOM", NamedTextColor.AQUA)
                        .decorate(TextDecoration.BOLD)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Right Click to activate", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Unleash a devastating sonic strike", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("🔥 INFERNO BURST", NamedTextColor.DARK_AQUA)
                        .decorate(TextDecoration.BOLD)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + Right Click to activate", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Release a 360° infernal shockwave", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("◆ The silence breaks. ◆", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        meta.setCustomModelData(CUSTOM_MODEL_DATA);
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ITEM_ID);
        item.setItemMeta(meta);
        return item;
    }

    /** Identified by PDC only, never by display name. */
    public boolean isSonic(ItemStack item) {
        if (item == null || item.getType() != Material.NETHERITE_SWORD || !item.hasItemMeta()) return false;
        return ITEM_ID.equals(item.getItemMeta().getPersistentDataContainer()
                .get(key, PersistentDataType.STRING));
    }
}
