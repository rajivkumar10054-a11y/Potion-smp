package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;

public class CombatListener implements Listener {

    private final PotionSMP plugin;

    public CombatListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent event) {
        // --- Shield: block all damage to shielded players ---
        if (event.getEntity() instanceof Player defender) {
            if (plugin.getShieldManager().isShielded(defender.getUniqueId())) {
                event.setCancelled(true);
                plugin.getShieldManager().spawnHitEffect(defender);
                return;
            }
        }

        if (event.isCancelled()) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        // Frozen players cannot deal outgoing damage or trigger offensive
        // PotionSMP onHit mechanics while the existing Freeze state is active.
        if (plugin.getFrozenPlayerManager().isFrozen(attacker.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        if (!(event.getEntity() instanceof LivingEntity target)) return;

        // PotionSMP-generated damage must still deal normal damage, but it must
        // not re-enter PotionSMP's offensive onHit mechanics.
        if (ProgrammaticDamageGuard.isSuppressed(attacker.getUniqueId())) {
            return;
        }

        // --- Glitch: deploy corruption on next hit if armed ---
        if (plugin.getGlitchManager().isArmed(attacker.getUniqueId())) {
            if (target instanceof Player targetPlayer) {
                plugin.getGlitchManager().deployOnHit(attacker, targetPlayer);
            }
        }

        // --- Block item pickup for corrupted players ---
        // (handled separately via PlayerPickupItemEvent)

        // --- Normal ability onHit dispatch ---
        PotionType slot1 = plugin.getSlotManager().getSlot1(attacker.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(attacker.getUniqueId());

        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG): log-only, dispatch below is unchanged.
        {
            boolean s1Regen = slot1 == PotionType.REGEN;
            boolean s2Regen = slot2 == PotionType.REGEN;
            // Mirrors the dispatch conditions below exactly: slot1 always dispatches
            // when non-null; slot2 dispatches when non-null and different from slot1.
            boolean regenDispatched = s1Regen || (s2Regen && slot2 != slot1);
            plugin.getLogger().info("[REGEN-DIAG][CombatListener] normal onHit dispatch reached: "
                    + "attacker=" + attacker.getName()
                    + ", target=" + target.getName()
                    + ", targetClass=" + target.getClass().getName()
                    + ", attackerOnGround=" + attacker.isOnGround()
                    + ", attackerFallDistance=" + attacker.getFallDistance()
                    + ", slot1IsRegen=" + s1Regen
                    + ", slot2IsRegen=" + s2Regen
                    + ", regenOnHitDispatched=" + regenDispatched);
        }

        if (slot1 != null) {
            Ability ability = plugin.getAbilityRegistry().get(slot1);
            if (ability != null) ability.onHit(plugin, attacker, target);
        }
        if (slot2 != null && slot2 != slot1) {
            Ability ability = plugin.getAbilityRegistry().get(slot2);
            if (ability != null) ability.onHit(plugin, attacker, target);
        }
    }

    // Block knockback on shielded players
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getShieldManager().isShielded(player.getUniqueId())) {
            event.setCancelled(true);
            plugin.getShieldManager().spawnHitEffect(player);
        }
    }

    // Block item pickup for glitch-corrupted players
    @EventHandler(priority = EventPriority.HIGH)
    public void onItemPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (plugin.getGlitchManager().hasNoPickup(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}
