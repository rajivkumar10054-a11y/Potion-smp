package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.gui.PotionGUIHolder;
import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public class GUIListener implements Listener {

    private final PotionSMP plugin;

    public GUIListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof PotionGUIHolder)) return;

        // Cancel EVERY click while the GUI is open (top and bottom inventory, all click
        // types: shift-click, number-key, offhand swap, double-click collect, drop...).
        event.setCancelled(true);

        // Reward/button logic runs ONLY for a click on the GUI's own (top) inventory.
        // A click in the player's bottom inventory (clickedInventory != top) must never
        // award anything, otherwise clicking an owned potion duplicates it.
        Inventory top = event.getView().getTopInventory();
        Inventory clicked = event.getClickedInventory();
        if (clicked == null || clicked != top) return;

        // Plain button presses only; ignore number-key, offhand swap, double-click, drop, etc.
        ClickType type = event.getClick();
        if (type != ClickType.LEFT && type != ClickType.RIGHT
                && type != ClickType.SHIFT_LEFT && type != ClickType.SHIFT_RIGHT) return;

        if (event.getCurrentItem() == null) return;

        PotionType potionType = PotionUtils.getPotionType(event.getCurrentItem());
        if (potionType == null) return;

        player.closeInventory();
        player.getInventory().addItem(ItemBuilder.buildPotion(potionType));

        player.sendMessage(PotionUtils.colorize("&a✦ You received a ") + potionType.getDisplayName() + PotionUtils.colorize("&a!"));
        player.sendMessage(PotionUtils.colorize("&7Drink it to equip it to Slot 1."));
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof PotionGUIHolder)) return;
        // Cancel any drag that touches a GUI slot (raw slots below top size belong to the GUI).
        for (int raw : event.getRawSlots()) {
            if (raw < top.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
