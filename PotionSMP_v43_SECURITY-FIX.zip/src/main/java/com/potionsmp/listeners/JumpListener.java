package com.potionsmp.listeners;

import org.bukkit.event.Listener;

/**
 * Retained as an empty listener for compatibility. Vitality Surge no longer
 * uses jump input or movement for activation.
 */
public class JumpListener implements Listener {
}
