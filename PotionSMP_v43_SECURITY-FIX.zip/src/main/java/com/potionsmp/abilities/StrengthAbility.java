package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * §4 Strength Potion – Titan Warrior
 *
 * PASSIVE:
 * - 2× damage to hostile mobs
 * - Bonus damage at low HP:
 *   <6 hearts → +1dmg, <4 → +2dmg, <2 → +3dmg
 *
 * ACTIVE – Spark (15s, 30s CD):
 * - Every attack = crit
 * - Disable enemy shields 10s
 * - Arrows ignore shields
 */
public class StrengthAbility implements Ability, Listener {

    private final Set<UUID> sparkActive = new HashSet<>();

    // Visual-only palette for the Berserker Aura
    private static final Particle.DustOptions BERSERKER_CRIMSON =
        new Particle.DustOptions(org.bukkit.Color.fromRGB(220, 20, 40), 0.8f);
    private static final Particle.DustOptions BERSERKER_DARK =
        new Particle.DustOptions(org.bukkit.Color.fromRGB(120, 0, 15), 0.7f);
    private final Map<UUID, BukkitTask> sparkParticleTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> sparkEndTasks = new HashMap<>();


    @Override
    public PotionType type() { return PotionType.STRENGTH; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        if (!PotionUtils.isQuiet()) {
            player.sendMessage(PotionUtils.colorize("&4Titan Warrior passive active — 2× mob damage!"));
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        cleanupSpark(player.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        cleanupSpark(event.getEntity().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cleanupSpark(event.getPlayer().getUniqueId());
    }

    private void cleanupSpark(UUID uid) {
        BukkitTask particleTask = sparkParticleTasks.remove(uid);
        if (particleTask != null) particleTask.cancel();

        BukkitTask endTask = sparkEndTasks.remove(uid);
        if (endTask != null) endTask.cancel();

        sparkActive.remove(uid);
    }

    // ── Passive: bonus damage on hit / melee crit + shield-disable during Spark ──
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player player) {
            if (ProgrammaticDamageGuard.isSuppressed(player.getUniqueId())) {
                return;
            }
            handleMeleeHit(e, player);
            return;
        }

        // Arrows: while Spark is active, the shooter's arrows ignore the
        // target's raised shield (documented Spark behavior — "Arrows
        // ignore shields"). Nothing else about Strength applies to arrows.
        if (e.getDamager() instanceof Arrow arrow && arrow.getShooter() instanceof Player shooter) {
            UUID shooterUid = shooter.getUniqueId();
            if (sparkActive.contains(shooterUid)
                    && PotionSMP.getInstance().getSlotManager().hasEquipped(shooterUid, PotionType.STRENGTH)
                    && e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)) {
                // Zeroing out the BLOCKING modifier is the supported way to
                // bypass a raised shield's damage reduction for this hit —
                // it does not touch the shield item or the victim's state.
                e.setDamage(EntityDamageEvent.DamageModifier.BLOCKING, 0.0);
            }
        }
    }

    private void handleMeleeHit(EntityDamageByEntityEvent e, Player player) {
        UUID uid = player.getUniqueId();

        if (!PotionSMP.getInstance().getSlotManager().hasEquipped(uid, PotionType.STRENGTH)) return;

        if (e.getEntity() instanceof Monster) {
            // 2× damage on mobs
            e.setDamage(e.getDamage() * 2.0);
        }

        // Low HP bonus
        if (e.getEntity() instanceof LivingEntity le) {
            double hp = le.getHealth();
            if (hp < 4.0)       e.setDamage(e.getDamage() + 3.0);
            else if (hp < 8.0)  e.setDamage(e.getDamage() + 2.0);
            else if (hp < 12.0) e.setDamage(e.getDamage() + 1.0);

            // Spark active → every attack is an actual critical hit + shield disable
            if (sparkActive.contains(uid)) {
                // Real critical-hit damage: the vanilla crit multiplier is
                // 1.5×. Particle.CRIT alone is purely cosmetic and never
                // changes damage, so this is the actual "every attack = crit"
                // effect the particle was only ever meant to accompany.
                if (!isNaturalCritical(player)) {
                    e.setDamage(e.getDamage() * 1.5);
                }

                // Crit visual (kept — this is the correct accompanying
                // effect, just no longer mistaken for the mechanic itself).
                le.getWorld().spawnParticle(Particle.CRIT, le.getLocation().add(0,1,0),
                    8, 0.3,0.3,0.3, 0.1);

                // Shield disable: briefly disable their shield.
                if (le instanceof Player target) {
                    disableShield(target);
                }
            }
        }
    }

    private void disableShield(Player target) {
        // Paper API: the same mechanism vanilla uses when an axe disables a
        // shield — puts the shield item on cooldown so it can't be raised
        // for the duration. Unlike a potion effect, this only affects the
        // shield itself: no attributes or unrelated potion effects touched.
        target.setCooldown(Material.SHIELD, 200); // 10s
    }

    // ── Active: Spark ─────────────────────────────────────────────────────
    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int dur      = plugin.getConfig().getInt("potions.strength.active-duration", 15);
        int cooldown = plugin.getConfig().getInt("potions.strength.active-cooldown", 30);
        int ticks    = dur * 20;

        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        cleanupSpark(uid);
        sparkActive.add(uid);

        // Visual
        Location loc = player.getLocation();
        // Compact outward pulse (visual only): two crimson rings plus a few crits.
        for (int ring = 0; ring < 2; ring++) {
            double r = 0.9 + ring * 0.7;
            double y = loc.getY() + 0.9 + ring * 0.3;
            for (int i = 0; i < 10; i++) {
                double a = Math.PI * 2 * i / 10 + ring * 0.31;
                loc.getWorld().spawnParticle(Particle.DUST,
                    loc.getX() + r * Math.cos(a), y, loc.getZ() + r * Math.sin(a),
                    1, 0, 0, 0, 0, (i % 3 == 0) ? BERSERKER_DARK : BERSERKER_CRIMSON);
            }
        }
        loc.getWorld().spawnParticle(Particle.CRIT, loc.clone().add(0,1,0), 10, 0.4,0.5,0.4, 0.15);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_PLAYER_ATTACK_CRIT,     1f,   1.0f);

        player.sendTitle("§4§l⚔ SPARK", "§7Every hit is a critical!", 5, 40, 10);

        // Aura loop during spark
        BukkitTask oldParticleTask = sparkParticleTasks.remove(uid);
        if (oldParticleTask != null) oldParticleTask.cancel();
        BukkitTask oldEndTask = sparkEndTasks.remove(uid);
        if (oldEndTask != null) oldEndTask.cancel();

        BukkitTask particleTask = new BukkitRunnable() {
            int ticks2 = 0;
            double angle = 0;
            @Override
            public void run() {
                if (ticks2 >= ticks || !player.isOnline() || !sparkActive.contains(uid)) {
                    sparkParticleTasks.remove(uid);
                    cancel();
                    return;
                }
                // Berserker Aura (visual only): two short crimson streaks
                // circling the player, each a 3-point trail lagging behind
                // its head. Drawn every 3rd tick (6 particles) and kept
                // low so the player model stays clearly visible.
                angle += 0.3;
                if (ticks2 % 3 == 0) {
                    Location l = player.getLocation();
                    for (int streak = 0; streak < 2; streak++) {
                        double base = angle * 1.0 + Math.PI * streak;
                        double y = l.getY() + 1.0 + Math.sin(angle * 0.7 + streak * Math.PI) * 0.45;
                        for (int p = 0; p < 3; p++) {
                            double a = base - p * 0.16; // trail lags behind the head
                            l.getWorld().spawnParticle(Particle.DUST,
                                l.getX() + Math.cos(a) * 0.85, y - p * 0.07, l.getZ() + Math.sin(a) * 0.85,
                                1, 0, 0, 0, 0, (p == 0) ? BERSERKER_CRIMSON : BERSERKER_DARK);
                        }
                    }
                }
                ticks2++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        sparkParticleTasks.put(uid, particleTask);

        // Schedule end
        BukkitTask endTask = new BukkitRunnable() {
            @Override
            public void run() {
                sparkEndTasks.remove(uid);
                BukkitTask particle = sparkParticleTasks.remove(uid);
                if (particle != null) particle.cancel();
                sparkActive.remove(uid);
                if (player.isOnline())
                    player.sendActionBar(net.kyori.adventure.text.Component.text("§7Spark ended."));
            }
        }.runTaskLater(plugin, ticks);
        sparkEndTasks.put(uid, endTask);

        return ActivationResult.SUCCESS;
    }

    private boolean isNaturalCritical(Player player) {
        return player.getAttackCooldown() >= 0.9f
                && player.getFallDistance() > 0.0f
                && !player.isOnGround()
                && !player.isSprinting()
                && !player.isSwimming()
                && !player.isInsideVehicle()
                && !player.hasPotionEffect(org.bukkit.potion.PotionEffectType.BLINDNESS);
    }

    public boolean isSparkActive(UUID uid) { return sparkActive.contains(uid); }
}
