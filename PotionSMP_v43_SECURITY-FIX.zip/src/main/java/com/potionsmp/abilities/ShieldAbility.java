package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Shield Potion — Divine Barrier
 * No passive.
 * Active: full damage + knockback immunity for 8s, dual spinning particle rings.
 */
public class ShieldAbility implements Ability, Listener {

    private PotionSMP plugin;

    @Override
    public void register(PotionSMP plugin) {
        this.plugin = plugin;
        Ability.super.register(plugin);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        plugin.getShieldManager().cleanupPlayer(event.getEntity().getUniqueId());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        plugin.getShieldManager().cleanupPlayer(event.getPlayer().getUniqueId());
    }

    @Override
    public PotionType type() { return PotionType.SHIELD; }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        if (plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), type()))
            return ActivationResult.ON_COOLDOWN;

        if (plugin.getEnderDomainManager().isSuppressed(player.getUniqueId())) {
            player.sendMessage(PotionUtils.colorize("&5☠ Suppressed by an Abyss Domain!"));
            return ActivationResult.SUCCESS;
        }

        int duration = plugin.getConfig().getInt("potions.shield.active-duration", 160);
        int cooldown = plugin.getConfig().getInt("potions.shield.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(player.getUniqueId(), type(), cooldown);
        player.sendMessage(PotionUtils.msg("shield-active"));

        plugin.getShieldManager().activateShield(player, duration);

        return ActivationResult.SUCCESS;
    }
}
