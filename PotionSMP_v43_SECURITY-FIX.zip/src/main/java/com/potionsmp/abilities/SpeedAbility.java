package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * PASSIVE:
 * - Base Speed I is active when no stronger Speed effect has priority.
 * - Ten consecutive valid hits, each within a rolling 1.5s window → Speed IV
 * - Speed IV lasts exactly 3 seconds and is never refreshed by extra hits
 * - After Speed IV ends, the combo counter is reset and a fresh 10-hit combo is required
 * - Speed IV takes priority over external Speed II while its fixed 3-second
 *   lifecycle is active; external Speed is restored with remaining duration
 *   when the custom IV ends, if it has not expired first
 * - 25% reduced iframes on hit targets
 *
 * ACTIVE – Lightning Dash:
 * - Dash in look direction
 * - Speed IV during dash
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 */
public class SpeedAbility implements Ability, Listener {

    // Consecutive valid-hit counter for the custom Speed combo.
    // This state is independent from Bukkit's SPEED amplifier.
    private final Map<UUID, Integer> speedStacks = new HashMap<>();
    // One fixed 60-tick lifecycle for each custom combo Speed IV activation.
    private final Map<UUID, BukkitTask> comboSpeedIVTasks = new HashMap<>();
    private final Map<UUID, Integer> comboSpeedIVExpiresAt = new HashMap<>();
    // Tracks whether PotionSMP currently owns the passive Speed I slot.
    // When a stronger external Speed effect arrives, the claim is discarded
    // without touching the external effect; it is recreated when that effect ends.
    private final Set<UUID> passiveSpeedOwned = new HashSet<>();
    // Bukkit effect events are synchronous. This prevents our own add/remove
    // operations from being mistaken for external Speed changes.
    private final Set<UUID> internalSpeedMutation = new HashSet<>();
    // One combo-expiration task per player.
    private final Map<UUID, BukkitTask> comboExpirationTasks = new HashMap<>();
    // Players currently dashing
    private final Set<UUID>          dashing        = new HashSet<>();
    // Running dash trail/completion task per player, so every cleanup path
    // (unequip, death, quit) can cancel it directly instead of letting it
    // discover the missing "dashing" flag and finish as if it had completed.
    private final Map<UUID, BukkitTask> dashTasks = new HashMap<>();
    // Pending "restore passive Speed" tasks for the dash's own temporary
    // Speed IV. A newer dash boost supersedes an older one instead of both
    // fighting over the player's Speed effect.
    private final Map<UUID, BukkitTask> pendingSpeedRestore = new HashMap<>();
    private static final long COMBO_WINDOW_TICKS = 30L;
    private static final int MAX_HITS = 10;
    private static final long COMBO_SPEED_IV_TICKS = 60L;

    // Best-known non-PotionSMP Speed effect currently suppressed beneath
    // the combo's Speed IV (e.g. an external/vanilla Speed II). Captured
    // either right before the 10th hit overwrites it, or — if it arrives
    // while Speed IV is already live — by the EntityPotionEffectEvent
    // guard below. Restored, with its remaining duration projected
    // forward, once Speed IV naturally ends; dropped if it would have
    // expired first. PotionSMP itself only ever sets amplifier 0 (Speed I)
    // or amplifier 3 (Speed IV/dash boost), so any other live amplifier is
    // by definition external.
    private final Map<UUID, ExternalSnapshot> externalSpeed = new HashMap<>();

    private static final class ExternalSnapshot {
        final PotionEffect effect;
        final int capturedTick;
        ExternalSnapshot(PotionEffect effect, int capturedTick) {
            this.effect = effect;
            this.capturedTick = capturedTick;
        }
    }


    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applyPassiveSpeedIfAllowed(plugin, player);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        speedStacks.remove(uid);
        boolean comboIVWasActive = isComboSpeedIVActive(uid);
        if (comboIVWasActive && !internalSpeedMutation.contains(uid)) {
            removeInternalSpeed(player);
        }
        cancelComboSpeedIV(uid);
        passiveSpeedOwned.remove(uid);
        // Dash cancelled by unequip/replacement: cancel its task so it can
        // never reach the completion path (no Shockwave), and release the
        // dash Resistance the task would otherwise have cleared.
        boolean wasDashing = dashing.remove(uid);
        cancelDashTask(uid);
        if (wasDashing && player.isOnline() && !player.isDead()) {
            plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
        }
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.SPEED);

        // clear() above only restores whatever was on this slot before
        // PotionSMP's very first touch — it doesn't know about a more
        // recent external effect (e.g. Speed II) that arrived and was
        // suppressed mid-session. Hand that back too, if it hasn't
        // expired, since PotionSMP no longer owns this slot to preserve it.
        restoreExternalDirectly(plugin, player);
    }

    // ── Cleanup on quit / death — Multiple Dash Fix ────────────────────────
    // Ensures "dashing" (and related temp-boost state) can never get stuck
    // if the player disconnects or dies mid-dash.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uid = event.getPlayer().getUniqueId();
        dashing.remove(uid);
        cancelDashTask(uid);
        speedStacks.remove(uid);
        cancelComboSpeedIV(uid);
        passiveSpeedOwned.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
        // No live effect to hand it back to while offline, and a fresh
        // rejoin should never resurrect it.
        externalSpeed.remove(uid);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uid = player.getUniqueId();

        // Minecraft clears active potion effects on death. Cancel any
        // pending Speed restore so it cannot fire while the player is dead.
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        // The stack-decay loop must also stop during the dead state;
        // PassiveReapplyListener starts a fresh, idempotent loop on respawn.
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();

        // Combo state ends with the player's effects; a stale count here
        // would make the post-respawn state disagree with the actual Speed
        // effect.
        speedStacks.remove(uid);
        cancelComboSpeedIV(uid);
        passiveSpeedOwned.remove(uid);

        // Death has already wiped whatever external Speed effect this was
        // shadowing too, so there is nothing left to restore it into.
        externalSpeed.remove(uid);

        // Cancel the dash task directly so death can never fall through to
        // the dash-completion path (no Shockwave from cleanup).
        dashing.remove(uid);
        cancelDashTask(uid);

        // Do not call clear(): death has already wiped the Bukkit effect, so
        // restoring the pre-PotionSMP Resistance snapshot would be wrong.
        // Discard only our bookkeeping claim; the respawn equip path will
        // create fresh ownership state.
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin != null) {
            plugin.getEffectOwnershipManager()
                .discard(player, type(), PotionEffectType.RESISTANCE);
        }
    }

    // ── Passive hit: 10-hit combo → fixed 3-second Speed IV ───────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        UUID uid = player.getUniqueId();

        // Hits during the fixed Speed IV do not advance, refresh, or restart
        // the combo. The IV has its own independent 60-tick lifecycle.
        if (isComboSpeedIVActive(uid)) {
            applyHitEffects(target);
            return;
        }

        int previousHits = speedStacks.getOrDefault(uid, 0);
        int hits = previousHits + 1;
        speedStacks.put(uid, hits);

        BukkitTask previous = comboExpirationTasks.remove(uid);
        if (previous != null) previous.cancel();

        if (hits >= MAX_HITS) {
            // The combo is locked/reset immediately. Additional hits during
            // the 60-tick IV cannot create another combo cycle.
            speedStacks.remove(uid);
            startComboSpeedIV(plugin, player);
        } else {
            scheduleComboExpiration(plugin, player);
        }

        applyHitEffects(target);
    }

    private void applyHitEffects(LivingEntity target) {
        // Reduce iframes by 25% (set to 75% of default 20).
        target.setNoDamageTicks(Math.max(0, (int)(target.getNoDamageTicks() * 0.75)));

        // Existing hit spark.
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0, 1, 0), 4, 0.2, 0.2, 0.2, 0.05);
    }

    private boolean isComboSpeedIVActive(UUID uid) {
        BukkitTask task = comboSpeedIVTasks.get(uid);
        return task != null && !task.isCancelled();
    }

    private void startComboSpeedIV(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        cancelComboSpeedIV(uid);

        PotionEffect current = player.getPotionEffect(PotionEffectType.SPEED);
        captureIfExternal(uid, current, plugin.getServer().getCurrentTick());

        // Release the passive claim without restoring/removing the currently
        // visible effect; the fixed Speed IV immediately takes that slot.
        passiveSpeedOwned.remove(uid);
        plugin.getEffectOwnershipManager().discard(player, type(), PotionEffectType.SPEED);

        applyInternalSpeed(player, new PotionEffect(
            PotionEffectType.SPEED, (int) COMBO_SPEED_IV_TICKS, 3, false, false));

        int expiresAt = plugin.getServer().getCurrentTick() + (int) COMBO_SPEED_IV_TICKS;
        comboSpeedIVExpiresAt.put(uid, expiresAt);

        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            comboSpeedIVTasks.remove(uid);
            comboSpeedIVExpiresAt.remove(uid);
            if (!player.isOnline()) {
                externalSpeed.remove(uid);
                return;
            }
            finishComboSpeedIV(plugin, player);
        }, COMBO_SPEED_IV_TICKS);
        comboSpeedIVTasks.put(uid, task);
    }

    private void finishComboSpeedIV(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        speedStacks.remove(uid);

        // Do not blindly remove another Speed effect. If Lightning Dash (or
        // another non-combo Speed source) currently owns the visible slot,
        // leave it alone and let its existing lifecycle finish.
        PotionEffect current = player.getPotionEffect(PotionEffectType.SPEED);
        if (current != null && current.getAmplifier() != 3) {
            if (current.getAmplifier() > 0) {
                externalSpeed.remove(uid);
                return;
            }
        }

        // If Lightning Dash is currently using its own temporary Speed IV,
        // do not touch that effect. Its existing dash restore task owns it.
        if (pendingSpeedRestore.containsKey(uid)) {
            externalSpeed.remove(uid);
            return;
        }

        // Remove only our combo IV. The mutation guard prevents the removal
        // event from being mistaken for expiration of an external effect.
        if (current != null && current.getAmplifier() == 3) {
            removeInternalSpeed(player);
        }

        ExternalSnapshot ext = externalSpeed.remove(uid);
        if (ext != null) {
            int remaining = ext.effect.getDuration()
                - (plugin.getServer().getCurrentTick() - ext.capturedTick);
            if (remaining > 0 && plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) {
                applyInternalSpeed(player, new PotionEffect(
                    PotionEffectType.SPEED, remaining, ext.effect.getAmplifier(),
                    ext.effect.isAmbient(), ext.effect.hasParticles(), ext.effect.hasIcon()));
                return;
            }
        }

        applyPassiveSpeedIfAllowed(plugin, player);
    }

    private void scheduleComboExpiration(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            comboExpirationTasks.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;
            if (isComboSpeedIVActive(uid)) return;

            speedStacks.remove(uid);
            plugin.getLogger().fine("[SPEED-DIAG] combo timeout: " + player.getName());
        }, COMBO_WINDOW_TICKS);
        comboExpirationTasks.put(uid, task);
    }

    private void cancelComboSpeedIV(UUID uid) {
        BukkitTask task = comboSpeedIVTasks.remove(uid);
        if (task != null) task.cancel();
        comboSpeedIVExpiresAt.remove(uid);
    }

    private void applyPassiveSpeedIfAllowed(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;
        if (isComboSpeedIVActive(uid)) return;
        if (dashing.contains(uid)) return;

        PotionEffect current = player.getPotionEffect(PotionEffectType.SPEED);
        if (current != null && current.getAmplifier() > 0) {
            // External Speed II+ has priority over passive Speed I.
            passiveSpeedOwned.remove(uid);
            return;
        }

        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
        passiveSpeedOwned.add(uid);
    }

    private void applyInternalSpeed(Player player, PotionEffect effect) {
        UUID uid = player.getUniqueId();
        internalSpeedMutation.add(uid);
        try {
            player.addPotionEffect(effect);
        } finally {
            internalSpeedMutation.remove(uid);
        }
    }

    private void removeInternalSpeed(Player player) {
        UUID uid = player.getUniqueId();
        internalSpeedMutation.add(uid);
        try {
            player.removePotionEffect(PotionEffectType.SPEED);
        } finally {
            internalSpeedMutation.remove(uid);
        }
    }

    // ── Speed IV priority: preserve/restore an external Speed effect ──────
    // (e.g. vanilla/beacon Speed II) that Speed IV would otherwise clobber.

    /** Records {@code candidate} as the effect to restore later, if it isn't
     *  one of PotionSMP's own Speed I/IV amplifiers (0 or 3). */
    private void captureIfExternal(UUID uid, PotionEffect candidate, int nowTick) {
        if (candidate == null) return;
        int amp = candidate.getAmplifier();
        if (amp == 0 || amp == 3) return; // our own baseline/IV, not external
        considerExternalCandidate(uid, candidate, nowTick);
    }

    /**
     * Keeps the better of the current snapshot and {@code candidate}:
     * higher amplifier wins outright; on a tie, the one with the greater
     * remaining duration wins. Never replaces an existing snapshot with a
     * strictly worse one ("do not unnecessarily shorten an existing
     * effect").
     */
    private void considerExternalCandidate(UUID uid, PotionEffect candidate, int nowTick) {
        ExternalSnapshot current = externalSpeed.get(uid);
        if (current == null) {
            externalSpeed.put(uid, new ExternalSnapshot(candidate, nowTick));
            return;
        }
        int currentRemaining = current.effect.getDuration() - (nowTick - current.capturedTick);
        if (candidate.getAmplifier() > current.effect.getAmplifier()
                || (candidate.getAmplifier() == current.effect.getAmplifier()
                    && candidate.getDuration() > currentRemaining)) {
            externalSpeed.put(uid, new ExternalSnapshot(candidate, nowTick));
        }
    }

    /**
     * Unequip only: the ownership clear() just above already handed the
     * slot back to whatever was there before PotionSMP's first-ever touch,
     * but that doesn't know about a more recent external effect suppressed
     * mid-session. Reapply it directly (PotionSMP no longer owns this slot
     * at all once unequipped) if it hasn't expired.
     */
    private void restoreExternalDirectly(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        ExternalSnapshot ext = externalSpeed.remove(uid);
        if (ext == null || !player.isOnline() || player.isDead()) return;

        int remaining = ext.effect.getDuration() - (plugin.getServer().getCurrentTick() - ext.capturedTick);
        if (remaining > 0) {
            player.addPotionEffect(new PotionEffect(
                PotionEffectType.SPEED, remaining, ext.effect.getAmplifier(),
                ext.effect.isAmbient(), ext.effect.hasParticles(), ext.effect.hasIcon()));
        }
    }

    /**
     * Keeps Bukkit's single SPEED slot ordered without allowing passive
     * Speed I to overwrite a stronger external Speed effect. During custom
     * combo Speed IV, lower external effects are captured and suppressed;
     * after IV expires the snapshot is restored if it is still alive.
     */
    @EventHandler
    public void onExternalSpeedChange(EntityPotionEffectEvent event) {
        if (event.getModifiedType() != PotionEffectType.SPEED) return;
        if (!(event.getEntity() instanceof Player player)) return;

        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;

        UUID uid = player.getUniqueId();
        if (internalSpeedMutation.contains(uid)) return;

        PotionEffect incoming = event.getNewEffect();
        int now = plugin.getServer().getCurrentTick();

        if (isComboSpeedIVActive(uid)) {
            if (incoming == null) {
                // Do not allow the custom IV to be removed by an external
                // removal while its fixed 60-tick lifecycle is still active.
                event.setCancelled(true);
                return;
            }
            if (incoming.getAmplifier() < 3) {
                considerExternalCandidate(uid, incoming, now);
                event.setCancelled(true);
            }
            return;
        }

        // Passive Custom Speed I must yield to any stronger external SPEED.
        if (incoming != null && incoming.getAmplifier() > 0
                && passiveSpeedOwned.contains(uid)) {
            plugin.getEffectOwnershipManager().discard(player, type(), PotionEffectType.SPEED);
            passiveSpeedOwned.remove(uid);
            plugin.getLogger().fine("[SPEED-DIAG] Custom Speed I paused for external Speed "
                + (incoming.getAmplifier() + 1) + ": " + player.getName());
            return;
        }

        // An external stronger effect has ended. Resume passive Speed I only
        // if Speed IV/dash is not currently owning the slot.
        if (incoming == null
                && !passiveSpeedOwned.contains(uid)
                && plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)
                && !dashing.contains(uid)) {
            // Bukkit may still expose the just-removed effect during the
            // event. Resume on the next tick, after the external effect is
            // actually gone.
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;
                if (isComboSpeedIVActive(uid) || dashing.contains(uid)) return;
                applyPassiveSpeedIfAllowed(plugin, player);
                plugin.getLogger().fine("[SPEED-DIAG] Custom Speed I resumed: " + player.getName());
            });
        }
    }

    /**
     * Applies the dash's existing TIME-LIMITED Speed IV (never Integer.MAX_VALUE) and
     * schedules a restore once it naturally expires. The restore returns to
     * whatever the current combo state dictates: Speed IV if a maintained
     * combo is still active, otherwise passive Speed I. The dash therefore
     * never ends, extends or resets the combo's Speed IV; that is governed
     * solely by the combo timer.
     */
    private void applyTemporarySpeed(PotionSMP plugin, Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, durationTicks, amplifier, false, false));

        BukkitTask restore = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            pendingSpeedRestore.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            if (isComboSpeedIVActive(uid)) {
                int remaining = Math.max(1, comboSpeedIVExpiresAt.getOrDefault(uid,
                    plugin.getServer().getCurrentTick() + 1) - plugin.getServer().getCurrentTick());
                applyInternalSpeed(player, new PotionEffect(
                    PotionEffectType.SPEED, remaining, 3, false, false));
            } else {
                applyPassiveSpeedIfAllowed(plugin, player);
            }
        }, durationTicks);

        pendingSpeedRestore.put(uid, restore);
    }

    private void cancelDashTask(UUID uid) {
        BukkitTask dash = dashTasks.remove(uid);
        if (dash != null) dash.cancel();
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Speed IV + 20% damage reduction during dash. Speed IV is applied
        // as a temporary boost (via applyTemporarySpeed) so the level that
        // matches the current combo state is restored once the dash's speed
        // window ends, instead of being left with no Speed effect at all.
        applyTemporarySpeed(plugin, player, 3, 40);
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        BukkitTask dashTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                // DASH CANCELLATION / CLEANUP: the player left, died, or the
                // dash flag was removed (Speed unequipped/replaced). Cleanup
                // never triggers the Shockwave.
                if (!player.isOnline() || player.isDead() || !dashing.contains(uid)) {
                    if (player.isOnline() && !player.isDead()) {
                        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    dashTasks.remove(uid);
                    cancel(); return;
                }
                // NORMAL DASH COMPLETION (1.8s): the only Shockwave path.
                if (ticks >= 36) {
                    triggerShockwave(plugin, player);
                    plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
                    dashing.remove(uid);
                    dashTasks.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2,0.2,0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc, 2, 0.3,0.1,0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        dashTasks.put(uid, dashTask);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world  = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg    = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle)*radius, 0.1, Math.sin(angle)*radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1,0.1,0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK,   p, 1, 0,0,0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            ProgrammaticDamageGuard.beginSuppression(player.getUniqueId());
            try {
                le.damage(dmg, player);
            } finally {
                ProgrammaticDamageGuard.endSuppression(player.getUniqueId());
            }
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }
}
