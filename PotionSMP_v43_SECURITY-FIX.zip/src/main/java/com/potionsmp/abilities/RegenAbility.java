package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

public class RegenAbility implements Ability, Listener {

    @Override
    public PotionType type() { return PotionType.REGEN; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Don't grant the passive regen while inside an Abyss Domain — once
        // the player leaves (or the domain ends), EnderDomainManager itself
        // calls this same method again to restore it.
        if (plugin.getEnderDomainManager().isSuppressed(player.getUniqueId())) return;
        int amp = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, amp, false, false));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.REGENERATION);
        plugin.getRegenAbilityManager().clearCharge(player.getUniqueId());
        plugin.getRegenAbilityManager().closeWindow(player.getUniqueId());
        plugin.getVitalityParticleRenderer().stop(player.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        UUID uid = event.getEntity().getUniqueId();
        plugin.getRegenAbilityManager().clearTransient(uid);
        plugin.getVitalityParticleRenderer().stop(uid);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        UUID uid = event.getPlayer().getUniqueId();
        plugin.getRegenAbilityManager().clearTransient(uid);
        plugin.getVitalityParticleRenderer().stop(uid);
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        plugin.getLogger().info("[MACE-DIVE-DIAG] RegenAbility.onHit ENTER "
                + "attacker=" + player.getName()
                + ", target=" + target.getName()
                + ", targetClass=" + target.getClass().getName()
                + ", targetIsPlayer=" + (target instanceof Player));
        // TEMPORARY DIAGNOSTIC ONLY: Mace Dive currently receives its target
        // from the normal EntityDamageByEntityEvent path; it does not perform
        // its own nearby-entity search here. Log the exact candidate handed
        // to Regen so we can determine whether Players reach this path.
        boolean charged = plugin.getRegenAbilityManager().isChargedForDive(player.getUniqueId());
        plugin.getLogger().info("[MACE-DIVE-DIAG] Candidate received by RegenAbility.onHit: "
                + "class=" + target.getClass().getName()
                + ", type=" + target.getType()
                + ", name=" + target.getName()
                + ", living=true"
                + ", player=" + (target instanceof Player)
                + ", charged=" + charged
                + ", accepted=" + charged
                + ", reason=" + (charged ? "charged Mace Dive; target handed off as final candidate"
                                          : "Mace Dive not charged; candidate rejected before trigger"));

        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG)
        plugin.getLogger().info("[REGEN-DIAG][RegenAbility.onHit] ENTER: "
                + "attacker=" + player.getName()
                + ", target=" + target.getName()
                + ", targetClass=" + target.getClass().getName()
                + ", targetIsPlayer=" + (target instanceof Player)
                + ", chargedForDive=" + charged
                + ", onGround=" + player.isOnGround()
                + ", fallDistance=" + player.getFallDistance());
        if (!charged) {
            plugin.getLogger().info("[REGEN-DIAG][RegenAbility.onHit] chargedForDive=false -> REJECTED: "
                    + "attacker UUID " + player.getUniqueId() + " is not in chargedForDive set "
                    + "(never added by launch(), or already removed by landing watcher / triggerMaceDive / clearCharge / clearTransient - see [REGEN-DIAG][Manager] removal logs)");
            return;
        }
        plugin.getLogger().info("[REGEN-DIAG][RegenAbility.onHit] chargedForDive=true -> Mace Dive is being triggered");
        // Vanilla-style Mace smash damage from the actual fall distance
        // (no fixed / configured damage).
        double dmg = plugin.getRegenAbilityManager().calculateMaceDiveDamage(player);
        plugin.getRegenAbilityManager().triggerMaceDive(player, target, dmg);
        plugin.getLogger().info("[MACE-DIVE-DIAG] Final selected target: "
                + "class=" + target.getClass().getName()
                + ", type=" + target.getType()
                + ", name=" + target.getName()
                + ", living=true"
                + ", player=" + (target instanceof Player));
        player.sendMessage(PotionUtils.msg("mace-dive-hit").replace("%target%", target.getName()));
    }

    /**
     * Vitality Surge activation: Shift + the trigger of the slot that
     * actually contains Regen.
     *
     * SlotCommand (/slot1, /slot2) resolves the pressed slot to the potion
     * type sitting in it and only calls activate() on THAT type's ability.
     * So this method is reached only when the pressed slot holds Regen; a
     * Shift + trigger of the other slot goes to the other potion's own
     * ability, and Shift + X/Y with Regen unequipped never gets here. Only
     * Regen looks at the Shift state; every other ability's dispatch is
     * untouched.
     *
     * The old Sneak + Right Click path (PlayerInteractEvent) is removed.
     */
    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG): state snapshot for every attempt.
        boolean dSneak = player.isSneaking();
        boolean dEquipped = plugin.getSlotManager().hasEquipped(uid, PotionType.REGEN);
        boolean dWindow = plugin.getRegenAbilityManager().isWindowActive(uid);
        boolean dCooldown = plugin.getCooldownManager().isOnCooldown(uid, type());
        long dCooldownRem = plugin.getCooldownManager().getRemainingSeconds(uid, type());
        String dState = "player=" + player.getName()
                + ", isSneaking=" + dSneak
                + ", regenEquipped=" + dEquipped
                + ", isWindowActive=" + dWindow
                + ", onCooldown=" + dCooldown + " (remaining=" + dCooldownRem + "s)"
                + ", tick=" + plugin.getServer().getCurrentTick()
                + ", ms=" + System.currentTimeMillis();

        // Plain (non-Shift) trigger of Regen's slot: existing behavior, no ability.
        if (!player.isSneaking()) {
            plugin.getLogger().info("[REGEN-DIAG][activate] REJECTED reason=not sneaking; " + dState);
            return ActivationResult.SUCCESS;
        }

        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.REGEN)) {
            plugin.getLogger().info("[REGEN-DIAG][activate] REJECTED reason=Regen not equipped; " + dState);
            return ActivationResult.SUCCESS;
        }

        // While the existing Surge window is active, allow another launch
        // only after the player has landed. The same window is preserved and
        // is never reopened or extended.
        if (plugin.getRegenAbilityManager().isWindowActive(uid)) {
            int height = plugin.getConfig().getInt("potions.regen.active-jump-height", 10);
            boolean relaunched = plugin.getRegenAbilityManager().relaunchWithinWindow(player, height);
            plugin.getLogger().info("[REGEN-DIAG][activate] WINDOW ACTIVE -> relaunch=" + relaunched + "; " + dState);
            return ActivationResult.SUCCESS;
        }

        // Existing cooldown rules, untouched for starting a new Surge window.
        if (plugin.getCooldownManager().isOnCooldown(uid, type())) {
            plugin.getLogger().info("[REGEN-DIAG][activate] REJECTED reason=on cooldown; " + dState);
            return ActivationResult.ON_COOLDOWN;
        }

        plugin.getLogger().info("[REGEN-DIAG][activate] ACCEPTED (isWindowActive==false at this moment); " + dState);
        triggerVitalitySurge(plugin, player);
        return ActivationResult.SUCCESS;
    }

    public void triggerVitalitySurge(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        // Suppressed: refuse to launch.
        if (plugin.getEnderDomainManager().isSuppressed(uid)) {
            plugin.getLogger().info("[REGEN-DIAG][triggerVitalitySurge] ABORTED after accept: reason=EnderDomain suppressed, player=" + player.getName());
            return;
        }

        // One activation per Surge window. Never re-launch inside it.
        if (plugin.getRegenAbilityManager().isWindowActive(uid)) {
            plugin.getLogger().info("[REGEN-DIAG][triggerVitalitySurge] ABORTED after accept: reason=window already active, player=" + player.getName());
            return;
        }

        int windowDuration = plugin.getConfig().getInt("potions.regen.active-duration", 200);

        int height = plugin.getConfig().getInt("potions.regen.active-jump-height", 10);
        int amp = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);

        player.sendMessage(PotionUtils.msg("regen-active"));

        // Full particle-only Vitality Surge animation (awakening → heart
        // formation → surge → sustained loop), started once here and left
        // running for the full active-duration window.
        plugin.getVitalityParticleRenderer().start(player);

        // Cooldown starts on activation, not on /slot press.
        int cooldown = plugin.getConfig().getInt("potions.regen.active-cooldown", 45);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        // Play the visual-only collapse animation once the window's
        // gameplay duration ends. Purely cosmetic — does not touch the
        // regeneration effect, glow, or Mace Dive charge timing. Tracked
        // per player so unequip/death/quit can cancel it.
        plugin.getRegenAbilityManager().scheduleEndAnimation(player, windowDuration);

        // true = open the one Surge window as part of this launch.
        plugin.getRegenAbilityManager().launch(player, height, windowDuration, amp + 1, true);
    }
}
