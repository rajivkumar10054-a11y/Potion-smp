package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.UUID;

/**
 * Handles freezing entities in place - used both by Freeze's passive
 * (brief 1s "struck"/stun on every 10th hit) and its active Arctic Prison
 * (full 3s area freeze). Locks position every tick and applies heavy
 * Slowness/Mining Fatigue so the entity can't move, attack, mine, or act.
 */
public class FrozenPlayerManager implements Listener {

    private final PotionSMP plugin;
    private final Map<UUID, Location> frozenEntities = new HashMap<>();
    private final Map<UUID, Integer> frozenTaskIds = new HashMap<>();
    // Non-player LivingEntities need their pre-Freeze Bukkit effects restored
    // because EffectOwnershipManager intentionally handles players only.
    // A snapshot is captured only once per (entity, effect type), so refreshing
    // an existing freeze never snapshots Freeze's own effect as the original.
    private final Map<UUID, Map<PotionEffectType, PotionEffect>> originalMobEffects = new HashMap<>();

    private static final Particle.DustOptions FROST_LOCK_CYAN =
            new Particle.DustOptions(Color.fromRGB(185, 241, 255), 0.7f);

    public FrozenPlayerManager(PotionSMP plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        Location loc = entity.getLocation().clone();
        frozenEntities.put(uid, loc);

        int dur = durationTicks + 5;
        if (entity instanceof Player player) {
            // Routed through EffectOwnershipManager so this never blindly
            // clobbers/deletes another PotionSMP ability's own claim on the
            // same effect type (e.g. Glitch's permanent Mining Fatigue) or a
            // vanilla/other-plugin effect the target already had.
            var ownership = plugin.getEffectOwnershipManager();
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false));
        } else {
            // Snapshot the mob's existing effects before Freeze touches them.
            // The snapshot is per entity/effect and survives Freeze refreshes.
            snapshotMobEffect(entity, PotionEffectType.SLOWNESS);
            snapshotMobEffect(entity, PotionEffectType.MINING_FATIGUE);
            snapshotMobEffect(entity, PotionEffectType.JUMP_BOOST);

            entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
            entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
            entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false));
        }

        // Cancel any previous freeze task for this entity before starting a new one
        Integer existing = frozenTaskIds.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable lockTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks || !entity.isValid()) {
                    unfreeze(entity);
                    cancel();
                    return;
                }
                if (entity.getLocation().distanceSquared(loc) > 0.1) {
                    entity.teleport(loc);
                }
                entity.setVelocity(new Vector(0, 0, 0));

                // Sparse frost accent while locked — every 4th tick, single
                // cyan particle, instead of the old 9-particle-per-tick
                // SNOWFLAKE/ITEM_SNOWBALL cloud.
                if (ticks % 4 == 0) {
                    entity.getWorld().spawnParticle(Particle.DUST, entity.getLocation().add(0, 1, 0),
                            1, 0.2, 0.3, 0.2, 0, FROST_LOCK_CYAN);
                }

                ticks++;
            }
        };
        int taskId = lockTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        frozenTaskIds.put(uid, taskId);
    }

    public void unfreeze(LivingEntity entity) {
        cleanupEntity(entity, false, false);
    }

    private void snapshotMobEffect(LivingEntity entity, PotionEffectType type) {
        UUID uid = entity.getUniqueId();
        Map<PotionEffectType, PotionEffect> snapshots =
                originalMobEffects.computeIfAbsent(uid, k -> new HashMap<>());
        if (!snapshots.containsKey(type)) {
            PotionEffect existing = entity.getPotionEffect(type);
            snapshots.put(type, copyEffect(existing));
        }
    }

    private PotionEffect copyEffect(PotionEffect effect) {
        if (effect == null) return null;
        return new PotionEffect(effect.getType(), effect.getDuration(), effect.getAmplifier(),
                effect.isAmbient(), effect.hasParticles(), effect.hasIcon());
    }

    private void restoreMobEffects(LivingEntity entity, UUID uid) {
        Map<PotionEffectType, PotionEffect> snapshots = originalMobEffects.remove(uid);
        if (snapshots == null) return;

        for (PotionEffectType type : snapshots.keySet()) {
            PotionEffect original = snapshots.get(type);
            if (original != null) {
                entity.addPotionEffect(copyEffect(original));
            } else {
                entity.removePotionEffect(type);
            }
        }
    }

    private void cleanupEntity(LivingEntity entity, boolean lifecycleEnd, boolean stopFreezeAura) {
        UUID uid = entity.getUniqueId();
        frozenEntities.remove(uid);

        Integer taskId = frozenTaskIds.remove(uid);
        if (taskId != null) {
            plugin.getServer().getScheduler().cancelTask(taskId);
        }

        if (entity instanceof Player player) {
            var ownership = plugin.getEffectOwnershipManager();
            if (lifecycleEnd) {
                // On death, Bukkit will clear the player's effects as part of
                // the lifecycle. Discard our claims/snapshots instead of
                // restoring an effect onto a dead player.
                ownership.discard(player, PotionType.FREEZE, PotionEffectType.SLOWNESS);
                ownership.discard(player, PotionType.FREEZE, PotionEffectType.MINING_FATIGUE);
                ownership.discard(player, PotionType.FREEZE, PotionEffectType.JUMP_BOOST);
            } else {
                ownership.clear(player, PotionType.FREEZE, PotionEffectType.SLOWNESS);
                ownership.clear(player, PotionType.FREEZE, PotionEffectType.MINING_FATIGUE);
                ownership.clear(player, PotionType.FREEZE, PotionEffectType.JUMP_BOOST);
            }
            if (stopFreezeAura) {
                plugin.getParticleManager().cancelAura(uid);
            }
        } else if (!lifecycleEnd) {
            restoreMobEffects(entity, uid);
        } else {
            // The entity is dead; no live effect can be restored. The snapshot
            // must still be discarded so the UUID cannot remain stale.
            originalMobEffects.remove(uid);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        cleanupEntity(event.getPlayer(), false, true);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        cleanupEntity(event.getEntity(), true, true);
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player) return;
        cleanupEntity(event.getEntity(), true, false);
    }

    public boolean isFrozen(UUID uid) {
        return frozenEntities.containsKey(uid);
    }

    public void unfreezeAll() {
        for (int id : new HashSet<>(frozenTaskIds.values())) {
            plugin.getServer().getScheduler().cancelTask(id);
        }

        // Restore/clear every currently tracked target without invoking the
        // normal targeted task flow, because this is plugin-wide shutdown.
        for (UUID uid : new HashSet<>(frozenEntities.keySet())) {
            LivingEntity entity = null;
            Player player = plugin.getServer().getPlayer(uid);
            if (player != null) {
                entity = player;
            } else {
                var found = Bukkit.getEntity(uid);
                if (found instanceof LivingEntity living) entity = living;
            }

            if (entity instanceof Player onlinePlayer) {
                var ownership = plugin.getEffectOwnershipManager();
                ownership.clear(onlinePlayer, PotionType.FREEZE, PotionEffectType.SLOWNESS);
                ownership.clear(onlinePlayer, PotionType.FREEZE, PotionEffectType.MINING_FATIGUE);
                ownership.clear(onlinePlayer, PotionType.FREEZE, PotionEffectType.JUMP_BOOST);
            } else if (entity != null) {
                restoreMobEffects(entity, uid);
            } else {
                originalMobEffects.remove(uid);
            }

            if (player != null) {
                plugin.getParticleManager().cancelAura(uid);
            }
        }

        // A snapshot can outlive the frozen-entity map only if a lifecycle
        // event raced with shutdown; clear it explicitly so disable leaves no
        // Freeze-owned state behind.
        originalMobEffects.clear();
        frozenEntities.clear();
        frozenTaskIds.clear();
    }
}
