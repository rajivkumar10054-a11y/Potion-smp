package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Handles Regen Potion's active ability (Vitality Surge).
 * The activation trigger is owned by RegenAbility (Shift + the trigger of
 * the slot containing Regen); this manager only handles the existing surge
 * state, launch, effects, cooldown window, and Mace Dive charge.
 */
public class RegenAbilityManager {

    private final PotionSMP plugin;

    // Players currently airborne+charged for a bonus Mace Dive hit
    private final Set<UUID> chargedForDive = new HashSet<>();

    // Players inside their Surge window: opened by the one valid activation
    // and open for durationTicks (10s by default). While it is open every
    // further activation attempt is ignored (one launch per window). Closes
    // automatically once the window's duration elapses.
    private final Set<UUID> windowActive = new HashSet<>();

    // One scheduled task per player for each timed piece of Surge state, so
    // cleanup can cancel them and they can never be duplicated.
    private final Map<UUID, BukkitTask> windowTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> endAnimationTasks = new HashMap<>();

    public RegenAbilityManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isWindowActive(UUID uuid) {
        return windowActive.contains(uuid);
    }

    /**
     * Opens the Surge window for durationTicks. Called once per accepted
     * activation (via launch(..., true)); RegenAbility rejects any attempt
     * made while the window is already open, so the window is never
     * extended or reopened mid-window.
     *
     * At natural expiration this only clears the window state, so the next
     * valid activation can start a brand-new window. The cosmetic end
     * animation is handled separately by scheduleEndAnimation(). No launch
     * is ever scheduled here — only this cleanup.
     */
    private void openWindow(UUID uuid, int durationTicks) {
        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG)
        final int diagOpenTick = plugin.getServer().getCurrentTick();
        final long diagOpenMs = System.currentTimeMillis();
        plugin.getLogger().info("[REGEN-DIAG][openWindow] OPENING: uuid=" + uuid
                + ", durationTicks=" + durationTicks
                + ", tick=" + diagOpenTick + ", ms=" + diagOpenMs
                + ", windowActiveBefore=" + windowActive.contains(uuid)
                + ", hadPreviousTask=" + windowTasks.containsKey(uuid));
        windowActive.add(uuid);
        BukkitTask previous = windowTasks.remove(uuid);
        if (previous != null) previous.cancel();
        windowTasks.put(uuid, plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getLogger().info("[REGEN-DIAG][openWindow] SCHEDULED TASK FIRED, window being removed: uuid=" + uuid
                    + ", windowWasActive=" + windowActive.contains(uuid)
                    + ", requestedDurationTicks=" + durationTicks
                    + ", elapsedTicks=" + (plugin.getServer().getCurrentTick() - diagOpenTick)
                    + ", elapsedMs=" + (System.currentTimeMillis() - diagOpenMs));
            windowTasks.remove(uuid);
            windowActive.remove(uuid);
        }, durationTicks));
        plugin.getLogger().info("[REGEN-DIAG][openWindow] OPENED: uuid=" + uuid
                + ", windowActiveNow=" + windowActive.contains(uuid));
    }

    /**
     * Schedules the cosmetic end-of-window collapse animation (one task per
     * player; cancelled by closeWindow/clearTransient).
     */
    public void scheduleEndAnimation(Player player, int durationTicks) {
        UUID uuid = player.getUniqueId();
        BukkitTask previous = endAnimationTasks.remove(uuid);
        if (previous != null) previous.cancel();
        endAnimationTasks.put(uuid, plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            endAnimationTasks.remove(uuid);
            plugin.getVitalityParticleRenderer().playEndAnimation(player);
        }, durationTicks));
    }

    /** Cleanup — e.g. on unequip, death, or quit. */
    public void closeWindow(UUID uuid) {
        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG)
        plugin.getLogger().info("[REGEN-DIAG][closeWindow] uuid=" + uuid
                + ", windowActiveBeforeRemoval=" + windowActive.contains(uuid)
                + ", hadWindowTask=" + windowTasks.containsKey(uuid)
                + ", tick=" + plugin.getServer().getCurrentTick()
                + ", ms=" + System.currentTimeMillis());
        windowActive.remove(uuid);
        BukkitTask window = windowTasks.remove(uuid);
        if (window != null) window.cancel();
        BukkitTask anim = endAnimationTasks.remove(uuid);
        if (anim != null) anim.cancel();
    }

    /**
     * Clears all short-lived Vitality Surge state for lifecycle events such as
     * death or disconnect. Equipped potion slots remain untouched, so the
     * normal passive can still be reapplied after respawn/reconnect.
     */
    public void clearTransient(UUID uuid) {
        plugin.getLogger().info("[REGEN-DIAG][Manager] clearTransient removing charge: uuid=" + uuid
                + ", chargedBefore=" + chargedForDive.contains(uuid));
        chargedForDive.remove(uuid);
        closeWindow(uuid);
    }

    public boolean isChargedForDive(UUID uuid) {
        return chargedForDive.contains(uuid);
    }

    public void clearCharge(UUID uuid) {
        plugin.getLogger().info("[REGEN-DIAG][Manager] clearCharge removing charge: uuid=" + uuid
                + ", chargedBefore=" + chargedForDive.contains(uuid));
        chargedForDive.remove(uuid);
    }

    /**
     * Performs the launch/jump + regen/glow effects without touching the
     * Surge window. Kept for API compatibility; RegenAbility uses the
     * 5-arg overload below.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier) {
        launch(player, heightBlocks, durationTicks, regenAmplifier, false);
    }

    /**
     * Performs the launch/jump + regen/glow effects. RegenAbility calls this
     * once per accepted activation with openWindow=true, which opens the
     * one Surge window (durationTicks long) before launching. Attempts made
     * while a window is open never reach this method.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier, boolean openWindow) {
        UUID uid = player.getUniqueId();

        if (openWindow) openWindow(uid, durationTicks);

        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));

        chargedForDive.add(uid);
        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG)
        plugin.getLogger().info("[REGEN-DIAG][launch] charge added: player=" + player.getName()
                + ", chargedForDive=" + chargedForDive.contains(uid)
                + ", fallDistance=" + player.getFallDistance()
                + ", onGround=" + player.isOnGround()
                + ", openWindow=" + openWindow);

        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, durationTicks, regenAmplifier, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationTicks, 0, false, false));

        Location loc = player.getLocation();
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 1f, 1.2f);

        runLandingWatcher(player);
    }

    /**
     * Starts another Mace Dive launch inside the already-open Surge window.
     * This does not reopen/extend the window or restart the cooldown.
     */
    public boolean relaunchWithinWindow(Player player, int heightBlocks) {
        UUID uid = player.getUniqueId();
        if (!windowActive.contains(uid) || !player.isOnGround()) {
            return false;
        }

        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));
        chargedForDive.add(uid);

        plugin.getLogger().info("[REGEN-DIAG][relaunch] charge added: player=" + player.getName()
                + ", chargedForDive=" + chargedForDive.contains(uid)
                + ", onGround=" + player.isOnGround());

        runLandingWatcher(player);
        return true;
    }

    private void runLandingWatcher(Player player) {
        UUID uid = player.getUniqueId();
        new BukkitRunnable() {
            int ticks = 0;
            boolean hasLeftGround = false;

            @Override
            public void run() {
                if (!player.isOnline() || ticks > 200) {
                    plugin.getLogger().info("[REGEN-DIAG][landingWatcher] EXIT without removing charge: player=" + player.getName()
                            + ", online=" + player.isOnline() + ", ticks=" + ticks
                            + ", hasLeftGround=" + hasLeftGround
                            + ", chargedForDive=" + chargedForDive.contains(uid));
                    cancel();
                    return;
                }

                // A successful Mace Dive already consumed the charge. Nothing
                // else in this watcher should act on that same launch.
                if (!chargedForDive.contains(uid)) {
                    cancel();
                    return;
                }

                // Do not treat the launch's initial server-side ground state
                // as a landing. First require an actual onGround -> airborne
                // transition.
                if (!player.isOnGround()) {
                    hasLeftGround = true;
                } else if (hasLeftGround) {
                    plugin.getLogger().info("[REGEN-DIAG][landingWatcher] REMOVING charge after genuine landing: player=" + player.getName()
                            + ", ticks=" + ticks
                            + ", chargedBefore=" + chargedForDive.contains(uid)
                            + ", fallDistance=" + player.getFallDistance()
                            + ", onGround=" + player.isOnGround());
                    chargedForDive.remove(uid);
                    cancel();
                    return;
                }

                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ── Mace Dive damage: vanilla 1.21.11 Mace smash-attack calculation ──
    // Vanilla Mace hit = 6.0 base attack damage + smash bonus from the
    // attacker's fall distance. The bonus applies only when fallDistance is
    // greater than 1.5 and the attacker is not gliding (vanilla
    // MaceItem#canSmashAttack), and has no upper cap:
    //   fall <= 3        : 4 * fall
    //   3 < fall <= 8    : 12 + 2 * (fall - 3)      (= 2*fall + 6)
    //   fall > 8         : 22 + (fall - 8)          (= fall + 14)
    // Density (an enchantment on the Mace item) does not apply: there is no
    // Mace item here. Critical-hit multiplication is not part of the smash
    // calculation and is not applied.
    private static final double MACE_BASE_DAMAGE = 6.0;
    private static final double SMASH_MIN_FALL   = 1.5;

    /**
     * Damage for the already-selected Mace Dive target, from the player's
     * actual fall distance. Paper's getFallDistance() is the same
     * fallDistance field vanilla's Mace reads: it only accumulates while the
     * player moves DOWN and is reset on ground contact, so the upward launch
     * is never counted, only the descent from the apex to the impact.
     */
    public double calculateMaceDiveDamage(Player player) {
        return MACE_BASE_DAMAGE + smashBonus(player.getFallDistance(), player.isGliding());
    }

    private static double smashBonus(double fallDistance, boolean gliding) {
        if (gliding || fallDistance <= SMASH_MIN_FALL) return 0.0;
        if (fallDistance <= 3.0) return 4.0 * fallDistance;
        if (fallDistance <= 8.0) return 12.0 + 2.0 * (fallDistance - 3.0);
        return 22.0 + (fallDistance - 8.0);
    }

    public void triggerMaceDive(Player player, LivingEntity target, double diveDamage) {
        UUID uid = player.getUniqueId();
        // TEMPORARY DIAGNOSTIC ONLY (REGEN-DIAG)
        plugin.getLogger().info("[REGEN-DIAG][triggerMaceDive] ENTER (charge removed here): attacker=" + player.getName()
                + ", chargedBefore=" + chargedForDive.contains(uid));
        chargedForDive.remove(uid);

        ProgrammaticDamageGuard.beginSuppression(uid);
        try {
            final double diagHealthBefore = target.getHealth();
            plugin.getLogger().info("[REGEN-DIAG][triggerMaceDive] BEFORE target.damage: attacker=" + player.getName()
                    + ", target=" + target.getName()
                    + ", targetClass=" + target.getClass().getName()
                    + ", targetIsPlayer=" + (target instanceof Player)
                    + ", calculatedDiveDamage=" + diveDamage
                    + ", attackerFallDistance=" + player.getFallDistance()
                    + ", attackerOnGround=" + player.isOnGround()
                    + ", targetHealth=" + diagHealthBefore
                    + ", guardSuppressed=" + ProgrammaticDamageGuard.isSuppressed(uid));
            target.damage(diveDamage, player);
            plugin.getLogger().info("[REGEN-DIAG][triggerMaceDive] AFTER target.damage: call completed, target=" + target.getName()
                    + ", targetHealthBefore=" + diagHealthBefore
                    + ", targetHealthAfter=" + target.getHealth()
                    + ", targetNoDamageTicks=" + target.getNoDamageTicks());
        } finally {
            ProgrammaticDamageGuard.endSuppression(uid);
        }

        Location loc = target.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 1, 0), 25, 0.6, 0.6, 0.6, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 30, 0.6, 0.4, 0.6, 0.3);

        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI * i) / 30;
            double x = loc.getX() + 1.5 * Math.cos(angle);
            double z = loc.getZ() + 1.5 * Math.sin(angle);
            loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, x, loc.getY() + 0.1, z, 1, 0, 0, 0, 0);
        }

        loc.getWorld().playSound(loc, Sound.ITEM_MACE_SMASH_GROUND, 1.2f, 1f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 0.5f);
    }
}
