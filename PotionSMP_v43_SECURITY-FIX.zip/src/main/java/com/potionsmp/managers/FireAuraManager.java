package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Manages the Fire Potion's "Inferno Rage" active ability.
 * Pure aura effect - no blocks are placed or modified. A moving circular zone
 * around the player damages + ignites any player/mob standing inside it,
 * visualized with particles only.
 */
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();
    private final Random random = new Random();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        UUID uid = player.getUniqueId();
        double dps = plugin.getConfig().getDouble("potions.fire.damage-per-second", 2.0);

        Integer existing = activeTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable auraTask = new BukkitRunnable() {
            int ticks = 0;
            // Visual-only rotation state (does not affect damage/timing logic below).
            double rotation = random.nextDouble() * 360.0;

            @Override
            public void run() {
                if (ticks >= durationTicks || !player.isOnline()) {
                    activeTasks.remove(uid);
                    cancel();
                    return;
                }

                Location center = player.getLocation();

                if (ticks % 20 == 0) {
                    for (Entity e : center.getWorld().getNearbyEntities(center, radius, 2.5, radius)) {
                        if (e instanceof LivingEntity le && !e.getUniqueId().equals(uid)) {
                            ProgrammaticDamageGuard.beginSuppression(uid);
                            try {
                                le.damage(dps, player);
                            } finally {
                                ProgrammaticDamageGuard.endSuppression(uid);
                            }
                            le.setFireTicks(40);
                        }
                    }
                }

                // Smooth rotation advances every tick, independent of draw throttling,
                // so the ring's spin stays fluid even though it's only rendered every
                // RING_INTERVAL_TICKS ticks.
                rotation = (rotation + ROTATION_PER_TICK) % 360.0;

                if (ticks % RING_INTERVAL_TICKS == 0) {
                    drawSectorRing(player, center, rotation);
                }

                ticks++;
            }
        };

        int taskId = auraTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        activeTasks.put(uid, taskId);
    }

    // ── Flat ring geometry ──────────────────────────────────────────────
    // Fixed visual radius/diameter per spec — independent of the gameplay
    // damage radius (potions.fire.active-fire-radius), which is untouched.
    // 10-block diameter = 5-block radius.
    private static final double RING_RADIUS = 5.0;
    // Feet / ground level offset — a hair off the ground to avoid z-fighting.
    private static final double Y_OFFSET = 0.1;
    // Draw the ring 5x/second (every 4 ticks) instead of every tick (20x/sec)
    // — keeps particle volume low and avoids the FPS drop seen in testing.
    private static final int RING_INTERVAL_TICKS = 4;

    // Four separated 90° sections, each with a small gap so they read as
    // distinct arcs rather than one solid circle.
    private static final int ARC_COUNT = 4;
    private static final double SECTION_SIZE = 360.0 / ARC_COUNT; // 90°
    private static final double ARC_GAP = 12.0;                   // gap per section
    private static final double ARC_SPAN = SECTION_SIZE - ARC_GAP; // visible arc size
    private static final int ARC_POINTS = 6;                       // points per arc

    // Smooth continuous spin: 360° over 36 ticks (1.8s) at 10°/tick.
    private static final double ROTATION_PER_TICK = 5.0;

    private static final Particle.DustOptions ORANGE_CORE =
            new Particle.DustOptions(Color.fromRGB(255, 120, 20), 0.7f);
    private static final Particle.DustOptions GOLD_CORE =
            new Particle.DustOptions(Color.fromRGB(255, 190, 40), 0.6f);
    private static final Particle.DustOptions DEEP_RED =
            new Particle.DustOptions(Color.fromRGB(150, 15, 10), 0.7f);

    // Inferno Spiral geometry (visual only; independent of the damage radius)
    private static final int SPIRAL_ARMS = 2;
    private static final int SPIRAL_POINTS = 7;            // points per arm per draw
    private static final double SPIRAL_HEIGHT = 2.3;       // matches the 2.5 vertical damage band
    private static final double SPIRAL_TOP_RADIUS = 3.8;   // arms taper inward as they rise
    private static final double SPIRAL_TURN_DEG = 150.0;   // angular travel base -> top

    /**
     * Inferno Spiral — two flame arms spiral upward from the ground at the
     * old ring radius, tapering inward as they rise. Orange/gold flame and
     * dust with sparse deep-red accents at the base and a single ember
     * drifting off an arm tip. The arms are thin (7 points each), so the
     * player and targets stay visible through the gaps. ~24 particles per
     * draw (every RING_INTERVAL_TICKS ticks).
     *
     * Visual only: this method never touches damage, targeting or timing.
     */
    private void drawSectorRing(Player player, Location center, double rotation) {
        // Don't render for a dead player; gameplay timing is unaffected.
        if (player.isDead()) return;

        World world = center.getWorld();
        if (world == null) return;
        double baseY = center.getY() + Y_OFFSET;

        for (int arm = 0; arm < SPIRAL_ARMS; arm++) {
            double armOffset = arm * (360.0 / SPIRAL_ARMS);
            for (int point = 0; point < SPIRAL_POINTS; point++) {
                double t = point / (double) (SPIRAL_POINTS - 1); // 0 = base, 1 = tip
                double angle = Math.toRadians(rotation + armOffset + SPIRAL_TURN_DEG * t);
                double radius = RING_RADIUS + (SPIRAL_TOP_RADIUS - RING_RADIUS) * t;
                double x = center.getX() + radius * Math.cos(angle);
                double z = center.getZ() + radius * Math.sin(angle);
                double y = baseY + SPIRAL_HEIGHT * t;

                // Flame on every point, dust accents interleaved for colour.
                world.spawnParticle(Particle.FLAME, x, y, z, 1, 0, 0, 0, 0);
                if (point % 2 == 0) {
                    world.spawnParticle(Particle.DUST, x, y, z, 1,
                            (point % 4 == 0) ? ORANGE_CORE : GOLD_CORE);
                } else if (point <= 1) {
                    world.spawnParticle(Particle.DUST, x, y, z, 1, DEEP_RED);
                }
            }
        }

        // One ember rising off an arm tip, slightly outward — sparse accent.
        if (random.nextInt(2) == 0) {
            double tipAngle = Math.toRadians(rotation + SPIRAL_TURN_DEG);
            double ex = center.getX() + SPIRAL_TOP_RADIUS * Math.cos(tipAngle);
            double ez = center.getZ() + SPIRAL_TOP_RADIUS * Math.sin(tipAngle);
            world.spawnParticle(Particle.SMALL_FLAME, ex, baseY + SPIRAL_HEIGHT, ez, 0, 0, 0.06, 0, 1);
        }

        // Small center wisp so the player still reads as "on fire".
        world.spawnParticle(Particle.FLAME, center.clone().add(0, 0.1, 0), 2, 0.2, 0, 0.2, 0.01);
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        activeTasks.clear();
    }
}
