package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * First-join potion reveal (centre-screen title animation, no inventory GUI).
 *
 * <p><b>Reward-state model (unchanged from v40/v41):</b>
 * <ul>
 *   <li>{@code first_spin_pending} (player PDC, STRING) = the server-chosen potion id,
 *       written BEFORE the animation. It is authoritative: a valid value is never
 *       re-rolled, only replayed.</li>
 *   <li>{@code first_spin_awarded} (player PDC, BOOLEAN) = reward completed. Written
 *       strictly AFTER the item is in the inventory or dropped; the pending value is
 *       removed in the same step. If set, the player is never eligible again.</li>
 *   <li>Interrupted (quit / shutdown / crash) before delivery: nothing was given,
 *       pending remains, and the next join replays the animation for the SAME potion.</li>
 * </ul>
 *
 * <p>Flow: join → {@link #evaluate} → (NEW: roll + persist pending) → title animation
 * → final reveal → {@link #deliver} (the only delivery path) → awarded written,
 * pending cleared.
 *
 * <p>All state is touched on the main thread only; one repeating task per player.
 */
public class FirstJoinSpinManager implements Listener {

    /** Single source of truth: the 12 PotionTypes, display names from the enum. */
    private static final PotionType[] POOL = PotionType.values();

    private static final long START_DELAY_TICKS = 20L; // let the client finish loading
    private static final int  ROLL_STEPS = 24;         // intermediate titles before the winner (2 full cycles)

    private final PotionSMP plugin;
    private final NamespacedKey awardedKey;
    private final NamespacedKey pendingKey;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public FirstJoinSpinManager(PotionSMP plugin) {
        this.plugin = plugin;
        this.awardedKey = new NamespacedKey(plugin, "first_spin_awarded");
        this.pendingKey = new NamespacedKey(plugin, "first_spin_pending");
        if (POOL.length != 12) {
            plugin.getLogger().warning("[FirstJoinSpin] Expected 12 potion types but found " + POOL.length + ".");
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ── Eligibility ───────────────────────────────────────────────────────

    private enum Verdict { ALREADY_AWARDED, EXISTING_PLAYER, RESUME, NEW }

    private Verdict evaluate(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();

        if (pdc.has(awardedKey, PersistentDataType.BOOLEAN)) return Verdict.ALREADY_AWARDED;

        // Interrupted earlier reveal: result already chosen and persisted, nothing delivered.
        if (pdc.has(pendingKey)) {
            String raw = null;
            try {
                raw = pdc.get(pendingKey, PersistentDataType.STRING);
            } catch (IllegalArgumentException ignored) { /* wrong stored type => treated as invalid */ }
            if (PotionType.fromId(raw) != null) return Verdict.RESUME;

            // Corrupt value: never award an unrelated potion because of it. Drop the bad
            // key and fall through to the normal eligibility checks below.
            plugin.getLogger().warning("[FirstJoinSpin] Invalid first_spin_pending value '" + raw
                + "' for " + player.getName() + "; removing it and re-checking eligibility.");
            pdc.remove(pendingKey);
        }

        // Joined this server before (i.e. existed before this feature): never eligible.
        if (player.hasPlayedBefore()) return Verdict.EXISTING_PLAYER;

        // Any other PotionSMP data on this player => not a first-timer.
        for (NamespacedKey k : pdc.getKeys()) {
            if (k.getNamespace().equals(awardedKey.getNamespace())
                    && !k.equals(awardedKey) && !k.equals(pendingKey)) {
                return Verdict.EXISTING_PLAYER;
            }
        }
        UUID id = player.getUniqueId();
        if (plugin.getSlotManager().getSlot1(id) != null || plugin.getSlotManager().getSlot2(id) != null) {
            return Verdict.EXISTING_PLAYER;
        }
        return Verdict.NEW;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (sessions.containsKey(player.getUniqueId())) return; // one animation per player

        switch (evaluate(player)) {
            case ALREADY_AWARDED -> plugin.getLogger().info("[FirstJoinSpin] Player "
                + player.getName() + " already has first-spin reward; skipping.");
            case EXISTING_PLAYER -> plugin.getLogger().info("[FirstJoinSpin] Player "
                + player.getName() + " is an existing player; skipping.");
            case RESUME -> {
                PotionType pending = PotionType.fromId(
                    player.getPersistentDataContainer().get(pendingKey, PersistentDataType.STRING));
                startSession(player, pending); // same stored winner, never re-rolled
            }
            case NEW -> {
                PotionType result = POOL[ThreadLocalRandom.current().nextInt(POOL.length)]; // equal odds
                player.getPersistentDataContainer().set(pendingKey, PersistentDataType.STRING, result.getId());
                startSession(player, result);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Session s = sessions.remove(event.getPlayer().getUniqueId());
        if (s != null) s.cancelQuietly(); // pending result stays persisted; no reward given
    }

    /** Plugin disable: cancel every task, clear runtime state. Persistent data untouched. */
    public void shutdown() {
        for (Session s : new HashSet<>(sessions.values())) s.cancelQuietly();
        sessions.clear();
    }

    private void startSession(Player player, PotionType result) {
        Session s = new Session(player.getUniqueId(), result);
        sessions.put(player.getUniqueId(), s);
        s.runTaskTimer(plugin, START_DELAY_TICKS, 1L);
    }

    // ── Title animation ───────────────────────────────────────────────────

    private static Component nameOf(PotionType type) {
        return LegacyComponentSerializer.legacySection().deserialize(type.getDisplayName());
    }

    private final class Session extends BukkitRunnable {
        private final UUID uuid;
        private final PotionType result;
        private final int startIndex;   // POOL index shown on frame 0
        private int frame = 0;          // 0..ROLL_STEPS; the last frame is the winner
        private int tick = 0;
        private int nextFrameAt = 0;
        private boolean finished = false;

        Session(UUID uuid, PotionType result) {
            this.uuid = uuid;
            this.result = result;
            int resultIndex = result.ordinal();
            // frame f shows POOL[(startIndex + f) % 12]; the last frame lands on the winner.
            this.startIndex = Math.floorMod(resultIndex - ROLL_STEPS, POOL.length);
        }

        @Override
        public void run() {
            if (finished) return;
            Player p = Bukkit.getPlayer(uuid);
            if (p == null || !p.isOnline()) { finish(); return; }

            if (tick++ < nextFrameAt) return;

            try {
                if (frame < ROLL_STEPS) {
                    double progress = (double) frame / ROLL_STEPS;
                    int delay = 3 + (int) (8.0 * progress * progress); // 3 → 11 ticks: fast, then slows
                    PotionType shown = POOL[(startIndex + frame) % POOL.length];

                    p.showTitle(Title.title(
                        nameOf(shown).decorate(TextDecoration.BOLD),
                        Component.text("◇ Rolling your first potion ◇", NamedTextColor.DARK_GRAY),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(50L * (delay + 1)), Duration.ZERO)));
                    p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 0.8f + 0.7f * (float) progress);

                    frame++;
                    nextFrameAt = tick + delay;
                } else {
                    finished = true; // set first so an exception below can never re-run delivery
                    try {
                        reveal(p);
                    } finally {
                        finish(); // always release the task and session, even if reveal/delivery throws
                    }
                }
            } catch (RuntimeException ex) {
                // Never leave a task spamming errors every tick. Pending result stays persisted
                // (awarded is only written after delivery), so the next join replays the same potion.
                plugin.getLogger().log(java.util.logging.Level.SEVERE,
                    "[FirstJoinSpin] Animation failed for " + p.getName() + "; pending result kept.", ex);
                finished = true;
                finish();
            }
        }

        private void reveal(Player p) {
            try {
                Component name = nameOf(result).decorate(TextDecoration.BOLD);
                Component title = Component.text("✦ ", NamedTextColor.GOLD, TextDecoration.BOLD)
                    .append(name)
                    .append(Component.text(" ✦", NamedTextColor.GOLD, TextDecoration.BOLD));
                p.showTitle(Title.title(
                    title,
                    Component.text("Your first-join potion", NamedTextColor.GRAY),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(2500), Duration.ofMillis(700))));
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            } catch (RuntimeException ex) {
                // Cosmetic only: a failed title must not prevent the (single) delivery.
                plugin.getLogger().log(java.util.logging.Level.WARNING,
                    "[FirstJoinSpin] Reveal title failed for " + p.getName(), ex);
            }

            deliver(p, result);
        }

        private void finish() {
            sessions.remove(uuid, this);
            cancelQuietly();
        }

        void cancelQuietly() {
            try { cancel(); } catch (IllegalStateException ignored) { /* never scheduled / already cancelled */ }
        }
    }

    // ── Reward delivery (single path) ─────────────────────────────────────

    /**
     * Delivers the real PotionSMP item (inventory-full fallback drops it nearby), then
     * writes {@code first_spin_awarded} and clears {@code first_spin_pending}. Refuses
     * to run twice for a player who is already marked awarded.
     */
    private void deliver(Player p, PotionType result) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        if (pdc.has(awardedKey, PersistentDataType.BOOLEAN)) return; // duplicate-delivery guard

        ItemStack item = ItemBuilder.buildPotion(result); // the real PotionSMP item
        Map<Integer, ItemStack> leftover = p.getInventory().addItem(item);
        if (!leftover.isEmpty()) {
            for (ItemStack rest : leftover.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), rest);
            }
        }

        // Flag only AFTER the item is in the inventory or on the ground.
        pdc.set(awardedKey, PersistentDataType.BOOLEAN, true);
        pdc.remove(pendingKey);

        // Cosmetic notice last, so a failure here can't leave the reward given but unflagged.
        if (!leftover.isEmpty()) {
            p.sendMessage("§eYour inventory was full; your potion has been dropped nearby.");
        }

        plugin.getLogger().info("[FirstJoinSpin] Player " + p.getName() + " (" + p.getUniqueId()
            + ") received " + result.name() + " potion.");
    }
}
