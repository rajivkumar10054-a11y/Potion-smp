package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class GlitchManager {

    private final PotionSMP plugin;

    // Players who cannot pick up items. This state has its own timer and is
    // intentionally independent from the System Corruption task duration.
    private final Set<UUID> noPickup = new HashSet<>();
    private final Map<UUID, BukkitTask> noPickupTasks = new HashMap<>();

    // Active corruption tasks on targets (targetUUID -> task).
    private final Map<UUID, BukkitTask> corruptionTasks = new HashMap<>();

    // Armed attackers waiting to deploy on the next valid Player hit.
    private final Map<UUID, ArmedState> armedAttackers = new HashMap<>();
    private final Map<UUID, BukkitTask> armedExpiryTasks = new HashMap<>();

    public GlitchManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean hasNoPickup(UUID uuid) {
        return noPickup.contains(uuid);
    }

    /**
     * Arms one player for one configured activation duration.
     *
     * Re-arming safely replaces both the old armed state and its expiry task.
     */
    public void armCorruption(UUID attackerUuid, int duration, int stutters) {
        cancelArmed(attackerUuid);

        ArmedState state = new ArmedState(duration, stutters);
        armedAttackers.put(attackerUuid, state);

        long expiryTicks = Math.max(0L, duration);
        BukkitTask expiryTask = new BukkitRunnable() {
            @Override
            public void run() {
                armedAttackers.remove(attackerUuid);
                armedExpiryTasks.remove(attackerUuid);
            }
        }.runTaskLater(plugin, expiryTicks);

        armedExpiryTasks.put(attackerUuid, expiryTask);
    }

    public boolean isArmed(UUID attackerUuid) {
        return armedAttackers.containsKey(attackerUuid);
    }

    /**
     * Called from CombatListener when an armed Glitch player hits an entity.
     *
     * The existing PvP-only mechanic is preserved: non-player targets do not
     * consume the armed state because corruption is only deployed on Players.
     */
    public void deployOnHit(Player attacker, Player target) {
        UUID attackerUuid = attacker.getUniqueId();
        ArmedState state = armedAttackers.remove(attackerUuid);
        cancelArmedExpiryTask(attackerUuid);

        if (state == null) return;

        applySystemCorruption(attacker, target, state.durationTicks, state.stutterCount);
    }

    public void applySystemCorruption(Player attacker, Player target,
                                       int durationTicks, int stutterCount) {
        UUID uid = target.getUniqueId();

        // Reapplying corruption to the same target replaces only that target's
        // previous corruption task.
        cancelCorruption(uid);

        // Force drop held item.
        ItemStack held = target.getInventory().getItemInMainHand();
        if (held != null && !held.getType().isAir()) {
            target.getInventory().setItemInMainHand(null);
            Item dropped = target.getWorld().dropItem(target.getLocation(), held);
            dropped.setPickupDelay(40);
            target.getWorld().spawnParticle(Particle.PORTAL,
                target.getLocation().add(0, 1, 0), 20, 0.3, 0.3, 0.3, 0.5);
            target.getWorld().playSound(target.getLocation(),
                Sound.ENTITY_ITEM_BREAK, 1f, 0.5f);
        }

        // The pickup lock gets its own configured lifetime. It is not tied to
        // the corruption task's duration.
        startNoPickup(uid);

        target.sendTitle(
            PotionUtils.colorize("&d&l⚡ SYSTEM CORRUPTED"),
            PotionUtils.colorize("&5Cannot pick up items!"),
            5, 40, 10
        );
        target.sendMessage(PotionUtils.colorize("&d⚡ System Corruption by &f" + attacker.getName()));
        target.getWorld().playSound(target.getLocation(),
            Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.3f);

        int stutterInterval = Math.max(1, durationTicks / (stutterCount + 1));

        BukkitRunnable task = new BukkitRunnable() {
            int ticks = 0;
            int stuttersDone = 0;
            final Random rand = new Random();

            @Override
            public void run() {
                if (ticks >= durationTicks || !target.isOnline()) {
                    finishCorruption(uid);
                    if (target.isOnline()) {
                        target.sendMessage(PotionUtils.colorize("&7System Corruption faded."));
                        target.getWorld().playSound(target.getLocation(),
                            Sound.BLOCK_REDSTONE_TORCH_BURNOUT, 1f, 0.8f);
                    }
                    cancel();
                    return;
                }

                Location loc = target.getLocation();

                // Glitch particles
                if (ticks % 2 == 0) {
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add(rnd(rand), rnd(rand)+1, rnd(rand)), 3,
                        new Particle.DustOptions(Color.fromRGB(150, 0, 255), 0.8f));
                    loc.getWorld().spawnParticle(Particle.DUST,
                        loc.clone().add(rnd(rand), rnd(rand)+1, rnd(rand)), 2,
                        new Particle.DustOptions(Color.fromRGB(0, 255, 220), 0.8f));
                    loc.getWorld().spawnParticle(Particle.END_ROD,
                        loc.clone().add(rnd(rand)*0.5, 1+rnd(rand), rnd(rand)*0.5),
                        1, 0, 0, 0, 0.05);
                }
                if (ticks % 10 == 0) {
                    loc.getWorld().spawnParticle(Particle.PORTAL,
                        loc.clone().add(0, 1, 0), 15, 0.5, 0.5, 0.5, 0.3);
                    loc.getWorld().playSound(loc, Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.5f, 2f);
                }

                // Micro-teleport stutter
                if (stuttersDone < stutterCount && ticks == stutterInterval * (stuttersDone + 1)) {
                    stuttersDone++;
                    double ox = (rand.nextDouble()*2-1) * (1+rand.nextDouble());
                    double oz = (rand.nextDouble()*2-1) * (1+rand.nextDouble());
                    Location stutter = loc.clone().add(ox, 0, oz);
                    stutter.setYaw(loc.getYaw());
                    stutter.setPitch(loc.getPitch());

                    if (stutter.getBlock().getType().isAir() &&
                        stutter.clone().add(0,1,0).getBlock().getType().isAir()) {
                        target.teleport(stutter);
                    }
                    loc.getWorld().spawnParticle(Particle.PORTAL, stutter, 25, 0.3, 0.5, 0.3, 0.4);
                    loc.getWorld().spawnParticle(Particle.END_ROD, stutter, 10, 0.3, 0.3, 0.3, 0.1);
                    loc.getWorld().playSound(stutter, Sound.ITEM_CHORUS_FRUIT_TELEPORT, 1f, 1.5f);
                    target.setVelocity(new Vector(
                        (rand.nextDouble()-0.5)*0.3, 0.1, (rand.nextDouble()-0.5)*0.3));
                }
                ticks++;
            }
        };

        BukkitTask scheduled = task.runTaskTimer(plugin, 0L, 1L);
        corruptionTasks.put(uid, scheduled);
    }

    /**
     * Starts/restarts the pickup lock using the configured duration.
     */
    private void startNoPickup(UUID uid) {
        cancelNoPickup(uid);

        noPickup.add(uid);

        int durationTicks = Math.max(0,
            plugin.getConfig().getInt("potions.glitch.no-pickup-duration", 200));

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                noPickup.remove(uid);
                noPickupTasks.remove(uid);
            }
        }.runTaskLater(plugin, durationTicks);

        noPickupTasks.put(uid, task);
    }

    /**
     * Removes only one player's armed state.
     */
    public void cancelArmed(UUID uid) {
        armedAttackers.remove(uid);
        cancelArmedExpiryTask(uid);
    }

    private void cancelArmedExpiryTask(UUID uid) {
        BukkitTask task = armedExpiryTasks.remove(uid);
        if (task != null) task.cancel();
    }

    /**
     * Removes only one player's active corruption task.
     */
    public void cancelCorruption(UUID uid) {
        BukkitTask task = corruptionTasks.remove(uid);
        if (task != null) task.cancel();
    }

    private void finishCorruption(UUID uid) {
        // Do not clear noPickup here: its configured duration is independent
        // from active System Corruption duration.
        corruptionTasks.remove(uid);
    }

    private void cancelNoPickup(UUID uid) {
        noPickup.remove(uid);
        BukkitTask task = noPickupTasks.remove(uid);
        if (task != null) task.cancel();
    }

    /**
     * Targeted cleanup for a single player's temporary Glitch state.
     *
     * This is used by unequip/death/quit and cannot affect another player.
     */
    public void cleanupPlayer(UUID uid) {
        cancelArmed(uid);
        cancelCorruption(uid);
        cancelNoPickup(uid);
    }

    /**
     * Explicit global cleanup for plugin disable only.
     */
    public void cancelAll() {
        for (UUID uid : new HashSet<>(corruptionTasks.keySet())) {
            cancelCorruption(uid);
        }
        for (UUID uid : new HashSet<>(noPickupTasks.keySet())) {
            cancelNoPickup(uid);
        }
        for (UUID uid : new HashSet<>(armedExpiryTasks.keySet())) {
            cancelArmed(uid);
        }

        // Defensive clearing for any state that does not currently have a task.
        corruptionTasks.clear();
        noPickupTasks.clear();
        noPickup.clear();
        armedExpiryTasks.clear();
        armedAttackers.clear();
    }

    private double rnd(Random r) {
        return (r.nextDouble()-0.5)*1.2;
    }

    private static final class ArmedState {
        private final int durationTicks;
        private final int stutterCount;

        private ArmedState(int durationTicks, int stutterCount) {
            this.durationTicks = durationTicks;
            this.stutterCount = stutterCount;
        }
    }
}
