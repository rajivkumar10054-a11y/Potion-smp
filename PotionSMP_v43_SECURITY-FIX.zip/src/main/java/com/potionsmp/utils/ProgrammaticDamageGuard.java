package com.potionsmp.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks PotionSMP-generated damage currently being attributed to each player.
 * The depth counter makes the guard safe for nested/re-entrant damage calls.
 */
public final class ProgrammaticDamageGuard {

    private static final Map<UUID, Integer> SUPPRESSION_DEPTH = new HashMap<>();

    private ProgrammaticDamageGuard() {
    }

    public static void beginSuppression(UUID uuid) {
        SUPPRESSION_DEPTH.merge(uuid, 1, Integer::sum);
    }

    public static void endSuppression(UUID uuid) {
        Integer depth = SUPPRESSION_DEPTH.get(uuid);
        if (depth == null) return;

        if (depth <= 1) {
            SUPPRESSION_DEPTH.remove(uuid);
        } else {
            SUPPRESSION_DEPTH.put(uuid, depth - 1);
        }
    }

    public static boolean isSuppressed(UUID uuid) {
        Integer depth = SUPPRESSION_DEPTH.get(uuid);
        return depth != null && depth > 0;
    }
}
