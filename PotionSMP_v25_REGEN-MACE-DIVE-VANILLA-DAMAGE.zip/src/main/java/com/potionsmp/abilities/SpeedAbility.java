package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * PASSIVE:
 * - Base Speed I always active
 * - Five consecutive perfect hits within a rolling 1.5s window → Speed IV
 * - Every further valid hit refreshes the 1.5s window and keeps Speed IV on
 * - No valid hit for 1.5s → combo resets and Speed I is restored
 * - 25% reduced iframes on hit targets
 *
 * ACTIVE – Lightning Dash:
 * - Dash in look direction
 * - Speed IV during dash
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 */
public class SpeedAbility implements Ability, Listener {

    // Consecutive perfect-hit counter per player (0–5).
    // This is dedicated combo state and is never derived from the Speed amplifier.
    private final Map<UUID, Integer> speedStacks   = new HashMap<>();
    // One combo-expiration task per player.
    private final Map<UUID, BukkitTask> comboExpirationTasks = new HashMap<>();
    // Players currently dashing
    private final Set<UUID>          dashing        = new HashSet<>();
    // Running dash trail/completion task per player, so every cleanup path
    // (unequip, death, quit) can cancel it directly instead of letting it
    // discover the missing "dashing" flag and finish as if it had completed.
    private final Map<UUID, BukkitTask> dashTasks = new HashMap<>();
    // Pending "restore passive Speed" tasks for the dash's own temporary
    // Speed IV. A newer dash boost supersedes an older one instead of both
    // fighting over the player's Speed effect.
    private final Map<UUID, BukkitTask> pendingSpeedRestore = new HashMap<>();
    private static final long COMBO_WINDOW_TICKS = 30L;
    private static final int  MAX_HITS           = 5;


    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applySpeed(plugin, player, 1);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        speedStacks.remove(uid);
        // Dash cancelled by unequip/replacement: cancel its task so it can
        // never reach the completion path (no Shockwave), and release the
        // dash Resistance the task would otherwise have cleared.
        boolean wasDashing = dashing.remove(uid);
        cancelDashTask(uid);
        if (wasDashing && player.isOnline() && !player.isDead()) {
            plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
        }
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.SPEED);
    }

    // ── Cleanup on quit / death — Multiple Dash Fix ────────────────────────
    // Ensures "dashing" (and related temp-boost state) can never get stuck
    // if the player disconnects or dies mid-dash.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uid = event.getPlayer().getUniqueId();
        dashing.remove(uid);
        cancelDashTask(uid);
        speedStacks.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uid = player.getUniqueId();

        // Minecraft clears active potion effects on death. Cancel any
        // pending Speed restore so it cannot fire while the player is dead.
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        // The stack-decay loop must also stop during the dead state;
        // PassiveReapplyListener starts a fresh, idempotent loop on respawn.
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();

        // Combo state ends with the player's effects; a stale count here
        // would make the post-respawn state disagree with the actual Speed
        // effect.
        speedStacks.remove(uid);

        // Cancel the dash task directly so death can never fall through to
        // the dash-completion path (no Shockwave from cleanup).
        dashing.remove(uid);
        cancelDashTask(uid);

        // Do not call clear(): death has already wiped the Bukkit effect, so
        // restoring the pre-PotionSMP Resistance snapshot would be wrong.
        // Discard only our bookkeeping claim; the respawn equip path will
        // create fresh ownership state.
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin != null) {
            plugin.getEffectOwnershipManager()
                .discard(player, type(), PotionEffectType.RESISTANCE);
        }
    }

    // ── Passive hit: rolling 1.5s combo → maintained Speed IV ─────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        UUID uid = player.getUniqueId();

        int previousHits = speedStacks.getOrDefault(uid, 0);
        int hits = Math.min(previousHits + 1, MAX_HITS);
        speedStacks.put(uid, hits);

        // Every valid hit (including hits after #5) refreshes the rolling
        // 1.5 second window. There is never more than one expiration task
        // per player.
        BukkitTask previous = comboExpirationTasks.remove(uid);
        if (previous != null) previous.cancel();
        scheduleComboExpiration(plugin, player);

        // Speed IV is applied once, on the transition to the fifth hit, and
        // then simply kept alive by the refreshed timer above. Hits 1-4
        // leave the passive Speed I untouched (no per-hit effect churn).
        // If the dash's own Speed IV is currently active, it is already
        // Speed IV and its restore task will pick the level matching the
        // combo state, so nothing is applied here.
        if (hits >= MAX_HITS && previousHits < MAX_HITS
                && !pendingSpeedRestore.containsKey(uid)) {
            applySpeed(plugin, player, 4);
        }

        // Reduce iframes by 25% (set to 75% of default 20)
        target.setNoDamageTicks(Math.max(0, (int)(target.getNoDamageTicks() * 0.75)));

        // Spark on hit
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0,1,0), 4, 0.2,0.2,0.2, 0.05);
    }

    /** True while this player's combo has reached the Speed IV threshold. */
    private boolean isComboSpeedIV(UUID uid) {
        return speedStacks.getOrDefault(uid, 0) >= MAX_HITS;
    }

    private void scheduleComboExpiration(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            comboExpirationTasks.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            boolean wasSpeedIV = isComboSpeedIV(uid);
            speedStacks.remove(uid);

            // Back to passive Speed I. Do not overwrite the dash's own
            // temporary Speed IV; its restore task returns to the correct
            // level (now Speed I, since the combo just ended).
            if (wasSpeedIV && !pendingSpeedRestore.containsKey(uid)) {
                applySpeed(plugin, player, 1);
            }
        }, COMBO_WINDOW_TICKS);
        comboExpirationTasks.put(uid, task);
    }

    private void applySpeed(PotionSMP plugin, Player player, int level) {
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, level - 1, false, false));
    }

    /**
     * Applies the dash's TIME-LIMITED Speed IV (never Integer.MAX_VALUE) and
     * schedules a restore once it naturally expires. The restore returns to
     * whatever the current combo state dictates: Speed IV if a maintained
     * combo is still active, otherwise passive Speed I. The dash therefore
     * never ends, extends or resets the combo's Speed IV; that is governed
     * solely by the combo timer.
     */
    private void applyTemporarySpeed(PotionSMP plugin, Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, durationTicks, amplifier, false, false));

        BukkitTask restore = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            pendingSpeedRestore.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            applySpeed(plugin, player, isComboSpeedIV(uid) ? 4 : 1);
        }, durationTicks);

        pendingSpeedRestore.put(uid, restore);
    }

    private void cancelDashTask(UUID uid) {
        BukkitTask dash = dashTasks.remove(uid);
        if (dash != null) dash.cancel();
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Speed IV + 20% damage reduction during dash. Speed IV is applied
        // as a temporary boost (via applyTemporarySpeed) so the level that
        // matches the current combo state is restored once the dash's speed
        // window ends, instead of being left with no Speed effect at all.
        applyTemporarySpeed(plugin, player, 3, 40);
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        BukkitTask dashTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                // DASH CANCELLATION / CLEANUP: the player left, died, or the
                // dash flag was removed (Speed unequipped/replaced). Cleanup
                // never triggers the Shockwave.
                if (!player.isOnline() || player.isDead() || !dashing.contains(uid)) {
                    if (player.isOnline() && !player.isDead()) {
                        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    dashTasks.remove(uid);
                    cancel(); return;
                }
                // NORMAL DASH COMPLETION (1.8s): the only Shockwave path.
                if (ticks >= 36) {
                    triggerShockwave(plugin, player);
                    plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
                    dashing.remove(uid);
                    dashTasks.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2,0.2,0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc, 2, 0.3,0.1,0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
        dashTasks.put(uid, dashTask);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world  = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg    = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle)*radius, 0.1, Math.sin(angle)*radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1,0.1,0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK,   p, 1, 0,0,0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            ProgrammaticDamageGuard.beginSuppression(player.getUniqueId());
            try {
                le.damage(dmg, player);
            } finally {
                ProgrammaticDamageGuard.endSuppression(player.getUniqueId());
            }
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }
}
