package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * ⛏ Haste Potion
 *
 * PASSIVE:
 * - Held pickaxe gets Efficiency III + Fortune II (refreshed every 5 ticks)
 * - Haste I always active (attack speed +10%)
 *
 * ACTIVE – Haste Rush (10s, 45s CD):
 * - Held pickaxe gets Efficiency 10 + Fortune 5 + Unbreaking 10 (+ rename)
 * - After 10s (or as soon as the item leaves the main hand), the item is
 *   handed back to its pre-Rush state
 *
 * ── Item-restoration design ─────────────────────────────────────────────
 * Every pickaxe Haste modifies (passively or via Rush) is stamped with a
 * random per-modification ID in its PersistentDataContainer, alongside a
 * full ItemStack clone taken the instant before Haste touched it (the
 * "snapshot") and a record of exactly which enchantments / name Haste
 * itself set. The tag identifies the item — never its slot, type,
 * enchant levels or name.
 *
 * Temporary modifications are valid ONLY while the tagged item is in the
 * main hand and Haste is equipped. reconcile() enforces that; the moment
 * it is violated the tagged item is found wherever it is (inventory,
 * offhand, cursor, open container, dropped item, item frame) and reverted:
 * the tag is removed and every property Haste itself set is put back to
 * its snapshot value — but only if it still holds the value Haste gave it,
 * so anything the player legitimately changed afterwards (durability wear,
 * anvil changes, other data) is preserved, and unrelated data is never
 * touched. A record whose item cannot currently be located is kept as an
 * "orphan" and retried instead of being silently dropped.
 *
 * Two layers per player (Rush sits on top of passive, so Rush is always
 * reverted first):
 *  - passiveTracked: pickaxe carrying passive Efficiency III / Fortune II.
 *  - rushTracked:    pickaxe carrying Rush's enchants + rename (its
 *    snapshot may already include the passive layer, which is correct).
 *
 * Every Haste task is stored per player UUID (passiveLoop, rushEndTask,
 * rushParticleTask) and Rush tasks carry a per-activation token so a stale
 * task can never touch a newer Rush. Haste never uses the shared
 * ParticleManager, so it never cancels another potion's aura.
 *
 * The Rush boss bar is Haste-owned too (rushBar, one per player, stamped
 * with the Rush token). It is created here and removed here; the shared
 * BossBarManager is not used, so it can never remove another potion's bar
 * and a stale token can never remove a newer Rush's bar.
 *
 * Crash safety: besides the in-memory {@link Tracked} record, every
 * modified item carries a small item-local recovery record in its own PDC
 * (haste_recovery_passive / haste_recovery_rush / haste_recovery_rush_oname /
 * haste_recovery_rush_aname): ONLY the original levels of the enchantments
 * Haste set and, for Rush, the original and applied display names. No
 * ItemStack or ItemMeta is ever serialized. It is written in the same
 * setItemMeta as the modification, and removed by the same revert that
 * undoes it. After a crash the memory record is gone but the item still
 * carries its tag + recovery record, so any marked item that is met (join
 * scan, held item, pickup, drop, click, container open, entity load) with
 * no live record is reverted from its own recovery record - through the
 * same revertMeta() as normal restoration, so durability and every
 * unrelated property stay as they are.
 */
public class HasteAbility implements Ability, Listener {

    private static final String PASSIVE_TAG = "haste_passive_id";
    private static final String RUSH_TAG    = "haste_rush_id";
    // Item-local crash-recovery record (same plugin namespace as the tags).
    private static final String REC_PASSIVE    = "haste_recovery_passive";
    private static final String REC_RUSH       = "haste_recovery_rush";
    private static final String REC_RUSH_ONAME = "haste_recovery_rush_oname"; // original name (absent = none)
    private static final String REC_RUSH_ANAME = "haste_recovery_rush_aname"; // name Rush set (absent = none)
    /** Max unlocatable records kept per player (oldest dropped first). */
    private static final int MAX_ORPHANS = 8;

    /**
     * A snapshot of an item Haste modified, keyed by the ID tagged onto it.
     * {@code applied} = the enchantments Haste itself set (and the level it
     * set); {@code appliedName} = the display name Rush set (null if none).
     */
    private static final class Tracked {
        final String tag;
        final String trackId;
        final Map<Enchantment, Integer> applied;
        /** Level of each applied enchantment BEFORE Haste touched it (absent = 0). */
        final Map<Enchantment, Integer> origLevels;
        /** Custom name before Rush renamed the item (null = none). */
        final Component origName;
        final Component appliedName;
        Tracked(String tag, String trackId, Map<Enchantment, Integer> applied,
                Map<Enchantment, Integer> origLevels, Component origName, Component appliedName) {
            this.tag = tag;
            this.trackId = trackId;
            this.applied = applied;
            this.origLevels = origLevels;
            this.origName = origName;
            this.appliedName = appliedName;
        }
    }

    /** The Haste-owned Rush boss bar plus the Rush token it belongs to. */
    private static final class RushBar {
        final Object token;
        final BossBar bar;
        RushBar(Object token, BossBar bar) { this.token = token; this.bar = bar; }
    }

    /** Where a record was found: which player owns it and in which collection. */
    private static final class Located {
        static final int RUSH = 0, PASSIVE = 1, ORPHAN = 2;
        final UUID owner;
        final Tracked rec;
        final int kind;
        Located(UUID owner, Tracked rec, int kind) { this.owner = owner; this.rec = rec; this.kind = kind; }
    }

    private final Set<UUID> rushActive              = new HashSet<>();
    // Tracks the running passive loop per player so a duplicate onEquip()
    // call cancels the old loop instead of leaving two running at once.
    private final Map<UUID, BukkitTask> passiveLoop = new HashMap<>();
    // The scheduled "Rush end" restoration task, so it can be cancelled if
    // Haste is unequipped (or the player quits/dies) before Rush ends.
    private final Map<UUID, BukkitTask> rushEndTask = new HashMap<>();
    // The Rush particle/aura task (Haste-owned; never the ParticleManager).
    private final Map<UUID, BukkitTask> rushParticleTask = new HashMap<>();
    // Identity of the current Rush activation; Rush tasks compare against it
    // so a stale task can never act on a newer Rush.
    private final Map<UUID, Object> rushToken       = new HashMap<>();
    // The exact pickaxe currently carrying the passive enchants, and its
    // state from immediately before Haste touched it.
    private final Map<UUID, Tracked> passiveTracked = new HashMap<>();
    // The exact pickaxe currently carrying Rush's enchants, and its state
    // from immediately before Rush touched it.
    private final Map<UUID, Tracked> rushTracked    = new HashMap<>();
    // Records whose tagged item could not be located when restoration was
    // attempted. Kept and retried instead of being discarded.
    private final Map<UUID, List<Tracked>> orphans  = new HashMap<>();
    // Players with a next-tick reconcile already queued.
    private final Set<UUID> pendingReconcile        = new HashSet<>();
    // Players with a foreign/stale-marker inventory check already queued.
    private final Set<UUID> pendingForeign          = new HashSet<>();
    // The Haste-owned Rush boss bar (one per player, stamped with the Rush
    // token). Never the shared BossBarManager.
    private final Map<UUID, RushBar> rushBar        = new HashMap<>();


    @Override
    public PotionType type() { return PotionType.HASTE; }

    // ── Equip ─────────────────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startPassiveLoop(plugin, player);
        if (!PotionUtils.isQuiet()) {
            player.sendMessage(PotionUtils.colorize("&6⛏ Haste Potion passive active!"));
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        cancelTask(passiveLoop, uid);
        endRushState(uid);

        // Restore Rush's modification first (it sits "on top of" the
        // passive one), then the passive one. Anything not currently
        // locatable is kept as an orphan and retried later.
        settleTracked(player);
        player.updateInventory();

        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
    }

    // ── Death ────────────────────────────────────────────────────────────
    // Restore tracked items BEFORE they become permanent death drops (or,
    // with keepInventory, before they stay in the inventory).

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        Player player = event.getEntity();
        UUID uid = player.getUniqueId();
        if (!hasRecords(uid) && !passiveLoop.containsKey(uid)) return;

        cancelTask(passiveLoop, uid);
        endRushState(uid);
        pendingReconcile.remove(uid);

        try {
            List<ItemStack> drops = event.getDrops();
            for (int i = 0; i < drops.size(); i++) {
                ItemStack restored = settleLoose(drops.get(i));
                if (restored != null) drops.set(i, restored);
            }
        } catch (UnsupportedOperationException ignored) {
            // Immutable drop list: the next-tick ground scan below covers it.
        }

        // keepInventory (or an item that wasn't in the drop list): whatever
        // is still recorded is restored wherever it currently is.
        settleTracked(player);

        // Minecraft already wiped potion effects on death; just drop our claim.
        plugin.getEffectOwnershipManager().discard(player, type(), PotionEffectType.HASTE);

        if (orphans.containsKey(uid)) {
            // Death drops become Item entities right after this event.
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                Player p = plugin.getServer().getPlayer(uid);
                if (p != null) retryOrphans(p);
            });
        }
    }

    // ── Disconnect ───────────────────────────────────────────────────────
    // A player's inventory NBT is saved on quit, so any Haste enchants
    // still on an item at that moment would otherwise become permanent.
    // Inventory is still accessible synchronously during this event.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();

        cancelTask(passiveLoop, uid);
        boolean wasRush = endRushState(uid);
        pendingReconcile.remove(uid);

        settleTracked(player);
        retryOrphans(player);
        orphans.remove(uid); // player is leaving; nothing further can be done

        if (wasRush && plugin != null) {
            plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
        }
    }

    // ── Plugin disable / restart safety ─────────────────────────────────
    // A player's inventory is saved to disk on a normal server shutdown too
    // (not just on quit), so any tracked pickaxe still enchanted at that
    // moment would otherwise survive a restart permanently. Called from
    // PotionSMP#onDisable(). Also cancels every remaining Haste task.

    public void restoreAllTrackedItems(PotionSMP plugin) {
        Set<UUID> ids = new HashSet<>();
        ids.addAll(passiveTracked.keySet());
        ids.addAll(rushTracked.keySet());
        ids.addAll(orphans.keySet());
        ids.addAll(passiveLoop.keySet());
        ids.addAll(rushEndTask.keySet());
        ids.addAll(rushParticleTask.keySet());
        ids.addAll(rushBar.keySet());
        ids.addAll(rushActive);

        for (UUID uid : ids) {
            // One player's failure must never stop the others from being
            // restored: this is the last chance before player data is saved.
            try {
                cancelTask(passiveLoop, uid);
                endRushState(uid);            // also removes this player's Rush bar
                Player player = plugin.getServer().getPlayer(uid);
                if (player == null) continue; // offline — onQuit already handled them
                settleTracked(player);
                retryOrphans(player);
            } catch (Exception ex) {
                plugin.getLogger().log(java.util.logging.Level.WARNING,
                    "Haste: could not fully restore items for " + uid, ex);
            }
        }
        // Belt and braces: no Haste-owned bar may outlive the plugin.
        for (UUID uid : new ArrayList<>(rushBar.keySet())) removeRushBar(uid, null);
        passiveTracked.clear();
        rushTracked.clear();
        orphans.clear();
        pendingReconcile.clear();
        pendingForeign.clear();
        rushToken.clear();
        rushActive.clear();
    }

    // ── Passive loop (every 5 ticks) ──────────────────────────────────────

    private void startPassiveLoop(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        // Idempotency guard: cancel any previous loop before starting a
        // fresh one, so a duplicate onEquip() call never doubles the
        // Haste/enchant application rate.
        cancelTask(passiveLoop, uid);

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.HASTE)) {
                    // Slot was cleared without going through onUnequip():
                    // never leave temporary modifications (or the Rush bar)
                    // behind.
                    endRushState(uid);
                    if (player.isOnline()) {
                        settleTracked(player);
                        player.updateInventory();
                    }
                    plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
                    clearOwnTask(passiveLoop, uid, getTaskId());
                    cancel();
                    return;
                }

                // Keep temp item modifications confined to the main hand,
                // even while Rush is active (the passive branch below is
                // skipped during Rush).
                reconcile(player);

                if (!rushActive.contains(player.getUniqueId())) {
                    // Haste I — permanent while equipped (attack speed +10%)
                    plugin.getEffectOwnershipManager().apply(player, type(),
                        new PotionEffect(PotionEffectType.HASTE, 30, 0, false, false));
                    applyPassiveEnchants(player);
                }

                // Subtle mining aura
                Location loc = player.getLocation().add(0, 1, 0);
                if (Math.random() < 0.3) {
                    loc.getWorld().spawnParticle(Particle.CRIT,
                        loc, 2, 0.3, 0.3, 0.3, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
        passiveLoop.put(uid, task);
    }

    /**
     * Apply Efficiency III + Fortune II to whichever pickaxe is currently
     * held. The exact item is tagged with a fresh random ID the first time
     * it's touched, so it (and only it) can be found and restored later no
     * matter where it ends up.
     */
    private void applyPassiveEnchants(Player player) {
        UUID uid = player.getUniqueId();
        ItemStack held = player.getInventory().getItemInMainHand();

        Tracked tracked = passiveTracked.get(uid);
        if (tracked != null) {
            if (itemHasTrackId(held, PASSIVE_TAG, tracked.trackId)) {
                // Still the same tracked pickaxe — just make sure the
                // enchants are still there (defensive re-apply in case an
                // anvil/grindstone stripped them since the last tick).
                ensurePassiveEnchants(held, tracked);
                return;
            }
            // Tracked pickaxe is no longer the held one: restore it wherever
            // it is (or keep the record as an orphan) before tracking anew.
            releaseRecord(player, passiveTracked);
        }

        if (!isPickaxe(held)) return;
        // Stray markers (left on disk by a crash, or a copied item). A marker
        // with NO live record anywhere is stale: recover it from the item's
        // own recovery record (Rush layer first), or - for an old marker with
        // no recovery record - just strip the marker. A marker that still
        // belongs to someone's live record is left to that record.
        String[] stray = readTagIds(held);
        if (stray != null) {
            boolean liveElsewhere = false;
            if (stray[1] != null) {
                if (findRecord(RUSH_TAG, stray[1]) == null) recoverInPlace(held, RUSH_TAG, stray[1]);
                else liveElsewhere = true;
            }
            if (stray[0] != null) {
                if (findRecord(PASSIVE_TAG, stray[0]) == null) recoverInPlace(held, PASSIVE_TAG, stray[0]);
                else liveElsewhere = true;
            }
            // Don't re-snapshot another record's item as an "original".
            if (liveElsewhere) return;
        }

        ItemMeta meta = held.getItemMeta();
        if (meta == null) return;

        // Record exactly which enchants Haste itself is going to set.
        Map<Enchantment, Integer> applied = new LinkedHashMap<>();
        if (meta.getEnchantLevel(Enchantment.EFFICIENCY) < 3) applied.put(Enchantment.EFFICIENCY, 3);
        if (meta.getEnchantLevel(Enchantment.FORTUNE)    < 2) applied.put(Enchantment.FORTUNE,    2);

        String trackId = UUID.randomUUID().toString();
        Tracked created = new Tracked(PASSIVE_TAG, trackId, applied,
            levelsOf(meta, applied.keySet()), null, null);
        meta.getPersistentDataContainer().set(tagKey(PASSIVE_TAG), PersistentDataType.STRING, trackId);
        // Recovery record is persisted BEFORE any enchant is added.
        writeRecovery(meta, created);
        held.setItemMeta(meta);

        passiveTracked.put(uid, created);
        ensurePassiveEnchants(held, created);
    }

    private void ensurePassiveEnchants(ItemStack item, Tracked tracked) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        boolean changed = false;
        for (Map.Entry<Enchantment, Integer> e : tracked.applied.entrySet()) {
            if (meta.getEnchantLevel(e.getKey()) < e.getValue()) {
                meta.addEnchant(e.getKey(), e.getValue(), true);
                changed = true;
            }
        }
        if (changed) item.setItemMeta(meta);
    }

    // ── Active: Haste Rush ────────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        // Defensive: never overwrite an in-progress Rush's saved original
        // (the cooldown above should already prevent re-activation, but this
        // guards against re-entrancy from any other future call site too).
        if (rushActive.contains(uid))
            return ActivationResult.ON_COOLDOWN;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isPickaxe(item)) {
            player.sendMessage(PotionUtils.colorize("&cHold a pickaxe to activate Haste Rush!"));
            return ActivationResult.SUCCESS;
        }

        // Checked before any state is touched so Rush can never be "active"
        // without a tracked item.
        ItemMeta rushMeta = item.getItemMeta();
        if (rushMeta == null) return ActivationResult.SUCCESS;

        int dur      = plugin.getConfig().getInt("potions.haste.active-duration", 10);
        int cooldown = plugin.getConfig().getInt("potions.haste.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        rushActive.add(uid);

        // A leftover Rush record (should not exist) is settled, never overwritten.
        releaseRecord(player, rushTracked);

        // ── Save the exact original item and tag it so restoration can
        //    find it again wherever it ends up. ──────────────────────────
        Map<Enchantment, Integer> applied = new LinkedHashMap<>();
        applied.put(Enchantment.EFFICIENCY, 10);
        applied.put(Enchantment.FORTUNE,    5);
        applied.put(Enchantment.UNBREAKING, 10);

        String trackId = UUID.randomUUID().toString();
        // State before Rush touches anything (may already include the passive layer).
        Map<Enchantment, Integer> origLevels = levelsOf(rushMeta, applied.keySet());
        Component origName = rushMeta.displayName();
        rushMeta.getPersistentDataContainer().set(tagKey(RUSH_TAG), PersistentDataType.STRING, trackId);
        rushMeta.addEnchant(Enchantment.EFFICIENCY, 10, true);
        rushMeta.addEnchant(Enchantment.FORTUNE,    5,  true);
        rushMeta.addEnchant(Enchantment.UNBREAKING, 10, true);
        // Rename to show Rush active
        rushMeta.setDisplayName("§6⚡ §e" + (item.getType().name().replace("_PICKAXE","")
            .replace("_"," ")) + " §6[HASTE RUSH]");
        Component appliedName = rushMeta.displayName();
        Tracked rushRecord = new Tracked(RUSH_TAG, trackId, applied, origLevels, origName, appliedName);
        // Recovery record and Rush's modifications land in the same setItemMeta.
        writeRecovery(rushMeta, rushRecord);
        item.setItemMeta(rushMeta);
        rushTracked.put(uid, rushRecord);

        // Identity of this activation — stale tasks compare against it.
        Object token = new Object();
        rushToken.put(uid, token);
        cancelTask(rushParticleTask, uid);
        cancelTask(rushEndTask, uid);

        // Haste II during Rush
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.HASTE, dur * 20 + 5, 1, false, false));

        // ── Visual ────────────────────────────────────────────────────────
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CRIT,          loc.clone().add(0,1,0), 30, 0.7,1,0.7, 0.2);
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0,1,0), 20, 0.5,0.8,0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc.clone().add(0,1,0), 10, 0.5,0.5,0.5, 0);
        loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_USE,             1f,   1.2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.4f, 1.5f);

        player.sendTitle("§6§l⛏ HASTE RUSH", "§eEff 10 · Fortune 5 · Unbreaking 10", 5, 40, 10);
        // Haste-owned boss bar, stamped with this activation's token.
        removeRushBar(uid, null); // leftover from an earlier Rush (should not exist)
        BossBar bar = Bukkit.createBossBar("§6⛏ Haste Rush Active",
            BarColor.YELLOW, BarStyle.SEGMENTED_10);
        bar.setProgress(1.0);
        bar.addPlayer(player);
        rushBar.put(uid, new RushBar(token, bar));

        // ── Rush aura loop (tracked per player) ───────────────────────────
        BukkitTask particles = new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (rushToken.get(uid) != token || ticks >= dur * 20 || !player.isOnline()) {
                    clearOwnTask(rushParticleTask, uid, getTaskId());
                    cancel();
                    return;
                }
                Location l = player.getLocation().add(0, 0.3, 0);
                angle += 0.25;
                for (int i = 0; i < 4; i++) {
                    double a = angle + (Math.PI / 2) * i;
                    l.getWorld().spawnParticle(Particle.CRIT,
                        l.clone().add(Math.cos(a)*0.7, 0.5, Math.sin(a)*0.7),
                        1, 0, 0, 0, 0);
                }
                if (ticks % 10 == 0)
                    l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 2, 0.4,0.3,0.4, 0.05);
                ticks++;
                RushBar rb = rushBar.get(uid);
                if (rb != null && rb.token == token) {
                    rb.bar.setProgress(Math.max(0.0, 1.0 - (double) ticks / (dur * 20.0)));
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
        rushParticleTask.put(uid, particles);

        // ── Schedule Rush end ─────────────────────────────────────────────
        BukkitTask endTask = new BukkitRunnable() {
            @Override
            public void run() {
                // Stale task (Rush was ended/replaced): never touch anything.
                if (rushToken.get(uid) != token) return;

                clearOwnTask(rushEndTask, uid, getTaskId());
                rushToken.remove(uid);
                rushActive.remove(uid);
                cancelTask(rushParticleTask, uid);
                removeRushBar(uid, token);

                // Only ever restore THIS activation's record (UUID + token +
                // item identity), never a newer one.
                Tracked ended = rushTracked.get(uid);
                if (ended != null && ended.trackId.equals(trackId)) {
                    rushTracked.remove(uid, ended);
                    if (!restoreTracked(player, RUSH_TAG, ended)) addOrphan(uid, ended);
                }
                if (player.isOnline()) player.updateInventory();
                if (player.isOnline()) {
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§7Haste Rush ended. Pickaxe restored."));
                    player.getWorld().playSound(player.getLocation(),
                        Sound.BLOCK_ANVIL_LAND, 0.6f, 1.2f);
                }
            }
        }.runTaskLater(plugin, dur * 20L);
        rushEndTask.put(uid, endTask);

        return ActivationResult.SUCCESS;
    }

    // ── Task helpers ─────────────────────────────────────────────────────

    private void cancelTask(Map<UUID, BukkitTask> tasks, UUID uid) {
        BukkitTask t = tasks.remove(uid);
        if (t != null) t.cancel();
    }

    /** Removes the map entry only if it is the calling task itself. */
    private void clearOwnTask(Map<UUID, BukkitTask> tasks, UUID uid, int taskId) {
        BukkitTask t = tasks.get(uid);
        if (t != null && t.getTaskId() == taskId) tasks.remove(uid);
    }

    /**
     * Ends Rush's runtime state (flag, token, end task, particle task).
     * Item restoration and the Haste II effect are handled by the caller.
     * @return true if Rush was active.
     */
    private boolean endRushState(UUID uid) {
        boolean was = rushActive.remove(uid);
        rushToken.remove(uid);
        cancelTask(rushEndTask, uid);
        cancelTask(rushParticleTask, uid);
        removeRushBar(uid, null);
        return was;
    }

    /**
     * Removes the Haste-owned Rush bar. With a token, only the bar that
     * belongs to that exact Rush is removed (a stale token can never remove
     * a newer Rush's bar); with null, the caller is ending the player's
     * CURRENT Rush. Never touches BossBarManager or any other potion's bar.
     */
    private void removeRushBar(UUID uid, Object token) {
        RushBar rb = rushBar.get(uid);
        if (rb == null) return;
        if (token != null && rb.token != token) return;
        rushBar.remove(uid);
        try { rb.bar.removeAll(); } catch (Exception ignored) {}
    }

    // ── Tag-based exact-item tracking / restoration ─────────────────────

    private NamespacedKey tagKey(String tag) {
        return new NamespacedKey(PotionSMP.getInstance(), tag);
    }

    private boolean itemHasTrackId(ItemStack item, String tag, String trackId) {
        if (item == null || trackId == null) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        String stored = meta.getPersistentDataContainer().get(tagKey(tag), PersistentDataType.STRING);
        return trackId.equals(stored);
    }

    private boolean hasTag(ItemStack item, String tag) {
        if (item == null) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(tagKey(tag), PersistentDataType.STRING);
    }

    /**
     * Finds every item carrying the given record's ID and reverts it.
     * Searched: whole player inventory (hotbar, storage, armor, offhand),
     * cursor, the open top inventory (chest / crafting grid / ...), the
     * player's ender chest, bundles inside any of those, and - only if none
     * of those held it - dropped items / item frames / armor stands within
     * 10 blocks. Never assumes the item is still in the main hand and never
     * scans the world.
     *
     * @return true if found and restored, false if it could not be located.
     */
    private boolean restoreTracked(Player player, String tag, Tracked tracked) {
        if (tracked == null) return false;
        boolean found = false;

        PlayerInventory inv = player.getInventory();
        found |= revertInContainer(inv, tag, tracked);

        // Cursor (item picked up during an inventory interaction)
        ItemStack fromCursor = revertMatching(player.getItemOnCursor(), tag, tracked);
        if (fromCursor != null) {
            player.setItemOnCursor(fromCursor);
            found = true;
        }

        // Open top inventory (chest, crafting grid, anvil, ...)
        Inventory top = player.getOpenInventory().getTopInventory();
        if (top != null && top != inv) found |= revertInContainer(top, tag, tracked);

        // The player's own ender chest (open or not)
        found |= revertInContainer(player.getEnderChest(), tag, tracked);

        if (found) return true;

        // Dropped items / item frames / armor stands near the player
        for (Entity e : player.getNearbyEntities(10, 10, 10)) {
            if (e instanceof Item drop) {
                ItemStack r = revertMatching(drop.getItemStack(), tag, tracked);
                if (r != null) { drop.setItemStack(r); return true; }
            } else if (e instanceof ItemFrame frame) {
                ItemStack r = revertMatching(frame.getItem(), tag, tracked);
                if (r != null) { frame.setItem(r, false); return true; }
            } else if (e instanceof ArmorStand stand && stand.getEquipment() != null) {
                for (EquipmentSlot slot : STAND_SLOTS) {
                    ItemStack r = revertMatching(stand.getEquipment().getItem(slot), tag, tracked);
                    if (r != null) { stand.getEquipment().setItem(slot, r); return true; }
                }
            }
        }
        return false;
    }

    private static final EquipmentSlot[] STAND_SLOTS = {
        EquipmentSlot.HAND, EquipmentSlot.OFF_HAND, EquipmentSlot.HEAD,
        EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    /** Reverts every stack (or bundle entry) in {@code inv} carrying the record's ID. */
    private boolean revertInContainer(Inventory inv, String tag, Tracked t) {
        boolean found = false;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack r = revertMatching(contents[i], tag, t);
            if (r != null) {
                inv.setItem(i, r);
                found = true;
            }
        }
        return found;
    }

    /**
     * @return the reverted replacement if {@code it} itself (or an entry
     *         inside it, if it is a bundle) carries the record's ID; null if
     *         nothing matched. Identity is the PDC ID only.
     */
    private ItemStack revertMatching(ItemStack it, String tag, Tracked t) {
        if (it == null) return null;
        if (itemHasTrackId(it, tag, t.trackId)) return revertTemporary(t, it);
        if (it.hasItemMeta() && it.getItemMeta() instanceof BundleMeta bm && bm.hasItems()) {
            List<ItemStack> items = new ArrayList<>(bm.getItems());
            boolean changed = false;
            for (int i = 0; i < items.size(); i++) {
                if (itemHasTrackId(items.get(i), tag, t.trackId)) {
                    items.set(i, revertTemporary(t, items.get(i)));
                    changed = true;
                }
            }
            if (changed) return withBundleItems(it, items);
        }
        return null;
    }

    private ItemStack withBundleItems(ItemStack bundle, List<ItemStack> items) {
        ItemStack copy = bundle.clone();
        if (copy.getItemMeta() instanceof BundleMeta nm) {
            nm.setItems(items);
            copy.setItemMeta(nm);
        }
        return copy;
    }

    /**
     * Reverts ONLY what Haste itself changed on the live stack:
     *  - removes this record's PDC tag;
     *  - for each enchantment Haste set: if it still holds the level Haste
     *    gave it, puts it back to the snapshot's level (removing it if the
     *    snapshot had none); if the player changed it since, it is kept;
     *  - Rush's rename: restored to the snapshot's name only if the name is
     *    still the one Rush set.
     * Everything else on the live item (durability wear, lore, PDC, flags,
     * attributes, model data, other enchants, later legitimate edits) is
     * left exactly as it is, and the amount/material are the live stack's.
     */
    private ItemStack revertTemporary(Tracked t, ItemStack current) {
        ItemStack out = current.clone();
        ItemMeta meta = out.getItemMeta();
        if (meta == null) return out;
        revertMeta(meta, t);
        out.setItemMeta(meta);
        return out;
    }

    /**
     * The single revert used by every path (normal, death, quit, shutdown,
     * crash recovery). Touches only Haste-owned values on {@code meta};
     * never durability, lore, attributes, model data, flags, other PDC or
     * other enchantments. Removes this layer's tag AND recovery record.
     */
    private void revertMeta(ItemMeta meta, Tracked t) {
        for (Map.Entry<Enchantment, Integer> e : t.applied.entrySet()) {
            if (meta.getEnchantLevel(e.getKey()) == e.getValue()) {
                int origLevel = t.origLevels.getOrDefault(e.getKey(), 0);
                if (origLevel > 0) meta.addEnchant(e.getKey(), origLevel, true);
                else meta.removeEnchant(e.getKey());
            }
        }
        if (t.appliedName != null && sameName(meta.displayName(), t.appliedName)) {
            meta.displayName(t.origName); // null removes the Rush name
        }
        var pdc = meta.getPersistentDataContainer();
        pdc.remove(tagKey(t.tag));
        clearRecovery(meta, t.tag);
    }

    // ── Item-local crash-recovery record (compact PDC strings) ───────────

    private static String enchCode(Enchantment e) {
        if (e == Enchantment.EFFICIENCY) return "e";
        if (e == Enchantment.FORTUNE)    return "f";
        if (e == Enchantment.UNBREAKING) return "u";
        return null;
    }

    private static Enchantment enchByCode(String c) {
        return switch (c) {
            case "e" -> Enchantment.EFFICIENCY;
            case "f" -> Enchantment.FORTUNE;
            case "u" -> Enchantment.UNBREAKING;
            default  -> null;
        };
    }

    private static Map<Enchantment, Integer> levelsOf(ItemMeta meta, Collection<Enchantment> keys) {
        Map<Enchantment, Integer> out = new LinkedHashMap<>();
        for (Enchantment e : keys) out.put(e, meta.getEnchantLevel(e));
        return out;
    }

    private static String recKey(String tag) { return RUSH_TAG.equals(tag) ? REC_RUSH : REC_PASSIVE; }

    /** Persists the layer's original values, e.g. "e:0>3,f:0>2" (enchant:original>applied). */
    private void writeRecovery(ItemMeta meta, Tracked t) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Enchantment, Integer> e : t.applied.entrySet()) {
            String c = enchCode(e.getKey());
            if (c == null) continue;
            if (sb.length() > 0) sb.append(',');
            sb.append(c).append(':').append(t.origLevels.getOrDefault(e.getKey(), 0))
              .append('>').append(e.getValue());
        }
        var pdc = meta.getPersistentDataContainer();
        pdc.set(tagKey(recKey(t.tag)), PersistentDataType.STRING, sb.toString());
        if (RUSH_TAG.equals(t.tag)) {
            if (t.origName != null) {
                pdc.set(tagKey(REC_RUSH_ONAME), PersistentDataType.STRING,
                    GsonComponentSerializer.gson().serialize(t.origName));
            } else {
                pdc.remove(tagKey(REC_RUSH_ONAME));
            }
            if (t.appliedName != null) {
                pdc.set(tagKey(REC_RUSH_ANAME), PersistentDataType.STRING,
                    GsonComponentSerializer.gson().serialize(t.appliedName));
            } else {
                pdc.remove(tagKey(REC_RUSH_ANAME));
            }
        }
    }

    private void clearRecovery(ItemMeta meta, String tag) {
        var pdc = meta.getPersistentDataContainer();
        pdc.remove(tagKey(recKey(tag)));
        if (RUSH_TAG.equals(tag)) {
            pdc.remove(tagKey(REC_RUSH_ONAME));
            pdc.remove(tagKey(REC_RUSH_ANAME));
        }
    }

    /** Rebuilds a record from the item's own recovery keys; null if it has none. */
    private Tracked readRecovery(String tag, String trackId, ItemMeta meta) {
        var pdc = meta.getPersistentDataContainer();
        String raw = pdc.get(tagKey(recKey(tag)), PersistentDataType.STRING);
        if (raw == null) return null;
        Map<Enchantment, Integer> applied = new LinkedHashMap<>();
        Map<Enchantment, Integer> orig = new LinkedHashMap<>();
        for (String part : raw.split(",")) {
            try {
                String[] a = part.split(":");
                Enchantment e = enchByCode(a[0]);
                if (e == null) continue;
                String[] b = a[1].split(">");
                orig.put(e, Integer.parseInt(b[0]));
                applied.put(e, Integer.parseInt(b[1]));
            } catch (RuntimeException ignored) { /* skip an unreadable entry */ }
        }
        Component origName = null, appliedName = null;
        if (RUSH_TAG.equals(tag)) {
            try {
                String o = pdc.get(tagKey(REC_RUSH_ONAME), PersistentDataType.STRING);
                if (o != null) origName = GsonComponentSerializer.gson().deserialize(o);
            } catch (RuntimeException ignored) { origName = null; }
            try {
                String a = pdc.get(tagKey(REC_RUSH_ANAME), PersistentDataType.STRING);
                if (a != null) appliedName = GsonComponentSerializer.gson().deserialize(a);
            } catch (RuntimeException ignored) { appliedName = null; }
        }
        return new Tracked(tag, trackId, applied, orig, origName, appliedName);
    }

    /**
     * Crash recovery for a marker with no live record: reverts from the
     * item's own recovery record (returns the new stack). A marker with no
     * recovery record (pre-v21 item) has only the marker stripped.
     */
    private ItemStack recoverStale(ItemStack stack, String tag, String id) {
        ItemStack out = stack.clone();
        ItemMeta meta = out.getItemMeta();
        if (meta == null) return out;
        Tracked rec = readRecovery(tag, id, meta);
        if (rec != null) revertMeta(meta, rec);
        else meta.getPersistentDataContainer().remove(tagKey(tag));
        out.setItemMeta(meta);
        return out;
    }

    private void recoverInPlace(ItemStack stack, String tag, String id) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return;
        Tracked rec = readRecovery(tag, id, meta);
        if (rec != null) revertMeta(meta, rec);
        else meta.getPersistentDataContainer().remove(tagKey(tag));
        stack.setItemMeta(meta);
    }

    /**
     * True only if {@code current} is (or renders exactly like) the name
     * Rush itself applied. A different name - i.e. a legitimate later
     * rename - is never treated as Rush's.
     */
    private static boolean sameName(Component current, Component applied) {
        if (current == null || applied == null) return false;
        if (current.equals(applied)) return true;
        LegacyComponentSerializer ser = LegacyComponentSerializer.legacySection();
        return ser.serialize(current).equals(ser.serialize(applied));
    }

    // ── Record bookkeeping ──────────────────────────────────────────────

    private boolean hasRecords(UUID uid) {
        return passiveTracked.containsKey(uid) || rushTracked.containsKey(uid)
            || orphans.containsKey(uid) || rushActive.contains(uid);
    }

    private void addOrphan(UUID uid, Tracked t) {
        List<Tracked> list = orphans.computeIfAbsent(uid, k -> new ArrayList<>());
        list.add(t);
        while (list.size() > MAX_ORPHANS) list.remove(0);
    }

    /**
     * Removes the primary record from {@code map}, restores its item
     * wherever it is, and keeps it as an orphan if it can't be located.
     */
    private void releaseRecord(Player player, Map<UUID, Tracked> map) {
        UUID uid = player.getUniqueId();
        Tracked t = map.remove(uid);
        if (t != null && !restoreTracked(player, t.tag, t)) addOrphan(uid, t);
    }

    /** Rush first (it sits on top of passive), then passive. */
    private void settleTracked(Player player) {
        releaseRecord(player, rushTracked);
        releaseRecord(player, passiveTracked);
    }

    /** Retries records whose item could not be located earlier. */
    private void retryOrphans(Player player) {
        UUID uid = player.getUniqueId();
        List<Tracked> list = orphans.get(uid);
        if (list == null) return;
        for (String tag : new String[] { RUSH_TAG, PASSIVE_TAG }) {
            for (Iterator<Tracked> it = list.iterator(); it.hasNext(); ) {
                Tracked t = it.next();
                if (t.tag.equals(tag) && restoreTracked(player, tag, t)) it.remove();
            }
        }
        if (list.isEmpty()) orphans.remove(uid);
    }

    // ── Identity lookup across all records ──────────────────────────────

    /** Both marker IDs on a stack: {passiveId, rushId}, or null if it has neither. */
    private String[] readTagIds(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        var pdc = meta.getPersistentDataContainer();
        String passive = pdc.get(tagKey(PASSIVE_TAG), PersistentDataType.STRING);
        String rush    = pdc.get(tagKey(RUSH_TAG),    PersistentDataType.STRING);
        if (passive == null && rush == null) return null;
        return new String[] { passive, rush };
    }

    /** The live record (any player's primary or orphan) that owns this marker ID, or null if stale. */
    private Located findRecord(String tag, String id) {
        if (id == null) return null;
        Map<UUID, Tracked> primary = RUSH_TAG.equals(tag) ? rushTracked : passiveTracked;
        int kind = RUSH_TAG.equals(tag) ? Located.RUSH : Located.PASSIVE;
        for (Map.Entry<UUID, Tracked> e : primary.entrySet()) {
            if (id.equals(e.getValue().trackId)) return new Located(e.getKey(), e.getValue(), kind);
        }
        for (Map.Entry<UUID, List<Tracked>> e : orphans.entrySet()) {
            for (Tracked t : e.getValue()) {
                if (t.tag.equals(tag) && id.equals(t.trackId)) {
                    return new Located(e.getKey(), t, Located.ORPHAN);
                }
            }
        }
        return null;
    }

    private void removeLocated(Located loc) {
        switch (loc.kind) {
            case Located.RUSH    -> rushTracked.remove(loc.owner, loc.rec);
            case Located.PASSIVE -> passiveTracked.remove(loc.owner, loc.rec);
            default -> {
                List<Tracked> list = orphans.get(loc.owner);
                if (list != null) {
                    list.remove(loc.rec);
                    if (list.isEmpty()) orphans.remove(loc.owner);
                }
            }
        }
    }

    /**
     * Settles one loose stack (dropped item, death drop, item another
     * player is holding) by its PDC identity: a stack whose ID matches a
     * live record (any player's) is reverted through that record and the
     * record is retired; a stack whose marker matches NO record is stale
     * (e.g. left by a crash) and only has the marker stripped. Rush layer
     * first, then passive. Material/type never decides anything.
     *
     * @return the replacement stack, or null if the stack carried no marker.
     */
    private ItemStack settleLoose(ItemStack stack) {
        String[] ids = readTagIds(stack);
        if (ids == null) return null;
        String[] tags   = { RUSH_TAG, PASSIVE_TAG };
        String[] idList = { ids[1],   ids[0] };
        ItemStack result = stack;
        for (int i = 0; i < 2; i++) {
            if (idList[i] == null) continue;
            Located loc = findRecord(tags[i], idList[i]);
            if (loc == null) {
                result = recoverStale(result, tags[i], idList[i]); // crash / stale marker
                continue;
            }
            result = revertTemporary(loc.rec, result);   // also removes the marker
            removeLocated(loc);
            if (loc.kind == Located.RUSH) {
                // The Rush item is gone from its owner: let the owner's
                // reconcile end the Rush state (and its bar) next tick.
                Player owner = Bukkit.getPlayer(loc.owner);
                if (owner != null) scheduleReconcile(owner);
            }
        }
        return result;
    }

    /** settleLoose, plus the entries of a bundle. Null if nothing changed. */
    private ItemStack settleDeep(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        ItemStack result = settleLoose(stack);
        ItemStack base = result != null ? result : stack;
        if (base.getItemMeta() instanceof BundleMeta bm && bm.hasItems()) {
            List<ItemStack> items = new ArrayList<>(bm.getItems());
            boolean changed = false;
            for (int i = 0; i < items.size(); i++) {
                ItemStack inner = settleLoose(items.get(i));
                if (inner != null) { items.set(i, inner); changed = true; }
            }
            if (changed) return withBundleItems(base, items);
        }
        return result;
    }

    // ── Items held by someone other than the tracking player ────────────

    private boolean anyRecords() {
        return !passiveTracked.isEmpty() || !rushTracked.isEmpty() || !orphans.isEmpty();
    }

    /** True if every marker on the stack is this holder's own current record. */
    private boolean isOwnLive(UUID holder, String[] ids) {
        Tracked p = passiveTracked.get(holder);
        Tracked r = rushTracked.get(holder);
        boolean passiveOk = ids[0] == null || (p != null && ids[0].equals(p.trackId));
        boolean rushOk    = ids[1] == null || (r != null && ids[1].equals(r.trackId));
        return passiveOk && rushOk;
    }

    private boolean isForeignTagged(Player holder, ItemStack stack) {
        String[] ids = readTagIds(stack);
        return ids != null && !isOwnLive(holder.getUniqueId(), ids);
    }

    /** Queue a foreign/stale-marker check of this holder's items for next tick. */
    private void scheduleForeignCheck(Player holder) {
        UUID uid = holder.getUniqueId();
        if (!pendingForeign.add(uid)) return;
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) { pendingForeign.remove(uid); return; }
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            pendingForeign.remove(uid);
            if (holder.isOnline()) settleHeldBy(holder, false);
        });
    }

    /**
     * Settles every marked item this player is holding that is NOT their own
     * live tracked item (theirs are handled by reconcile): their inventory,
     * cursor, open top inventory and optionally ender chest. Used when an
     * item reaches a holder other than its tracker (pickup, another
     * player's click, join). Bounded: one player's containers only.
     */
    private void settleHeldBy(Player holder, boolean includeEnderChest) {
        UUID uid = holder.getUniqueId();
        PlayerInventory inv = holder.getInventory();
        boolean changed = settleInventory(uid, inv);

        ItemStack cursor = settleForeign(uid, holder.getItemOnCursor());
        if (cursor != null) { holder.setItemOnCursor(cursor); changed = true; }

        Inventory top = holder.getOpenInventory().getTopInventory();
        if (top != null && top != inv) changed |= settleInventory(uid, top);
        if (includeEnderChest) changed |= settleInventory(uid, holder.getEnderChest());
        if (changed) holder.updateInventory();
    }

    private boolean settleInventory(UUID holderUid, Inventory inv) {
        boolean changed = false;
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack r = settleForeign(holderUid, contents[i]);
            if (r != null) { inv.setItem(i, r); changed = true; }
        }
        return changed;
    }

    private ItemStack settleForeign(UUID holderUid, ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String[] ids = readTagIds(stack);
        if (ids != null && isOwnLive(holderUid, ids)) return null;
        return settleDeep(stack);
    }

    // ── Main-hand reconciliation ────────────────────────────────────────
    // Temporary modifications are valid only while the tagged item is in
    // the main hand AND Haste is equipped. Anything else -> restore.

    private void reconcile(Player player) {
        if (player == null || !player.isOnline()) return;
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        UUID uid = player.getUniqueId();

        retryOrphans(player);

        Tracked rush    = rushTracked.get(uid);
        Tracked passive = passiveTracked.get(uid);
        boolean rushWithoutItem = rush == null && rushActive.contains(uid);
        if (rush == null && passive == null && !rushWithoutItem) return;

        boolean equipped = plugin.getSlotManager().hasEquipped(uid, PotionType.HASTE);
        ItemStack main = player.getInventory().getItemInMainHand();
        boolean changed = false;

        // Rush first: its snapshot may itself carry the passive layer.
        if (rushWithoutItem || (rush != null && !(equipped && itemHasTrackId(main, RUSH_TAG, rush.trackId)))) {
            releaseRecord(player, rushTracked);
            // Rush can't outlive its item: end it and drop its Haste II.
            if (endRushState(uid)) {
                plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
            }
            changed = true;
        }
        if (passive != null && !(equipped && itemHasTrackId(main, PASSIVE_TAG, passive.trackId))) {
            releaseRecord(player, passiveTracked);
            changed = true;
        }
        if (changed) player.updateInventory();
    }

    /** Queue a reconcile for next tick, once inventory state has settled. */
    private void scheduleReconcile(Player player) {
        UUID uid = player.getUniqueId();
        if (!hasRecords(uid)) return;
        if (!pendingReconcile.add(uid)) return;
        PotionSMP plugin = PotionSMP.getInstance();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            pendingReconcile.remove(uid);
            reconcile(player);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player p)) return;
        scheduleReconcile(p);
        // Someone handling an item that another player's record still owns
        // (e.g. viewing/taking from that player's inventory).
        if (anyRecords() && (isForeignTagged(p, event.getCurrentItem())
                          || isForeignTagged(p, event.getCursor()))) {
            scheduleForeignCheck(p);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player p)) return;
        scheduleReconcile(p);
        if (anyRecords() && isForeignTagged(p, event.getOldCursor())) scheduleForeignCheck(p);
    }

    /** A tagged item picked up by a player that is not its tracker is settled at once. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player p)) return;
        if (anyRecords() && isForeignTagged(p, event.getItem().getItemStack())) {
            scheduleForeignCheck(p);
        }
    }

    /**
     * Nothing is tracked for a player who has just joined, so any Haste
     * marker in their inventory / ender chest is either stale (server crash
     * left it on disk) or another player's live item: settle by identity.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        settleHeldBy(event.getPlayer(), true);
    }

    /** Opening a container: settle marked items in it (crash leftovers) next tick. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (event.getPlayer() instanceof Player p) scheduleForeignCheck(p);
    }

    /**
     * Entities of a chunk that just loaded (e.g. after a restart): dropped
     * items, item frames and armor stands holding a marked item are settled
     * by identity. Bounded to the loading chunk - no world scan.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for (Entity e : event.getEntities()) {
            if (e instanceof Item drop) {
                ItemStack r = settleDeep(drop.getItemStack());
                if (r != null) drop.setItemStack(r);
            } else if (e instanceof ItemFrame frame) {
                ItemStack r = settleDeep(frame.getItem());
                if (r != null) frame.setItem(r, false);
            } else if (e instanceof ArmorStand stand && stand.getEquipment() != null) {
                for (EquipmentSlot slot : STAND_SLOTS) {
                    ItemStack r = settleDeep(stand.getEquipment().getItem(slot));
                    if (r != null) stand.getEquipment().setItem(slot, r);
                }
            }
        }
    }

    /** Item-frame placement: the item leaves the hand without a click/drop event. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        scheduleReconcile(event.getPlayer());
    }

    /** Armor-stand placement/swap: same as above. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        scheduleReconcile(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player p) scheduleReconcile(p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeldChange(PlayerItemHeldEvent event) {
        scheduleReconcile(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        scheduleReconcile(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        Item drop = event.getItemDrop();
        ItemStack restored = settleDeep(drop.getItemStack());
        if (restored != null) drop.setItemStack(restored);
        scheduleReconcile(player);
    }

    /** A tracked item that breaks no longer exists — drop its record and end Rush if it was the Rush item. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onItemBreak(PlayerItemBreakEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        ItemStack broken = event.getBrokenItem();

        Tracked rush = rushTracked.get(uid);
        if (rush != null && itemHasTrackId(broken, RUSH_TAG, rush.trackId)) {
            rushTracked.remove(uid, rush);
            if (endRushState(uid) && plugin != null) {
                plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
            }
        }
        Tracked passive = passiveTracked.get(uid);
        if (passive != null && itemHasTrackId(broken, PASSIVE_TAG, passive.trackId)) {
            passiveTracked.remove(uid, passive);
        }
        List<Tracked> list = orphans.get(uid);
        if (list != null) {
            list.removeIf(o -> itemHasTrackId(broken, o.tag, o.trackId));
            if (list.isEmpty()) orphans.remove(uid);
        }
    }

    // ── Helper ────────────────────────────────────────────────────────────

    private boolean isPickaxe(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.endsWith("_PICKAXE");
    }
}
