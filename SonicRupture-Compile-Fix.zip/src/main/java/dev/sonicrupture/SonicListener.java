package dev.sonicrupture;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class SonicListener implements Listener {

    private final SonicRupturePlugin plugin;

    public SonicListener(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    /** Right-click only: no left-click, attack, jump, sneak or command trigger. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        if (e.useItemInHand() == Event.Result.DENY) return;
        if (!plugin.items().isSonic(e.getItem())) return;

        Player p = e.getPlayer();
        Block clicked = e.getClickedBlock();
        // Player is opening a chest/door/etc., not firing.
        if (clicked != null && clicked.getType().isInteractable()) return;

        plugin.abilities().tryStartCharge(p);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        plugin.abilities().reset(p);
        plugin.projectiles().cancelFor(p.getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.abilities().reset(p);
        plugin.projectiles().cancelFor(p.getUniqueId());
    }
}
