package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class SonicItemManager {

    public static final String ITEM_ID = "sonic_rupture";
    public static final int CUSTOM_MODEL_DATA = 1001;

    private final NamespacedKey key;

    public SonicItemManager(SonicRupturePlugin plugin) {
        this.key = new NamespacedKey(plugin, "item_id");
    }

    public ItemStack create() {
        ItemStack item = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Sonic Rupture", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        meta.setCustomModelData(CUSTOM_MODEL_DATA);
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ITEM_ID);
        item.setItemMeta(meta);
        return item;
    }

    /** Identified by PDC only, never by display name. */
    public boolean isSonic(ItemStack item) {
        if (item == null || item.getType() != Material.NETHERITE_SWORD || !item.hasItemMeta()) return false;
        return ITEM_ID.equals(item.getItemMeta().getPersistentDataContainer()
                .get(key, PersistentDataType.STRING));
    }
}
