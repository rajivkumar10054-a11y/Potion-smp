package dev.sonicrupture;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class SonicRupturePlugin extends JavaPlugin {

    private ConfigManager cfg;
    private SonicItemManager items;
    private AbilityManager abilities;
    private ProjectileManager projectiles;
    private SonicFx fx;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = new ConfigManager(this);
        cfg.load();
        items = new SonicItemManager(this);
        projectiles = new ProjectileManager(this);
        abilities = new AbilityManager(this);
        fx = new BasicSonicFx(this);

        Bukkit.getPluginManager().registerEvents(new SonicListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);

        SonicCommand command = new SonicCommand(this);
        getCommand("sonic").setExecutor(command);
        getCommand("sonic").setTabCompleter(command);
    }

    @Override
    public void onDisable() {
        if (abilities != null) abilities.resetAll();
        if (projectiles != null) projectiles.shutdown();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof SonicGui) {
                p.closeInventory();
            }
        }
    }

    public ConfigManager cfg() { return cfg; }
    public SonicItemManager items() { return items; }
    public AbilityManager abilities() { return abilities; }
    public ProjectileManager projectiles() { return projectiles; }
    public SonicFx fx() { return fx; }

    /** Phase 2 hook: swap in a richer visual implementation. */
    public void setFx(SonicFx fx) { this.fx = fx; }
}
