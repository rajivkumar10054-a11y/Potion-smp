package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;
import java.util.Locale;

public final class ConfigManager {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final SonicRupturePlugin plugin;

    private int chargeTicks, cooldownTicks, lifetimeTicks;
    private double speed, maxRange, hitbox, damage, kbHorizontal, kbVertical;
    private boolean stopOnBlocks, sounds;

    private boolean fxChargeEnabled, fxTravelEnabled, fxBlockScatterEnabled, fxImpactEnabled;
    private int fxChargeParticleCount, fxChargeMaxParticleCount;
    private double fxChargeRadius, fxChargeMaxRadius;
    private String fxChargeParticle, fxChargeSound;
    private float fxChargeSoundVolume, fxChargeSoundPitch;

    private String fxTravelParticle;
    private int fxTravelParticleCount, fxMaxParticlesPerTick;

    private double fxScatterRadius, fxScatterOffset, fxScatterSpeed;
    private String fxScatterPattern, fxScatterMode, fxScatterSound;
    private int fxScatterMaxBlocks, fxScatterParticleCount, fxScatterSampleSpacing;
    private float fxScatterSoundVolume, fxScatterSoundPitch;
    private List<String> fxScatterCustomBlocks, fxScatterSkipBlocks;

    private String fxImpactParticle, fxImpactSound;
    private int fxImpactParticleCount;
    private double fxImpactOffset, fxImpactSpeed;
    private float fxImpactSoundVolume, fxImpactSoundPitch;

    private String msgCooldown, msgReceived, msgInventoryFull;

    public ConfigManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.reloadConfig();
        FileConfiguration c = plugin.getConfig();

        chargeTicks = Math.max(1, c.getInt("ability.charge-duration-ticks", 34));
        cooldownTicks = Math.max(0, c.getInt("ability.cooldown-ticks", 1200));
        speed = Math.max(0.1, c.getDouble("projectile.speed", 2.0));
        maxRange = Math.max(1.0, c.getDouble("projectile.max-range", 40.0));
        lifetimeTicks = Math.max(1, c.getInt("projectile.max-lifetime-ticks", 60));
        hitbox = Math.max(0.0, c.getDouble("projectile.hitbox-size", 0.4));
        stopOnBlocks = c.getBoolean("projectile.stop-on-blocks", true);
        damage = Math.max(0.0, c.getDouble("damage.amount", 10.0));
        kbHorizontal = c.getDouble("damage.knockback-horizontal", 1.2);
        kbVertical = c.getDouble("damage.knockback-vertical", 0.3);
        sounds = c.getBoolean("sounds.enabled", true);

        fxChargeEnabled = c.getBoolean("fx.charge.enabled", true);
        fxChargeParticleCount = Math.max(0, c.getInt("fx.charge.particle-count", 2));
        fxChargeMaxParticleCount = Math.max(fxChargeParticleCount,
                c.getInt("fx.charge.max-particle-count", 8));
        fxChargeRadius = Math.max(0.0, c.getDouble("fx.charge.radius", 0.35));
        fxChargeMaxRadius = Math.max(fxChargeRadius, c.getDouble("fx.charge.max-radius", 1.15));
        fxChargeParticle = c.getString("fx.charge.particle", "SCULK_SOUL");
        fxChargeSound = c.getString("fx.charge.sound", "ENTITY_WARDEN_SONIC_CHARGE");
        fxChargeSoundVolume = (float) Math.max(0.0, c.getDouble("fx.charge.sound-volume", 2.0));
        fxChargeSoundPitch = (float) c.getDouble("fx.charge.sound-pitch", 1.0);

        fxTravelEnabled = c.getBoolean("fx.travel.enabled", true);
        fxTravelParticle = c.getString("fx.travel.particle", "SONIC_BOOM");
        fxTravelParticleCount = Math.max(0, c.getInt("fx.travel.particle-count", 1));

        fxBlockScatterEnabled = c.getBoolean("fx.block-scatter.enabled", true);
        fxScatterRadius = Math.max(0.0, c.getDouble("fx.block-scatter.radius", 1.0));
        fxScatterPattern = c.getString("fx.block-scatter.pattern", "line").toLowerCase(Locale.ROOT);
        if (!fxScatterPattern.equals("line") && !fxScatterPattern.equals("cone")
                && !fxScatterPattern.equals("random")) fxScatterPattern = "line";
        fxScatterMode = c.getString("fx.block-scatter.selection-mode", "all").toLowerCase(Locale.ROOT);
        if (!fxScatterMode.equals("all") && !fxScatterMode.equals("natural")
                && !fxScatterMode.equals("custom")) fxScatterMode = "all";
        fxScatterMaxBlocks = Math.max(0, c.getInt("fx.block-scatter.max-blocks-per-shot", 30));
        fxScatterParticleCount = Math.max(0, c.getInt("fx.block-scatter.particle-count", 5));
        fxScatterOffset = Math.max(0.0, c.getDouble("fx.block-scatter.particle-offset", 0.12));
        fxScatterSpeed = Math.max(0.0, c.getDouble("fx.block-scatter.particle-speed", 0.08));
        fxScatterSound = c.getString("fx.block-scatter.sound", "BLOCK_STONE_BREAK");
        fxScatterSoundVolume = (float) Math.max(0.0, c.getDouble("fx.block-scatter.sound-volume", 0.35));
        fxScatterSoundPitch = (float) c.getDouble("fx.block-scatter.sound-pitch", 1.0);
        fxMaxParticlesPerTick = Math.max(0, c.getInt("fx.block-scatter.max-particle-effects-per-tick", 12));
        fxScatterSampleSpacing = Math.max(1, c.getInt("fx.block-scatter.sample-spacing", 1));
        fxScatterCustomBlocks = c.getStringList("fx.block-scatter.custom-blocks");
        fxScatterSkipBlocks = c.getStringList("fx.block-scatter.skip-blocks");

        fxImpactEnabled = c.getBoolean("fx.impact.enabled", true);
        fxImpactParticle = c.getString("fx.impact.particle", "SONIC_BOOM");
        fxImpactParticleCount = Math.max(0, c.getInt("fx.impact.particle-count", 1));
        fxImpactOffset = Math.max(0.0, c.getDouble("fx.impact.particle-offset", 0.35));
        fxImpactSpeed = Math.max(0.0, c.getDouble("fx.impact.particle-speed", 0.08));
        fxImpactSound = c.getString("fx.impact.sound", "ENTITY_WARDEN_SONIC_BOOM");
        fxImpactSoundVolume = (float) Math.max(0.0, c.getDouble("fx.impact.sound-volume", 2.5));
        fxImpactSoundPitch = (float) c.getDouble("fx.impact.sound-pitch", 1.0);

        msgCooldown = c.getString("messages.cooldown", "<red>Sonic Rupture is on cooldown (<seconds>s)");
        msgReceived = c.getString("messages.received", "<aqua>You received Sonic Rupture.");
        msgInventoryFull = c.getString("messages.inventory-full", "<red>Your inventory is full.");
    }

    public int chargeTicks() { return chargeTicks; }
    public int cooldownTicks() { return cooldownTicks; }
    public int lifetimeTicks() { return lifetimeTicks; }
    public double speed() { return speed; }
    public double maxRange() { return maxRange; }
    public double hitbox() { return hitbox; }
    public double damage() { return damage; }
    public double kbHorizontal() { return kbHorizontal; }
    public double kbVertical() { return kbVertical; }
    public boolean stopOnBlocks() { return stopOnBlocks; }
    public boolean sounds() { return sounds; }

    public boolean fxChargeEnabled() { return fxChargeEnabled; }
    public int fxChargeParticleCount() { return fxChargeParticleCount; }
    public int fxChargeMaxParticleCount() { return fxChargeMaxParticleCount; }
    public double fxChargeRadius() { return fxChargeRadius; }
    public double fxChargeMaxRadius() { return fxChargeMaxRadius; }
    public String fxChargeParticle() { return fxChargeParticle; }
    public String fxChargeSound() { return fxChargeSound; }
    public float fxChargeSoundVolume() { return fxChargeSoundVolume; }
    public float fxChargeSoundPitch() { return fxChargeSoundPitch; }

    public boolean fxTravelEnabled() { return fxTravelEnabled; }
    public String fxTravelParticle() { return fxTravelParticle; }
    public int fxTravelParticleCount() { return fxTravelParticleCount; }

    public boolean fxBlockScatterEnabled() { return fxBlockScatterEnabled; }
    public double fxScatterRadius() { return fxScatterRadius; }
    public String fxScatterPattern() { return fxScatterPattern; }
    public String fxScatterMode() { return fxScatterMode; }
    public int fxScatterMaxBlocks() { return fxScatterMaxBlocks; }
    public int fxScatterParticleCount() { return fxScatterParticleCount; }
    public double fxScatterOffset() { return fxScatterOffset; }
    public double fxScatterSpeed() { return fxScatterSpeed; }
    public String fxScatterSound() { return fxScatterSound; }
    public float fxScatterSoundVolume() { return fxScatterSoundVolume; }
    public float fxScatterSoundPitch() { return fxScatterSoundPitch; }
    public int fxMaxParticlesPerTick() { return fxMaxParticlesPerTick; }
    public int fxScatterSampleSpacing() { return fxScatterSampleSpacing; }
    public List<String> fxScatterCustomBlocks() { return fxScatterCustomBlocks; }
    public List<String> fxScatterSkipBlocks() { return fxScatterSkipBlocks; }

    public boolean fxImpactEnabled() { return fxImpactEnabled; }
    public String fxImpactParticle() { return fxImpactParticle; }
    public int fxImpactParticleCount() { return fxImpactParticleCount; }
    public double fxImpactOffset() { return fxImpactOffset; }
    public double fxImpactSpeed() { return fxImpactSpeed; }
    public String fxImpactSound() { return fxImpactSound; }
    public float fxImpactSoundVolume() { return fxImpactSoundVolume; }
    public float fxImpactSoundPitch() { return fxImpactSoundPitch; }

    public Component cooldownMessage(String seconds) {
        return MM.deserialize(msgCooldown.replace("<seconds>", seconds));
    }
    public Component receivedMessage() { return MM.deserialize(msgReceived); }
    public Component inventoryFullMessage() { return MM.deserialize(msgInventoryFull); }
}
