package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public final class SonicGui implements InventoryHolder {

    public static final int SWORD_SLOT = 13;

    private final Inventory inventory;

    public SonicGui() {
        inventory = Bukkit.createInventory(this, 27, Component.text("Sonic Rupture", NamedTextColor.DARK_AQUA));

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.displayName(Component.text(" "));
        filler.setItemMeta(fm);
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, filler);

        // Display-only item: carries no Sonic identifier, so it can never act as the real sword.
        ItemStack icon = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta im = icon.getItemMeta();
        im.displayName(Component.text("Sonic Rupture", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));
        im.lore(List.of(Component.text("Click to receive", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false)));
        icon.setItemMeta(im);
        inventory.setItem(SWORD_SLOT, icon);
    }

    public void open(Player p) {
        p.openInventory(inventory);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
