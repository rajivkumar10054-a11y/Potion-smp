package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Dispatches combat hit events to equipped potion abilities.
 * Ability-specific damage blocks, freezes, and item pickup cancellations
 * have been removed to prepare for new ability implementations.
 */
public class CombatListener implements Listener {

    private final PotionSMP plugin;

    public CombatListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;
        if (!(event.getDamager() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        // PotionSMP-generated damage must still deal normal damage, but it must
        // not re-enter PotionSMP's offensive onHit mechanics.
        if (ProgrammaticDamageGuard.isSuppressed(attacker.getUniqueId())) {
            return;
        }

        // Ability onHit dispatch to equipped slots
        PotionType slot1 = plugin.getSlotManager().getSlot1(attacker.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(attacker.getUniqueId());

        if (slot1 != null) {
            Ability ability = plugin.getAbilityRegistry().get(slot1);
            if (ability != null) ability.onHit(plugin, attacker, target);
        }
        if (slot2 != null && slot2 != slot1) {
            Ability ability = plugin.getAbilityRegistry().get(slot2);
            if (ability != null) ability.onHit(plugin, attacker, target);
        }
    }
}
