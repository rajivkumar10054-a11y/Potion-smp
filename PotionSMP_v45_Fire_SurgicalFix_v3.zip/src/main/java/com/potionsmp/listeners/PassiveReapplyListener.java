package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.managers.SlotManager;
import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionType;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Manages slot state and re-applies equipped potion passives across player lifecycle
 * events (respawn, join, server reload, and external effect clearing).
 *
 * Old ability-specific passive effects (permanent Fire Resistance, Regen, etc.)
 * have been decoupled so only current Ability.onEquip() hooks are triggered.
 */
public class PassiveReapplyListener implements Listener {

    private final PotionSMP plugin;

    // Players with a one-shot passive verification already queued (dedupe).
    private final Set<UUID> pendingVerify = new HashSet<>();

    public PassiveReapplyListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // ── Death: drop equipped potion(s) and clear slots ───────────────────

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uid = player.getUniqueId();

        SlotManager slots = plugin.getSlotManager();
        PotionType s1 = slots.getSlot1(uid);
        PotionType s2 = slots.getSlot2(uid);
        if (s1 == null && s2 == null) return;

        Location loc = player.getLocation();
        if (loc.getWorld() != null) {
            if (s1 != null) loc.getWorld().dropItemNaturally(loc, ItemBuilder.buildPotion(s1));
            if (s2 != null && s2 != s1) loc.getWorld().dropItemNaturally(loc, ItemBuilder.buildPotion(s2));
        }

        slots.clearAll(uid);
        slots.saveToPlayer(player);
    }

    // ── Passive persistence: restore after external removal ───────────────

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEffectRemoved(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        EntityPotionEffectEvent.Action action = event.getAction();
        if (action != EntityPotionEffectEvent.Action.REMOVED
                && action != EntityPotionEffectEvent.Action.CLEARED) return;
        EntityPotionEffectEvent.Cause cause = event.getCause();
        if (cause == EntityPotionEffectEvent.Cause.DEATH
                || cause == EntityPotionEffectEvent.Cause.EXPIRATION) return;
        if (player.isDead()) return;

        UUID uid = player.getUniqueId();
        SlotManager slots = plugin.getSlotManager();
        if (slots.getSlot1(uid) == null && slots.getSlot2(uid) == null) return;
        if (!pendingVerify.add(uid)) return;

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            pendingVerify.remove(uid);
            verifyPassives(player);
        });
    }

    private void verifyPassives(Player player) {
        if (!player.isOnline() || player.isDead()) return;
        UUID uid = player.getUniqueId();
        PotionType s1 = plugin.getSlotManager().getSlot1(uid);
        PotionType s2 = plugin.getSlotManager().getSlot2(uid);
        reapply(player, s1);
        if (s2 != null && s2 != s1) reapply(player, s2);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        reapplyNextTick(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        reapplyNextTick(event.getPlayer());
    }

    /**
     * Restores this player's slots from their PersistentDataContainer and
     * calls onEquip() for equipped potions.
     */
    public void reapplyNextTick(Player player) {
        UUID uid = player.getUniqueId();
        SlotManager slots = plugin.getSlotManager();
        slots.loadFromPlayer(player);

        PotionType slot1 = slots.getSlot1(uid);
        PotionType slot2 = slots.getSlot2(uid);
        if (slot1 == null && slot2 == null) return;

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            reapply(player, slot1);
            if (slot2 != null && slot2 != slot1) reapply(player, slot2);
        });
    }

    private void reapply(Player player, PotionType type) {
        if (type == null) return;
        Ability ability = plugin.getAbilityRegistry().get(type);
        if (ability != null) ability.onEquip(plugin, player);
    }
}
