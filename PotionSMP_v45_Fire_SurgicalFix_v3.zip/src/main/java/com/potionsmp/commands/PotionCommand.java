package com.potionsmp.commands;

import com.potionsmp.PotionSMP;
import com.potionsmp.gui.PotionGUI;
import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class PotionCommand implements CommandExecutor, TabCompleter {

    private final PotionSMP plugin;

    public PotionCommand(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        // v44: "/potion" (and its namespaced form "/potionsmp:potion") is OP-only.
        // /potionsmp and /psmp share this executor and are NOT restricted.
        // Checked first, before any command action.
        if (isRestrictedLabel(label) && !sender.isOp()) {
            sender.sendMessage(PotionUtils.colorize("&cYou don't have permission."));
            return true;
        }

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Console must specify a player: /potionSMP give <type> [player]");
                return true;
            }
            PotionGUI.open(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("give")) {
            if (args.length > 3) {
                sender.sendMessage(PotionUtils.colorize("&cUsage: /potionSMP give <type> [player]"));
                return true;
            }
            if (!sender.hasPermission("potionsmp.give")) {
                sender.sendMessage(PotionUtils.colorize("&cYou don't have permission."));
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(PotionUtils.colorize("&cUsage: /potionSMP give <type> [player]"));
                return true;
            }
            PotionType type = PotionType.fromId(args[1]);
            if (type == null) {
                sender.sendMessage(PotionUtils.colorize("&cUnknown potion type. Options: " + availableTypes()));
                return true;
            }

            Player target;
            if (args.length >= 3) {
                target = Bukkit.getPlayer(args[2]);
                if (target == null) {
                    sender.sendMessage(PotionUtils.colorize("&cPlayer not found: " + args[2]));
                    return true;
                }
            } else {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Specify a player name.");
                    return true;
                }
                target = (Player) sender;
            }

            target.getInventory().addItem(ItemBuilder.buildPotion(type));
            sender.sendMessage(PotionUtils.msg("gave-potion")
                    .replace("%potion%", type.getDisplayName())
                    .replace("%player%", target.getName()));
            return true;
        }

        if (args[0].equalsIgnoreCase("swap")) {
            if (args.length != 1) {
                sender.sendMessage(PotionUtils.colorize("&cUsage: /potionSMP swap"));
                return true;
            }
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            plugin.getSlotManager().swap(player.getUniqueId());
            plugin.getSlotManager().saveToPlayer(player);
            player.sendMessage(PotionUtils.colorize("&a✦ Swapped Slot 1 and Slot 2!"));

            // Immediate HUD refresh — don't wait for the periodic 10-tick tick
            plugin.getHudManager().sendOnce(player);
            return true;
        }

        sender.sendMessage(PotionUtils.colorize("&eUsage: /potionSMP [give <type> [player] | swap]"));
        return true;
    }

    /** True when the label the sender typed is the "potion" alias (case-insensitive, namespace stripped). */
    private static boolean isRestrictedLabel(String label) {
        if (label == null) return false;
        int colon = label.lastIndexOf(':');
        String bare = colon >= 0 ? label.substring(colon + 1) : label;
        return bare.equalsIgnoreCase("potion");
    }

    private String availableTypes() {
        return Arrays.stream(PotionType.values()).map(PotionType::getId).reduce((a, b) -> a + ", " + b).orElse("");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (isRestrictedLabel(alias) && !sender.isOp()) return List.of();
        if (args.length == 1) return List.of("give", "swap");
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            return Arrays.stream(PotionType.values()).map(PotionType::getId).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        }
        return List.of();
    }
}
