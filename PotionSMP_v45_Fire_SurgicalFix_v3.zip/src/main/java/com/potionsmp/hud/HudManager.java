package com.potionsmp.hud;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.abilities.FireAbility;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.Map;

/**
 * Renders a 2-slot HUD above the hotbar via ActionBar every 10 ticks.
 *
 * Font : minecraft:default  (assets/minecraft/font/default.json)
 * Textures: assets/minecraft/textures/potions/*.png
 *
 * ARCHITECTURE — one complete glyph per slot state (no overlay/negative-space trick):
 *   \uE901          → empty slot (complete empty box glyph)
 *   \uE002 – \uE00D  → potion ready (complete box+icon glyph, per type)
 *   \uE202 – \uE20D  → potion on cooldown (complete darkened box+icon glyph)
 *
 * Fire Potion Custom Countdown States:
 *   - Active State: RED text, counts down from 10s to 1s.
 *   - Cooldown State: WHITE text, counts down from 30s to 1s immediately after active state ends.
 *   - Never displays active and cooldown timers simultaneously.
 */
public class HudManager {

    // ── Font key ──────────────────────────────────────────────────────────
    private static final Key FONT = Key.key("minecraft", "default");

    // ── Slot background ───────────────────────────────────────────────────
    private static final String SLOT_EMPTY = "\uE901";

    // ── Space chars ───────────────────────────────────────────────────────
    private static final String SP2 = "\uE904"; // +2 px
    private static final String SP6 = "\uE905"; // +6 px

    private record IconInfo(String normal, String dark) {}

    private static final Map<PotionType, IconInfo> ICONS = new EnumMap<>(PotionType.class);
    static {
        ICONS.put(PotionType.FIRE,     new IconInfo("\uE006", "\uE206"));
        ICONS.put(PotionType.FREEZE,   new IconInfo("\uE004", "\uE204"));
        ICONS.put(PotionType.REGEN,    new IconInfo("\uE008", "\uE208"));
        ICONS.put(PotionType.GLITCH,   new IconInfo("\uE002", "\uE202"));
        ICONS.put(PotionType.SHIELD,   new IconInfo("\uE003", "\uE203"));
        ICONS.put(PotionType.ENDER,    new IconInfo("\uE005", "\uE205"));
        ICONS.put(PotionType.TELEPORT, new IconInfo("\uE007", "\uE207"));
        ICONS.put(PotionType.SPEED,    new IconInfo("\uE009", "\uE209"));
        ICONS.put(PotionType.FEATHER,  new IconInfo("\uE00A", "\uE20A"));
        ICONS.put(PotionType.EMERALD,  new IconInfo("\uE00B", "\uE20B"));
        ICONS.put(PotionType.STRENGTH, new IconInfo("\uE00C", "\uE20C"));
        ICONS.put(PotionType.HASTE,    new IconInfo("\uE00D", "\uE20D"));
    }

    private static final Style FONT_STYLE = Style.style().font(FONT).build();
    private static final Component READY_TEXT = Component.text("Ready", NamedTextColor.GREEN);
    private static final Component GAP = Component.text(SP6).style(FONT_STYLE);
    private static final Component EMPTY_SLOT = Component.text(SLOT_EMPTY + SP2).style(FONT_STYLE);
    private static final Map<PotionType, Component> READY_ICONS = new EnumMap<>(PotionType.class);
    static {
        for (Map.Entry<PotionType, IconInfo> e : ICONS.entrySet()) {
            READY_ICONS.put(e.getKey(),
                Component.text(e.getValue().normal() + SP2).style(FONT_STYLE));
        }
    }

    private final PotionSMP plugin;
    private BukkitTask task;

    public HudManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 0L, 10L);
    }

    public void stop() {
        if (task != null) { task.cancel(); task = null; }
    }

    // ── Tick: send to ALL online players ──────────────────────────────────

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendActionBar(buildHUD(player));
        }
    }

    public void sendOnce(Player player) {
        player.sendActionBar(buildHUD(player));
    }

    // ── HUD builder ───────────────────────────────────────────────────────

    private Component buildHUD(Player player) {
        PotionType slot1 = plugin.getSlotManager().getSlot1(player.getUniqueId());
        PotionType slot2 = plugin.getSlotManager().getSlot2(player.getUniqueId());

        return Component.empty()
                .append(buildSlot(player, slot1))
                .append(GAP)
                .append(buildSlot(player, slot2));
    }

    private Component buildSlot(Player player, PotionType type) {
        if (type == null) {
            return EMPTY_SLOT;
        }

        IconInfo info = ICONS.getOrDefault(type, new IconInfo(SLOT_EMPTY, SLOT_EMPTY));

        // Fire Potion: Specific Active State (RED) vs Cooldown State (WHITE)
        if (type == PotionType.FIRE) {
            Ability ability = plugin.getAbilityRegistry().get(PotionType.FIRE);
            if (ability instanceof FireAbility fireAbility && fireAbility.isActiveState(player.getUniqueId())) {
                int activeSecs = fireAbility.getRemainingActiveSeconds(plugin, player.getUniqueId());
                // Active State: normal icon + remaining seconds in RED
                return Component.empty()
                        .append(Component.text(info.normal() + SP2).style(FONT_STYLE))
                        .append(Component.text(String.valueOf(activeSecs), NamedTextColor.RED));
            }

            boolean onCooldown = plugin.getCooldownManager()
                    .isOnCooldown(player.getUniqueId(), type);

            if (onCooldown) {
                long secs = plugin.getCooldownManager()
                        .getRemainingSeconds(player.getUniqueId(), type);
                // Cooldown State: darkened icon + remaining seconds in WHITE
                return Component.empty()
                        .append(Component.text(info.dark() + SP2).style(FONT_STYLE))
                        .append(Component.text(String.valueOf(secs), NamedTextColor.WHITE));
            }

            // Ready state: normal icon + green Ready
            Component cached = READY_ICONS.get(type);
            Component icon = cached != null ? cached
                : Component.text(info.normal() + SP2).style(FONT_STYLE);
            return Component.empty().append(icon).append(READY_TEXT);
        }

        // Standard logic for all other 11 potions (YELLOW cooldown, green Ready)
        boolean onCooldown = plugin.getCooldownManager()
                .isOnCooldown(player.getUniqueId(), type);

        if (onCooldown) {
            long secs = plugin.getCooldownManager()
                    .getRemainingSeconds(player.getUniqueId(), type);
            return Component.empty()
                    .append(Component.text(info.dark() + SP2).style(FONT_STYLE))
                    .append(Component.text(String.valueOf(secs), NamedTextColor.YELLOW));
        }

        Component cached = READY_ICONS.get(type);
        Component icon = cached != null ? cached
            : Component.text(info.normal() + SP2).style(FONT_STYLE);
        return Component.empty().append(icon).append(READY_TEXT);
    }
}
