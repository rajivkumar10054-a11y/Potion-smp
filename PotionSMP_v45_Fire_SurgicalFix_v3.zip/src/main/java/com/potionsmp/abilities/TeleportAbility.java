package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Teleport Potion ability implementation.
 * Old active (Shadow Teleport / player teleportation) and passive (permanent Invisibility)
 * abilities and cooldowns have been removed to prepare for new ability implementation.
 */
public class TeleportAbility implements Ability {

    @Override
    public PotionType type() {
        return PotionType.TELEPORT;
    }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        // Old on-hit passive removed; ready for new ability implementation.
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        // Old active ability and cooldown removed; ready for new ability implementation.
        return ActivationResult.SUCCESS;
    }
}
