package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.ParticleManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * PotionSMP Fire Potion Implementation — Surgical Fix v3 + Complete Regression Audit.
 * Role: Area Damage.
 *
 * Locked Design:
 * 1. Passive — Fire Ignition:
 *    - Permanent Fire Resistance managed via EffectOwnershipManager.
 *    - Every 10 hits on a valid target, ignites direct target for 100 ticks.
 *    - Ignites eligible nearby enemies within 3 blocks for 80 ticks (excluding direct target).
 *    - Supports eligible mobs and players per v45 target-selection rules.
 *    - Resets Fire-specific progress and debounce on unequip (Issue 6).
 *
 * 2. Active 1 — Fire Burst (X + Y):
 *    - Starts 200-tick (10-second) active state.
 *    - Anchors fixed 10x10 ground zone to solid ground beneath activating player.
 *    - Explicitly cancels activation if no solid ground can be determined; avoids unnecessary chunk loads (Issue 8).
 *    - Zone remains fixed for the entire active state; does not follow player.
 *    - BoundingBox intersection testing guarantees exact 10x10x2.5 coverage without point-based edge bugs (Issue 5).
 *    - Targets inside receive vanilla fire burning (refreshes 25 ticks while inside; finishes naturally after leaving).
 *    - Visual fire trails follow player movement without dealing damage.
 *    - No permanent fire blocks, terrain modification, or custom damage stacking.
 *
 * 3. Active 2 — Flame Strike (Shift + X + Y):
 *    - Shoots one SmallFireball; usable once per active state.
 *    - Configurable direct impact damage (4 HP default) and ignition (40 ticks default).
 *    - Overrides damage directly in EntityDamageByEntityEvent without duplicate vanilla/custom damage.
 *    - Idempotent projectile cleanup across all terminal paths (Issue 4).
 *
 * 4. Shared Lifecycle & Cooldown:
 *    - 200 ticks active state -> 600 ticks (30s) shared cooldown begins after active state ends.
 *    - Rigorous server-tick and session-token validation prevents premature or duplicate cooldowns (Issues 1 & 2).
 *    - Configuration validation clamps invalid/negative/extreme values to safe defaults (Issue 3).
 */
public class FireAbility implements Ability, Listener {

    // Timing constants (tick-synchronized)
    public static final int ACTIVE_STATE_DURATION_TICKS = 200; // 10 seconds
    public static final int SHARED_COOLDOWN_SECONDS = 30;      // 30 seconds

    // Fire Burst zone geometry
    public static final double FIRE_ZONE_SIZE = 10.0;
    public static final double FIRE_ZONE_HALF_SIZE = FIRE_ZONE_SIZE / 2.0;
    public static final double FIRE_ZONE_HEIGHT = 2.5;

    // Flame Strike configuration defaults
    public static final double FLAME_STRIKE_DIRECT_DAMAGE = 4.0; // 4 HP (2 hearts)
    public static final int FLAME_STRIKE_IGNITION_TICKS = 40;     // 40 ticks (2 seconds)
    public static final String FLAME_STRIKE_PROJECTILE_KEY = "flame_strike_projectile";

    // Ground search depth limit
    private static final int MAX_GROUND_SEARCH_BLOCKS = 30;

    // Stored plugin instance from register()
    private PotionSMP plugin;

    // Session generation token to prevent expiration race conditions (Issue 2)
    private final Map<UUID, UUID> activeSessionTokens = new ConcurrentHashMap<>();
    private final Map<UUID, Long> activeStateEndTick = new ConcurrentHashMap<>();
    private final Map<UUID, List<BukkitTask>> activeStateTasks = new ConcurrentHashMap<>();
    private final Map<UUID, Location> activeFireZones = new ConcurrentHashMap<>();
    private final Set<UUID> flameStrikeUsed = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Set<UUID> activeProjectiles = Collections.newSetFromMap(new ConcurrentHashMap<>());

    @Override
    public PotionType type() {
        return PotionType.FIRE;
    }

    @Override
    public void register(PotionSMP plugin) {
        this.plugin = plugin;
        Ability.super.register(plugin);
    }

    private PotionSMP getPlugin() {
        if (this.plugin != null) return this.plugin;
        return PotionSMP.getInstance();
    }

    // ── Passive Lifecycle (v45 Exact + Issue 6 Fix) ────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        this.plugin = plugin;
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        this.plugin = plugin;
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.FIRE_RESISTANCE);

        // Issue 6: Reset Fire-specific partial hit counter and debounce tracking on unequip
        plugin.getHitCounterManager().reset(player.getUniqueId(), type());

        endActiveState(plugin, player.getUniqueId(), null, false);
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        this.plugin = plugin;
        // Validate direct target before processing passive hit
        if (!isValidTarget(player, target)) return;

        int newCount = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(), target.getUniqueId(),
            player.getWorld().getFullTime());
        if (newCount == -1) return;

        int threshold = getValidatedPassiveHits(plugin);
        if (newCount >= threshold) {
            plugin.getHitCounterManager().reset(player.getUniqueId(), type());

            Location loc = target.getLocation().clone().add(0, 1, 0);

            // Direct target receives full 100 ticks
            target.setFireTicks(100);

            // Nearby eligible enemies within 3 blocks receive 80 ticks (excluding direct target)
            for (Entity e : loc.getWorld().getNearbyEntities(loc, 3, 3, 3)) {
                if (e instanceof LivingEntity le
                        && !e.getUniqueId().equals(player.getUniqueId())
                        && !e.getUniqueId().equals(target.getUniqueId())) {
                    if (isValidTarget(player, le)) {
                        le.setFireTicks(80);
                    }
                }
            }

            // Passive particles and audio
            ParticleManager.spawnFirePassiveParticles(loc);
            loc.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
            player.sendMessage(PotionUtils.colorize("&c🔥 Passive fire ignition!"));
        } else {
            // Per-hit subtle particle
            target.getWorld().spawnParticle(Particle.FLAME,
                target.getLocation().add(0, 1, 0), 2, 0.15, 0.15, 0.15, 0.01);
        }
    }

    // ── Active State Lifecycle (Issues 1 & 2 Fixes) ─────────────────────────

    /**
     * Issue 1: Validates both session token existence AND current server tick.
     * Never returns true merely because a token exists after expiration.
     */
    public boolean isActiveState(UUID uuid) {
        if (!activeSessionTokens.containsKey(uuid)) return false;
        Long endTick = activeStateEndTick.get(uuid);
        if (endTick == null) return false;
        PotionSMP p = getPlugin();
        if (p == null) return false;
        return p.getServer().getCurrentTick() < endTick;
    }

    public int getRemainingActiveSeconds(PotionSMP plugin, UUID uuid) {
        if (!isActiveState(uuid)) return 0;
        Long endTick = activeStateEndTick.get(uuid);
        if (endTick == null) return 0;
        PotionSMP p = plugin != null ? plugin : getPlugin();
        if (p == null) return 0;
        long remainingTicks = endTick - p.getServer().getCurrentTick();
        if (remainingTicks <= 0) return 0;
        return (int) Math.ceil(remainingTicks / 20.0);
    }

    public boolean hasUsedFlameStrike(UUID uuid) {
        return flameStrikeUsed.contains(uuid);
    }

    public Location getActiveFireZone(UUID uuid) {
        return activeFireZones.get(uuid);
    }

    public boolean startActiveState(PotionSMP plugin, Player player) {
        this.plugin = plugin;
        UUID uid = player.getUniqueId();

        // Issue 2: Protect against duplicate calls or replacing an active session
        if (isActiveState(uid)) {
            return false;
        }

        // Complete any expired session token before starting a new one
        UUID existingSession = activeSessionTokens.get(uid);
        if (existingSession != null) {
            endActiveState(plugin, uid, existingSession, true);
        }

        // Issue 8: Ground detection — cancel activation if no solid ground found
        Location groundCenter = findGroundLocation(player.getLocation());
        if (groundCenter == null) {
            player.sendMessage(PotionUtils.colorize("&c✖ Cannot activate Fire Burst: no solid ground beneath you!"));
            return false;
        }

        // Generate unique session token for this active state
        UUID sessionId = UUID.randomUUID();
        activeSessionTokens.put(uid, sessionId);

        // Cancel any lingering tasks from previous sessions safely
        List<BukkitTask> oldTasks = activeStateTasks.remove(uid);
        if (oldTasks != null) {
            for (BukkitTask t : oldTasks) {
                try { t.cancel(); } catch (Exception ignored) {}
            }
        }

        // Issue 3: Validated duration from config with bounds check
        int durationTicks = getValidatedActiveDuration(plugin);
        long currentTick = plugin.getServer().getCurrentTick();
        activeStateEndTick.put(uid, currentTick + durationTicks);
        flameStrikeUsed.remove(uid);
        activeFireZones.put(uid, groundCenter);

        List<BukkitTask> tasks = new ArrayList<>();

        // Zone particle outline & vanilla fire burning task (runs every 4 ticks)
        BukkitTask zoneTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                // Issue 1: Terminate if session changed, active state expired, or player offline
                if (!player.isOnline() || !sessionId.equals(activeSessionTokens.get(uid)) || !isActiveState(uid) || ticks >= durationTicks) {
                    cancel();
                    return;
                }

                renderZoneParticles(groundCenter);

                // Check entity positions against exact BoundingBox boundaries every 10 ticks (0.5s)
                if (ticks % 10 == 0) {
                    applyZoneVanillaBurning(plugin, player, groundCenter);
                }

                ticks += 4;
            }
        }.runTaskTimer(plugin, 0L, 4L);
        tasks.add(zoneTask);

        // Fire trails visually following activating player's movement (every 2 ticks)
        BukkitTask trailTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || !sessionId.equals(activeSessionTokens.get(uid)) || !isActiveState(uid)) {
                    cancel();
                    return;
                }
                Location footLoc = player.getLocation().add(0, 0.1, 0);
                footLoc.getWorld().spawnParticle(Particle.FLAME, footLoc, 2, 0.12, 0.05, 0.12, 0.01);
                footLoc.getWorld().spawnParticle(Particle.SMALL_FLAME, footLoc, 1, 0.08, 0.02, 0.08, 0.005);
            }
        }.runTaskTimer(plugin, 0L, 2L);
        tasks.add(trailTask);

        // Issue 2: End timer verifies session identity before terminating
        BukkitTask endTimer = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (sessionId.equals(activeSessionTokens.get(uid))) {
                endActiveState(plugin, uid, sessionId, true);
            }
        }, durationTicks);
        tasks.add(endTimer);

        activeStateTasks.put(uid, tasks);

        // Activation sound and notification
        groundCenter.getWorld().playSound(groundCenter, Sound.ENTITY_BLAZE_SHOOT, 1.2f, 0.7f);
        player.sendMessage(PotionUtils.colorize("&c🔥 &lFire Burst &7activated! 10×10 Fire Zone deployed for 10s."));
        return true;
    }

    public void endActiveState(PotionSMP plugin, UUID uid, UUID expectedSessionId, boolean normalExpiration) {
        if (plugin == null) plugin = getPlugin();
        this.plugin = plugin;

        // Issue 2: Verify session token identity
        if (expectedSessionId != null) {
            UUID currentToken = activeSessionTokens.get(uid);
            if (currentToken == null || !currentToken.equals(expectedSessionId)) {
                return; // Stale session task; ignore
            }
        }

        // Atomically remove session token; if null, no active session was running
        UUID removedSession = activeSessionTokens.remove(uid);
        if (removedSession == null) {
            return; // Idempotent: no active session was running, do not start cooldown
        }

        activeStateEndTick.remove(uid);
        activeFireZones.remove(uid);
        flameStrikeUsed.remove(uid);

        List<BukkitTask> tasks = activeStateTasks.remove(uid);
        if (tasks != null) {
            for (BukkitTask t : tasks) {
                try { t.cancel(); } catch (Exception ignored) {}
            }
        }

        // Issue 3: Validated cooldown from config with fallback
        int cooldownSec = getValidatedActiveCooldown(plugin);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldownSec);

        Player player = plugin.getServer().getPlayer(uid);
        if (player != null && player.isOnline() && normalExpiration) {
            player.sendMessage(PotionUtils.colorize("&7Fire Potion Active State ended. 30s cooldown started."));
        }
    }

    // ── Zone Geometry & Safe Ground Anchoring (Issues 5 & 8 Fixes) ──────────

    private Location findGroundLocation(Location loc) {
        World world = loc.getWorld();
        if (world == null) return null;

        int blockX = loc.getBlockX();
        int blockZ = loc.getBlockZ();

        // Issue 8: Avoid loading chunks unnecessarily
        if (!world.isChunkLoaded(blockX >> 4, blockZ >> 4)) {
            return null;
        }

        int startY = loc.getBlockY();
        int minY = Math.max(world.getMinHeight(), startY - MAX_GROUND_SEARCH_BLOCKS);

        // Search downward from player's feet to find solid ground
        for (int y = startY; y >= minY; y--) {
            Block b = world.getBlockAt(blockX, y, blockZ);
            if (b.getType().isSolid()) {
                Block above = world.getBlockAt(blockX, y + 1, blockZ);
                if (!above.getType().isSolid()) {
                    Location ground = loc.clone();
                    ground.setX(blockX + 0.5);
                    ground.setY(y + 1.0);
                    ground.setZ(blockZ + 0.5);
                    return ground;
                }
            }
        }
        // Issue 8: Explicitly return null if no solid ground found within range (no airborne fallback)
        return null;
    }

    private void renderZoneParticles(Location center) {
        World world = center.getWorld();
        if (world == null) return;

        // Guard against unloaded chunks
        if (!world.isChunkLoaded(center.getBlockX() >> 4, center.getBlockZ() >> 4)) {
            return;
        }

        double cx = center.getX();
        double cz = center.getZ();
        double y = center.getY() + 0.1;

        double half = FIRE_ZONE_SIZE / 2.0;
        double minX = cx - half;
        double maxX = cx + half;
        double minZ = cz - half;
        double maxZ = cz + half;

        // Perimeter particles: outlining the FIRE_ZONE_SIZE x FIRE_ZONE_SIZE square
        for (double x = minX; x <= maxX; x += 1.0) {
            world.spawnParticle(Particle.FLAME, x, y, minZ, 1, 0, 0, 0, 0);
            world.spawnParticle(Particle.FLAME, x, y, maxZ, 1, 0, 0, 0, 0);
        }
        for (double z = minZ; z <= maxZ; z += 1.0) {
            world.spawnParticle(Particle.FLAME, minX, y, z, 1, 0, 0, 0, 0);
            world.spawnParticle(Particle.FLAME, maxX, y, z, 1, 0, 0, 0, 0);
        }

        // Interior accent particles (sparse embers)
        world.spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, cx + (Math.random() - 0.5) * (FIRE_ZONE_SIZE - 2.0), y, cz + (Math.random() - 0.5) * (FIRE_ZONE_SIZE - 2.0), 1, 0, 0.05, 0, 0);
        world.spawnParticle(Particle.SMALL_FLAME, cx + (Math.random() - 0.5) * (FIRE_ZONE_SIZE - 2.0), y, cz + (Math.random() - 0.5) * (FIRE_ZONE_SIZE - 2.0), 2, 0.1, 0.02, 0.1, 0.01);
    }

    /**
     * Issue 5: Uses native BoundingBox intersection testing.
     * Prevents point-based edge bugs and accounts for true 3D entity collision.
     */
    private void applyZoneVanillaBurning(PotionSMP plugin, Player caster, Location center) {
        World world = center.getWorld();
        if (world == null) return;

        if (!world.isChunkLoaded(center.getBlockX() >> 4, center.getBlockZ() >> 4)) {
            return;
        }

        double cx = center.getX();
        double cz = center.getZ();
        double groundY = center.getY();

        double half = FIRE_ZONE_SIZE / 2.0;
        double minX = cx - half;
        double maxX = cx + half;
        double minZ = cz - half;
        double maxZ = cz + half;
        double minY = groundY - 0.5;
        double maxY = groundY + FIRE_ZONE_HEIGHT;

        BoundingBox zoneBox = new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ);

        for (Entity e : world.getNearbyEntities(center, half + 1.0, FIRE_ZONE_HEIGHT + 1.0, half + 1.0)) {
            if (!(e instanceof LivingEntity target) || !isValidTarget(caster, target)) {
                continue;
            }

            // BoundingBox intersection check
            if (zoneBox.overlaps(target.getBoundingBox())) {
                target.setFireTicks(25);
            }
        }
    }

    // ── Ability Dispatcher ─────────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        this.plugin = plugin;
        boolean sneaking = player.isSneaking();

        if (!sneaking) {
            // X + Y: Fire Burst
            return handleFireBurst(plugin, player);
        } else {
            // Shift + X + Y: Flame Strike
            return handleFlameStrike(plugin, player);
        }
    }

    private ActivationResult handleFireBurst(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Issue 1: Handle boundary expiration if current session is past endTick
        UUID currentSession = activeSessionTokens.get(uid);
        if (currentSession != null) {
            Long endTick = activeStateEndTick.get(uid);
            if (endTick != null && plugin.getServer().getCurrentTick() >= endTick) {
                endActiveState(plugin, uid, currentSession, true);
            }
        }

        if (isActiveState(uid)) {
            player.sendMessage(PotionUtils.colorize("&c✖ Fire Burst is already active!"));
            return ActivationResult.SUCCESS;
        }

        if (plugin.getCooldownManager().isOnCooldown(uid, type())) {
            return ActivationResult.ON_COOLDOWN;
        }

        // Starts the active state, anchors the fixed 10x10 fire zone, and starts fire trails
        boolean started = startActiveState(plugin, player);
        if (!started) {
            return ActivationResult.SUCCESS;
        }
        return ActivationResult.SUCCESS;
    }

    private ActivationResult handleFlameStrike(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Discovered Bug 1: Reject if player is dead or in spectator mode
        if (player.isDead() || player.getGameMode() == GameMode.SPECTATOR) {
            return ActivationResult.SUCCESS;
        }

        // Issue 1: Check actual expiration boundary before allowing Flame Strike
        UUID currentSession = activeSessionTokens.get(uid);
        if (currentSession != null) {
            Long endTick = activeStateEndTick.get(uid);
            if (endTick != null && plugin.getServer().getCurrentTick() >= endTick) {
                endActiveState(plugin, uid, currentSession, true);
            }
        }

        // Available only during active state
        if (!isActiveState(uid)) {
            player.sendMessage(PotionUtils.colorize("&c✖ Flame Strike is only available during Active State! Activate Fire Burst (X + Y) first."));
            return ActivationResult.SUCCESS;
        }

        // Usable once per active state
        if (flameStrikeUsed.contains(uid)) {
            player.sendMessage(PotionUtils.colorize("&c✖ Flame Strike can only be used once per Active State!"));
            return ActivationResult.SUCCESS;
        }

        flameStrikeUsed.add(uid);
        launchFlameStrikeProjectile(plugin, player);
        return ActivationResult.SUCCESS;
    }

    // ── Flame Strike Projectile (Issues 3 & 4 Fixes) ────────────────────────

    private void launchFlameStrikeProjectile(PotionSMP plugin, Player player) {
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection().normalize();

        SmallFireball fireball = player.launchProjectile(SmallFireball.class, direction.multiply(1.5));
        fireball.setIsIncendiary(false);
        fireball.setYield(0f);

        NamespacedKey key = new NamespacedKey(plugin, FLAME_STRIKE_PROJECTILE_KEY);
        fireball.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        UUID fireballId = fireball.getUniqueId();
        activeProjectiles.add(fireballId);

        // Issue 4: Safety timeout removes projectile tracking after 5s (100 ticks) to prevent leaks
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            cleanupProjectile(fireballId, fireball);
        }, 100L);

        eye.getWorld().playSound(eye, Sound.ENTITY_BLAZE_SHOOT, 1.3f, 1.0f);
        player.sendMessage(PotionUtils.colorize("&6⚡ &lFlame Strike &7launched!"));
    }

    private boolean isFlameStrikeProjectile(SmallFireball fireball) {
        PotionSMP p = getPlugin();
        if (p == null) return false;
        NamespacedKey key = new NamespacedKey(p, FLAME_STRIKE_PROJECTILE_KEY);
        return fireball.getPersistentDataContainer().has(key, PersistentDataType.BYTE)
                || activeProjectiles.contains(fireball.getUniqueId());
    }

    private void cleanupProjectile(UUID fireballId, SmallFireball fireball) {
        activeProjectiles.remove(fireballId);
        if (fireball != null && fireball.isValid()) {
            fireball.remove();
        }
    }

    // Direct projectile damage: sets exact damage on EntityDamageByEntityEvent without duplicate calls
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFireballDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof SmallFireball fireball && isFlameStrikeProjectile(fireball)) {
            UUID fireballId = fireball.getUniqueId();

            if (event.getEntity() instanceof LivingEntity target && fireball.getShooter() instanceof Player shooter) {
                if (!isValidTarget(shooter, target)) {
                    event.setCancelled(true);
                    cleanupProjectile(fireballId, fireball);
                    return;
                }

                PotionSMP p = getPlugin();
                double damage = getValidatedFlameStrikeDamage(p);
                int ignitionTicks = getValidatedFlameStrikeIgnition(p);

                // Set event damage directly to prevent duplicate vanilla projectile impact damage
                event.setDamage(damage);
                target.setFireTicks(ignitionTicks);

                // Visual impact particles and sound
                Location hitLoc = target.getLocation().add(0, target.getHeight() * 0.5, 0);
                hitLoc.getWorld().spawnParticle(Particle.EXPLOSION, hitLoc, 1, 0.1, 0.1, 0.1, 0);
                hitLoc.getWorld().spawnParticle(Particle.FLAME, hitLoc, 25, 0.3, 0.3, 0.3, 0.05);
                hitLoc.getWorld().playSound(hitLoc, Sound.ENTITY_BLAZE_SHOOT, 1.4f, 1.2f);

                shooter.sendMessage(PotionUtils.colorize("&6⚡ &lFlame Strike &7struck &f" + target.getName() + "&7!"));
                cleanupProjectile(fireballId, fireball);
            } else {
                cleanupProjectile(fireballId, fireball);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile proj = event.getEntity();
        if (!(proj instanceof SmallFireball fireball) || !isFlameStrikeProjectile(fireball)) return;

        // Block hit: extinguish safely without damaging terrain or creating fire blocks
        if (event.getHitBlock() != null) {
            Location bLoc = event.getHitBlock().getLocation().add(0.5, 1.0, 0.5);
            bLoc.getWorld().spawnParticle(Particle.FLAME, bLoc, 8, 0.2, 0.2, 0.2, 0.05);
            bLoc.getWorld().playSound(bLoc, Sound.BLOCK_FIRE_EXTINGUISH, 0.8f, 1.5f);
            cleanupProjectile(fireball.getUniqueId(), fireball);
        }
    }

    // ── Target Validation & Safety ──────────────────────────────────────────

    public boolean isValidTarget(Player attacker, LivingEntity target) {
        if (target == null || !target.isValid() || target.isDead()) return false;
        if (target instanceof ArmorStand) return false;
        if (target.isInvulnerable()) return false;
        if (target.getUniqueId().equals(attacker.getUniqueId())) return false;

        if (target instanceof Player p) {
            if (!p.isOnline()) return false;
            GameMode gm = p.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;

            // Scoreboard friendly-fire check
            Team attackerTeam = attacker.getScoreboard().getEntryTeam(attacker.getName());
            if (attackerTeam != null && attackerTeam.hasEntry(p.getName()) && !attackerTeam.allowFriendlyFire()) {
                return false;
            }
        }
        return true;
    }

    // ── Event Cleanups ─────────────────────────────────────────────────────

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        PotionSMP p = getPlugin();
        if (p != null) {
            endActiveState(p, event.getPlayer().getUniqueId(), null, false);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        PotionSMP p = getPlugin();
        if (p != null) {
            endActiveState(p, event.getEntity().getUniqueId(), null, false);
        }
    }

    public void shutdown(PotionSMP plugin) {
        this.plugin = plugin;
        for (UUID uid : new ArrayList<>(activeSessionTokens.keySet())) {
            endActiveState(plugin, uid, null, false);
        }
        activeProjectiles.clear();
    }

    // ── Configuration Validation Helpers (Issue 3 Fix) ─────────────────────

    public int getValidatedActiveDuration(PotionSMP plugin) {
        if (plugin == null) plugin = getPlugin();
        int val = plugin != null ? plugin.getConfig().getInt("potions.fire.active-duration", ACTIVE_STATE_DURATION_TICKS) : ACTIVE_STATE_DURATION_TICKS;
        if (val <= 0 || val > 72000) {
            return ACTIVE_STATE_DURATION_TICKS;
        }
        return val;
    }

    public int getValidatedActiveCooldown(PotionSMP plugin) {
        if (plugin == null) plugin = getPlugin();
        int val = plugin != null ? plugin.getConfig().getInt("potions.fire.active-cooldown", SHARED_COOLDOWN_SECONDS) : SHARED_COOLDOWN_SECONDS;
        if (val <= 0 || val > 86400) {
            return SHARED_COOLDOWN_SECONDS;
        }
        return val;
    }

    public double getValidatedFlameStrikeDamage(PotionSMP plugin) {
        if (plugin == null) plugin = getPlugin();
        double val = plugin != null ? plugin.getConfig().getDouble("potions.fire.flame-strike-damage", FLAME_STRIKE_DIRECT_DAMAGE) : FLAME_STRIKE_DIRECT_DAMAGE;
        if (Double.isNaN(val) || Double.isInfinite(val) || val < 0 || val > 1000.0) {
            return FLAME_STRIKE_DIRECT_DAMAGE;
        }
        return val;
    }

    public int getValidatedFlameStrikeIgnition(PotionSMP plugin) {
        if (plugin == null) plugin = getPlugin();
        int val = plugin != null ? plugin.getConfig().getInt("potions.fire.flame-strike-ignition-ticks", FLAME_STRIKE_IGNITION_TICKS) : FLAME_STRIKE_IGNITION_TICKS;
        if (val < 0 || val > 72000) {
            return FLAME_STRIKE_IGNITION_TICKS;
        }
        return val;
    }

    public int getValidatedPassiveHits(PotionSMP plugin) {
        if (plugin == null) plugin = getPlugin();
        int val = plugin != null ? plugin.getConfig().getInt("potions.fire.passive-hits", 10) : 10;
        if (val <= 0 || val > 1000) {
            return 10;
        }
        return val;
    }
}
