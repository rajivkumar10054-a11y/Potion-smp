package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Frost/Freeze Potion ability implementation.
 * Old active (Arctic Prison) and passive (10-hit stun) abilities and cooldowns
 * have been removed to prepare for new ability implementation.
 */
public class FreezeAbility implements Ability {

    @Override
    public PotionType type() {
        return PotionType.FREEZE;
    }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        // Old on-hit passive removed; ready for new ability implementation.
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        // Old active ability and cooldown removed; ready for new ability implementation.
        return ActivationResult.SUCCESS;
    }
}
