package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/**
 * Haste Potion ability implementation.
 * Old active (Haste Rush / Vein Miner / Efficiency 10) and passive
 * (permanent Haste, pickaxe enchants) abilities, listeners, and cooldowns
 * have been removed to prepare for new ability implementation.
 */
public class HasteAbility implements Ability {

    @Override
    public PotionType type() {
        return PotionType.HASTE;
    }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        // Old passive removed; ready for new ability implementation.
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        // Old on-hit passive removed; ready for new ability implementation.
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        // Old active ability and cooldown removed; ready for new ability implementation.
        return ActivationResult.SUCCESS;
    }

    /**
     * Legacy cleanup stub retained for compatibility with PotionSMP shutdown.
     */
    public void restoreAllTrackedItems(PotionSMP plugin) {
        // No tracked items in clean ability foundation.
    }
}
