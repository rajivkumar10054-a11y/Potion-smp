package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * @deprecated Obsolete v45 aura manager. Fire Potion now uses the fixed 10x10 ground zone in FireAbility.
 * Retained solely for architectural compatibility; do not use for new implementations.
 */
@Deprecated
public class FireAuraManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> activeTasks = new HashMap<>();
    private final Random random = new Random();

    public FireAuraManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    /**
     * @deprecated The old damaging aura is disabled. Redesigned Fire Potion uses Fire Burst zone in FireAbility.
     */
    @Deprecated
    public void activateInfernoAura(Player player, int durationTicks, int radius) {
        // Disabled to prevent obsolete damaging aura from executing alongside redesigned Fire abilities.
    }

    public void cancelAura(UUID uid) {
        Integer taskId = activeTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
    }

    public void cancelAll() {
        for (int id : activeTasks.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        activeTasks.clear();
    }
}
