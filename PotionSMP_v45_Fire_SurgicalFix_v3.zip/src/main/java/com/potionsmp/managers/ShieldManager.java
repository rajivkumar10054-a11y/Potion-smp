package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages Shield Potion's Divine Barrier:
 *  - Complete damage immunity
 *  - Knockback immunity
 *  - Two intersecting particle rings (vertical clockwise + horizontal counter-clockwise)
 *    that follow player yaw/pitch in real time
 *  - Hit effect: white flash + shockwave + glass shard burst
 */
public class ShieldManager {

    private final PotionSMP plugin;
    private final Map<UUID, Boolean> shielded = new HashMap<>();
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<>();

    public ShieldManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isShielded(UUID uuid) {
        // Ender Domain suppresses Shield's protection: even if a player
        // successfully activated Divine Barrier before entering the domain,
        // it must stop protecting them the instant they're suppressed. Both
        // CombatListener checks (damage immunity + knockback immunity) go
        // through this one method, so gating it here is sufficient.
        if (plugin.getEnderDomainManager().isSuppressed(uuid)) return false;
        return shielded.getOrDefault(uuid, false);
    }

    public void activateShield(Player player, int durationTicks) {
        UUID uid = player.getUniqueId();

        // Re-activation replaces the previous Shield state/task for this player.
        cancelExpiryTask(uid);
        shielded.put(uid, true);
        player.sendMessage(PotionUtils.colorize("&f🛡 Divine Barrier active!"));

        // All visuals (activation burst, 3-layer rotating barrier, shield
        // fragments, core energy, and the end-of-duration collapse) are
        // handled entirely by ShieldAuraManager — kept as the single
        // visual system so it never runs alongside a duplicate set of
        // particles here.
        plugin.getShieldAuraManager().startDivineBarrier(player, durationTicks);

        // Auto-deactivate immunity after duration. This checks the actual
        // stored Shield state, not isShielded(), because Ender Domain
        // suppression intentionally makes isShielded() return false.
        BukkitTask expiryTask = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            expiryTasks.remove(uid);
            if (shielded.remove(uid) != null) {
                plugin.getShieldAuraManager().stopDivineBarrier(uid);
                if (player.isOnline()) {
                    player.sendMessage(PotionUtils.colorize("&7Divine Barrier has faded."));
                }
            }
        }, durationTicks + 1);
        expiryTasks.put(uid, expiryTask);
    }

    /** Spawns hit effect when damage is blocked */
    public void spawnHitEffect(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);
        // White flash
        loc.getWorld().spawnParticle(Particle.DUST, loc, 14, 0.4, 0.4, 0.4, 0,
            new Particle.DustOptions(Color.WHITE, 1.2f));
        // Ripple ring (visual only): evenly spaced, with a purple accent
        // every 4th point so it reads as a barrier pulse rather than a blast.
        Particle.DustOptions purple = new Particle.DustOptions(Color.fromRGB(165, 105, 255), 1.0f);
        for (int i = 0; i < 20; i++) {
            double a = Math.toRadians(18.0 * i);
            double x = Math.cos(a) * 2.0;
            double z = Math.sin(a) * 2.0;
            if (i % 4 == 0) {
                loc.getWorld().spawnParticle(Particle.DUST,
                    loc.getX() + x, loc.getY(), loc.getZ() + z, 1, 0, 0, 0, 0, purple);
            } else {
                loc.getWorld().spawnParticle(Particle.END_ROD,
                    loc.getX() + x, loc.getY(), loc.getZ() + z, 1, 0, 0, 0, 0);
            }
        }
        // Glass shard burst
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 12, 0.5, 0.5, 0.5, 0.3);
        loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.5f, 2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_HURT, 0.8f, 2f);
    }

    private void deactivateShield(Player player) {
        UUID uid = player.getUniqueId();
        cancelExpiryTask(uid);
        shielded.remove(uid);
        // Stop the visual barrier if it's somehow still running. Under
        // normal timing ShieldAuraManager's own task already finished and
        // played its end-of-duration collapse a tick earlier (both are
        // started with the same durationTicks) — this is just a safety
        // cleanup, not a second ending animation.
        plugin.getShieldAuraManager().stopDivineBarrier(uid);
    }

    /** Removes all Shield state belonging only to this player. */
    public void cleanupPlayer(UUID uid) {
        cancelExpiryTask(uid);
        shielded.remove(uid);
        plugin.getShieldAuraManager().stopDivineBarrier(uid);
    }

    private void cancelExpiryTask(UUID uid) {
        BukkitTask task = expiryTasks.remove(uid);
        if (task != null) {
            task.cancel();
        }
    }

    /** Plugin-wide shutdown cleanup only. */
    public void cancelAll() {
        for (BukkitTask task : expiryTasks.values()) {
            task.cancel();
        }
        expiryTasks.clear();
        shielded.clear();
    }
}
