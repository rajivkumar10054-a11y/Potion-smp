package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Feather Potion — plugin-controlled, Elytra-like flight WITHOUT ever
 * giving/equipping an actual Elytra item. This is the ONLY Feather flight
 * system in the codebase; the old "slow descent while falling" glide loop
 * has been fully removed (see FeatherAbility.java).
 *
 * Activation: the player must have Feather equipped, be airborne (not on
 * ground, not in water/lava), and be at least `flight-min-altitude` blocks
 * above the nearest solid ground below them. Altitude is measured with a
 * downward ray trace, not just onGround()/a fixed Y check.
 *
 * While flying: Feather keeps the player in Minecraft's vanilla fall-flying
 * state. The 1.21.11 LivingEntity travelGliding/calcGlidingVelocity path
 * therefore supplies momentum, pitch control, drag, gravity interaction,
 * steering and collision behavior. No Elytra item is equipped.
 *
 * This manager never touches the player's chest slot / inventory.
 */
public class FeatherFlightManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitTask> flightTasks = new HashMap<>();
    private final Set<UUID> activationArmed = new HashSet<>();
    // Armed players who have actually been seen airborne since their Jump
    // press. Landing only cancels an armed activation once this is true, so
    // the takeoff frame (Jump pressed while still on the ground) can never
    // cancel it.
    private final Set<UUID> armedAirborne = new HashSet<>();
    // Server tick of each player's most recent Jump press (armed players only).
    private final Map<UUID, Integer> armedAtTick = new HashMap<>();
    // A Jump press that never leaves the ground (e.g. a low ceiling) must not
    // stay armed forever. This only applies while the player is standing on
    // the ground; it never interrupts a climb.
    private static final int GROUNDED_ARM_GRACE_TICKS = 10;

    // Short grace window after flight ends during which fall damage is
    // still cancelled (covers the same-tick landing case where the
    // EntityDamageEvent for FALL can fire right as/just after we stop the
    // task). Cleared automatically a few ticks later — this is NOT a
    // standing fall-damage immunity, just a landing-frame safety net.
    private final Set<UUID> recentlyFlying = new HashSet<>();

    public FeatherFlightManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isFlying(UUID uid) {
        return flightTasks.containsKey(uid);
    }

    public boolean isActivationArmed(UUID uid) {
        return activationArmed.contains(uid);
    }

    /**
     * Existing flight-state fall-damage helper retained for compatibility.
     * FeatherAbility now applies equipped-state fall immunity separately.
     */
    public boolean shouldCancelFallDamage(UUID uid) {
        return flightTasks.containsKey(uid) || recentlyFlying.contains(uid);
    }

    /**
     * Arm Feather flight after an actual jump-button press. This is separate
     * from the flight state so pressing jump while already airborne is also
     * required to start flight.
     */
    public void armFlight(Player player) {
        UUID uid = player.getUniqueId();
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return;
        activationArmed.add(uid);
        armedAtTick.put(uid, plugin.getServer().getCurrentTick());
        // A fresh press starts a fresh attempt: already airborne now, or
        // still waiting to leave the ground.
        if (player.isOnGround()) {
            armedAirborne.remove(uid);
        } else {
            armedAirborne.add(uid);
        }
        tryStartFlight(player);
    }

    /** Ends the current activation opportunity (armed state and its bookkeeping). */
    private void clearArmed(UUID uid) {
        activationArmed.remove(uid);
        armedAirborne.remove(uid);
        armedAtTick.remove(uid);
    }

    /**
     * Check whether an armed jump now satisfies the existing flight
     * conditions. No Y-movement value is used as an activation trigger.
     */
    public void tryStartFlight(Player player) {
        UUID uid = player.getUniqueId();
        if (flightTasks.containsKey(uid)) return;
        if (!activationArmed.contains(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) {
            clearArmed(uid);
            return;
        }
        if (player.isOnGround()) {
            // Back on the ground without having started flight: the armed
            // jump attempt is over and a fresh Jump press is required. Only
            // once the player has actually been airborne since the press
            // (so the takeoff frame cannot cancel it); a press that never
            // leaves the ground is dropped after a short grace period.
            Integer armedAt = armedAtTick.get(uid);
            if (armedAirborne.contains(uid)
                    || (armedAt != null
                        && plugin.getServer().getCurrentTick() - armedAt > GROUNDED_ARM_GRACE_TICKS)) {
                clearArmed(uid);
            }
            return;
        }
        // Airborne (still climbing toward the altitude threshold is fine —
        // the armed state is kept while waiting).
        armedAirborne.add(uid);
        if (isInLiquid(player)) return;

        // Don't fight vanilla creative/spectator flight.
        GameMode mode = player.getGameMode();
        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) return;

        double minAltitude = plugin.getConfig().getDouble("potions.feather.flight-min-altitude", 5.0);
        if (distanceToGround(player) < minAltitude) return;

        clearArmed(uid);
        startFlight(player);
    }

    private void startFlight(Player player) {
        UUID uid = player.getUniqueId();
        recentlyFlying.remove(uid);

        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    stopFlight(player);
                    return;
                }
                if (!plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
                    stopFlight(player);
                    return;
                }
                if (isInLiquid(player)) {
                    stopFlight(player);
                    return;
                }
                if (player.isOnGround()) {
                    playLandingEffect(player);
                    stopFlight(player);
                    return;
                }

                // Keep the vanilla fall-flying state alive. No custom velocity
                // calculation is performed here; Minecraft applies its own
                // 1.21.11 Elytra physics during entity travel.
                if (!player.isGliding()) {
                    player.setGliding(true);
                }

            }
        };

        BukkitTask handle = task.runTaskTimer(plugin, 0L, 1L);
        flightTasks.put(uid, handle);

        // Put the flight state in the authoritative map first so the
        // EntityToggleGlideEvent guard is active before the no-Elytra glide
        // state is requested. Vanilla then owns the actual movement physics.
        player.setGliding(true);
    }

    public void stopFlight(Player player) {
        UUID uid = player.getUniqueId();
        clearArmed(uid);
        BukkitTask task = flightTasks.remove(uid);
        if (task != null) task.cancel();
        if (player.isGliding()) {
            player.setGliding(false);
        }
        // Brief landing-frame grace window for fall-damage cancellation —
        // NOT a standing immunity. Cleared automatically shortly after.
        recentlyFlying.add(uid);
        plugin.getServer().getScheduler().runTaskLater(plugin,
            () -> recentlyFlying.remove(uid), 10L);
    }

    public void cancelAll() {
        Set<UUID> flying = new HashSet<>(flightTasks.keySet());
        for (BukkitTask task : flightTasks.values()) {
            task.cancel();
        }
        // Clear authoritative state before changing the glide flag so the
        // EntityToggleGlideEvent guard cannot cancel our own shutdown.
        flightTasks.clear();
        activationArmed.clear();
        armedAirborne.clear();
        armedAtTick.clear();
        recentlyFlying.clear();

        for (UUID uid : flying) {
            Player player = plugin.getServer().getPlayer(uid);
            if (player != null && player.isGliding()) {
                player.setGliding(false);
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    /**
     * Distance from the player's current location straight down to the
     * nearest solid block below them, via a downward ray trace. Returns
     * Double.MAX_VALUE if nothing solid is found within range (i.e.
     * definitely high enough to fly).
     */
    private double distanceToGround(Player player) {
        World world = player.getWorld();
        Location start = player.getLocation();
        RayTraceResult result = world.rayTraceBlocks(start, new Vector(0, -1, 0),
            320.0, FluidCollisionMode.NEVER, true);
        if (result == null || result.getHitPosition() == null) {
            return Double.MAX_VALUE;
        }
        return start.getY() - result.getHitPosition().getY();
    }

    private boolean isInLiquid(Player player) {
        return isLiquid(player.getLocation().getBlock().getType())
            || isLiquid(player.getEyeLocation().getBlock().getType());
    }

    private boolean isLiquid(Material m) {
        return m == Material.WATER || m == Material.LAVA;
    }

    private void playLandingEffect(Player player) {
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CLOUD, loc, 8, 0.4, 0.1, 0.4, 0.05);
        loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_STEP, 0.8f, 1.2f);
    }

}
