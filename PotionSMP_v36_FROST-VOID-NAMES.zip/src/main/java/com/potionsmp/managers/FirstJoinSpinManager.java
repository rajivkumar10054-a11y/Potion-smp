package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ItemBuilder;
import com.potionsmp.utils.PotionType;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * First-time-join random potion wheel.
 *
 * <p>Flow: join → eligibility check → server picks ONE potion (equal odds) →
 * the pick is stored as a "pending" PDC value → a 54-slot inventory shows the
 * 12 potions on a ring under a fixed pointer → the ring rotates, slows, and
 * stops with the pre-selected potion under the pointer → the real PotionSMP
 * item (via {@link ItemBuilder#buildPotion}) is delivered → only then is
 * {@code first_spin_awarded} written and the pending value removed.
 *
 * <p>Safety model (one UUID → at most one reward):
 * <ul>
 *   <li>{@code first_spin_awarded} (player PDC, survives restarts) is written
 *       strictly AFTER delivery. If set, the player never spins again.</li>
 *   <li>{@code first_spin_pending} stores the server-chosen result before the
 *       animation starts. If the player quits / server stops mid-spin, nothing
 *       has been given; on the next join the SAME stored result is spun again
 *       (never re-rolled), so there is still exactly one possible reward.</li>
 *   <li>Players with any other PotionSMP player-PDC data (slot keys, i.e. they
 *       have ever drunk a potion) are treated as existing players: no spin.</li>
 * </ul>
 *
 * <p>All state is touched on the main thread only. One repeating task per
 * active session; cancelled on quit, on completion and in {@link #shutdown()}.
 */
public class FirstJoinSpinManager implements Listener {

    /**
     * SINGLE SOURCE OF TRUTH for the wheel order / index→potion mapping:
     * 0=FIRE 1=FREEZE 2=REGEN 3=GLITCH 4=SHIELD 5=ENDER 6=TELEPORT 7=SPEED
     * 8=FEATHER 9=EMERALD 10=STRENGTH 11=HASTE (the declaration order of
     * {@link PotionType}). Used by the RNG, the wheel animation and the reward.
     */
    private static final PotionType[] WHEEL = PotionType.values();

    // 54-slot chest layout (row*9+col). Ring positions are listed clockwise
    // starting at the top-centre; ring position 0 sits directly under the pointer.
    private static final int[] RING = {13, 14, 24, 34, 42, 50, 49, 48, 38, 28, 20, 12};
    private static final int POINTER_SLOT = 4;
    private static final int CENTER_SLOT = 31;

    private static final int FULL_ROTATIONS_TICKS_BASE = 24; // min steps before landing (2 full turns)
    private static final long START_DELAY_TICKS = 20L;       // let the client finish loading
    private static final int  HOLD_TICKS = 50;               // show the result before closing

    private final PotionSMP plugin;
    private final NamespacedKey awardedKey;
    private final NamespacedKey pendingKey;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public FirstJoinSpinManager(PotionSMP plugin) {
        this.plugin = plugin;
        this.awardedKey = new NamespacedKey(plugin, "first_spin_awarded");
        this.pendingKey = new NamespacedKey(plugin, "first_spin_pending");
        if (WHEEL.length != 12) {
            plugin.getLogger().warning("[FirstJoinSpin] Expected 12 potion types but found "
                + WHEEL.length + "; wheel layout supports exactly 12.");
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ── Eligibility ───────────────────────────────────────────────────────

    private enum Verdict { ALREADY_AWARDED, EXISTING_PLAYER, RESUME, NEW }

    private Verdict evaluate(Player player) {
        PersistentDataContainer pdc = player.getPersistentDataContainer();

        if (pdc.has(awardedKey, PersistentDataType.BOOLEAN)) return Verdict.ALREADY_AWARDED;

        // Interrupted earlier spin: result already chosen and persisted, nothing delivered.
        if (PotionType.fromId(pdc.get(pendingKey, PersistentDataType.STRING)) != null) return Verdict.RESUME;

        // Joined this server before (i.e. existed before this feature): never eligible.
        if (player.hasPlayedBefore()) return Verdict.EXISTING_PLAYER;

        // Any other PotionSMP data on this player => not a first-timer.
        for (NamespacedKey k : pdc.getKeys()) {
            if (k.getNamespace().equals(awardedKey.getNamespace())
                    && !k.equals(awardedKey) && !k.equals(pendingKey)) {
                return Verdict.EXISTING_PLAYER;
            }
        }
        UUID id = player.getUniqueId();
        if (plugin.getSlotManager().getSlot1(id) != null || plugin.getSlotManager().getSlot2(id) != null) {
            return Verdict.EXISTING_PLAYER;
        }
        return Verdict.NEW;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (sessions.containsKey(player.getUniqueId())) return;

        switch (evaluate(player)) {
            case ALREADY_AWARDED -> plugin.getLogger().info("[FirstJoinSpin] Player "
                + player.getName() + " already has first-spin reward; skipping.");
            case EXISTING_PLAYER -> plugin.getLogger().info("[FirstJoinSpin] Player "
                + player.getName() + " is an existing player; skipping.");
            case RESUME -> {
                PotionType pending = PotionType.fromId(
                    player.getPersistentDataContainer().get(pendingKey, PersistentDataType.STRING));
                startSession(player, pending);
            }
            case NEW -> {
                // Server-side, equal-probability pick over the single WHEEL mapping.
                int index = ThreadLocalRandom.current().nextInt(WHEEL.length);
                PotionType result = WHEEL[index];
                player.getPersistentDataContainer().set(pendingKey, PersistentDataType.STRING, result.getId());
                startSession(player, result);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Session s = sessions.remove(event.getPlayer().getUniqueId());
        if (s != null) s.cancelQuietly(false); // pending result stays persisted; no reward given
    }

    // Keep the wheel GUI read-only.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof SpinHolder) event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof SpinHolder) event.setCancelled(true);
    }

    /** Plugin disable: cancel every task, close wheels, clear runtime state. Persistent data untouched. */
    public void shutdown() {
        for (Session s : new HashSet<>(sessions.values())) s.cancelQuietly(true);
        sessions.clear();
    }

    private void startSession(Player player, PotionType result) {
        Session s = new Session(player.getUniqueId(), result);
        sessions.put(player.getUniqueId(), s);
        s.runTaskTimer(plugin, START_DELAY_TICKS, 1L);
    }

    // ── Spin session ──────────────────────────────────────────────────────

    private static final class SpinHolder implements InventoryHolder {
        private Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private enum Phase { OPEN, SPIN, HOLD }

    private final class Session extends BukkitRunnable {
        private final UUID uuid;
        private final PotionType result;
        private final int resultIndex;
        private final int totalSteps;
        private final SpinHolder holder = new SpinHolder();
        private final ItemStack[] icons = new ItemStack[WHEEL.length];
        private final ItemStack[] iconsHi = new ItemStack[WHEEL.length];

        private Phase phase = Phase.OPEN;
        private int tick = 0;
        private int step = 0;
        private int nextStepAt = 0;
        private int holdUntil = 0;

        Session(UUID uuid, PotionType result) {
            this.uuid = uuid;
            this.result = result;
            this.resultIndex = indexOf(result);
            // r after N steps = N mod 12 = resultIndex  ->  chosen potion ends at ring position 0 (under pointer).
            this.totalSteps = FULL_ROTATIONS_TICKS_BASE + resultIndex;
        }

        @Override
        public void run() {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null || !p.isOnline()) { finish(false); return; }

            switch (phase) {
                case OPEN -> {
                    buildInventory();
                    p.openInventory(holder.inv);
                    phase = Phase.SPIN;
                    nextStepAt = 10; // short beat so the player sees the full wheel first
                }
                case SPIN -> {
                    tick++;
                    // If the player closed/replaced the wheel mid-spin, put it back.
                    if (p.getOpenInventory().getTopInventory().getHolder() != holder) {
                        p.openInventory(holder.inv);
                    }
                    if (tick < nextStepAt) return;
                    step++;
                    renderRing(step);
                    p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.0f + 0.5f * step / totalSteps);
                    if (step >= totalSteps) {
                        phase = Phase.HOLD; // set first so an exception below can never re-run delivery
                        holdUntil = tick + HOLD_TICKS;
                        renderResult();
                        deliver(p);
                    } else {
                        double progress = (double) step / totalSteps;
                        nextStepAt = tick + 2 + (int) (8.0 * progress * progress); // 2 → 10 ticks: fast, then slows
                    }
                }
                case HOLD -> {
                    tick++;
                    if (tick >= holdUntil) finish(true);
                }
            }
        }

        // ── Reward ────────────────────────────────────────────────────────

        private void deliver(Player p) {
            ItemStack item = ItemBuilder.buildPotion(result); // the real PotionSMP item
            Map<Integer, ItemStack> leftover = p.getInventory().addItem(item);
            if (!leftover.isEmpty()) {
                for (ItemStack rest : leftover.values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), rest);
                }
                p.sendMessage("§eYour inventory was full; your potion has been dropped nearby.");
            }

            // Flag only AFTER the item is in the inventory or on the ground.
            PersistentDataContainer pdc = p.getPersistentDataContainer();
            pdc.set(awardedKey, PersistentDataType.BOOLEAN, true);
            pdc.remove(pendingKey);

            p.sendMessage("§aYou received: " + result.getDisplayName());
            p.sendTitle("§6✦ " + result.getDisplayName() + " §6✦", "§7You received", 5, 40, 10);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            plugin.getLogger().info("[FirstJoinSpin] Player " + p.getName() + " (" + uuid
                + ") received " + result.name() + " potion.");
        }

        // ── Rendering ─────────────────────────────────────────────────────

        private void buildInventory() {
            holder.inv = Bukkit.createInventory(holder, 54, Component.text("§6§l✦ Potion Wheel ✦"));

            ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
            for (int i = 0; i < 54; i++) holder.inv.setItem(i, filler);
            holder.inv.setItem(POINTER_SLOT, named(Material.HOPPER, "§e§l▼ POINTER ▼"));

            for (int i = 0; i < WHEEL.length; i++) {
                icons[i] = icon(WHEEL[i], false);
                iconsHi[i] = icon(WHEEL[i], true);
            }
            renderRing(0);
        }

        /** Ring position p shows potion (p + offset) mod 12; position 0 is under the pointer. */
        private void renderRing(int offset) {
            for (int pos = 0; pos < RING.length; pos++) {
                int idx = (pos + offset) % WHEEL.length;
                holder.inv.setItem(RING[pos], pos == 0 ? iconsHi[idx] : icons[idx]);
            }
            int underPointer = offset % WHEEL.length;
            holder.inv.setItem(CENTER_SLOT, named(Material.NETHER_STAR,
                "§7Spinning... " + WHEEL[underPointer].getDisplayName()));
        }

        private void renderResult() {
            ItemStack star = named(Material.NETHER_STAR, "§a§lYou received: " + result.getDisplayName());
            ItemMeta m = star.getItemMeta();
            m.setEnchantmentGlintOverride(true);
            star.setItemMeta(m);
            holder.inv.setItem(CENTER_SLOT, star);
        }

        private ItemStack icon(PotionType type, boolean highlighted) {
            ItemStack item = ItemBuilder.buildPotion(type);
            ItemMeta meta = item.getItemMeta();
            // Make the display copy inert: strip PotionSMP tags so it can never be mistaken for a real potion.
            PersistentDataContainer c = meta.getPersistentDataContainer();
            for (NamespacedKey k : new HashSet<>(c.getKeys())) c.remove(k);
            if (highlighted) {
                meta.setDisplayName("§e▶ " + type.getDisplayName() + " §e◀");
                meta.setEnchantmentGlintOverride(true);
            } else {
                meta.setDisplayName(type.getDisplayName());
            }
            meta.setLore(List.of("§8Wheel preview"));
            item.setItemMeta(meta);
            return item;
        }

        private ItemStack named(Material mat, String name) {
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(name);
            item.setItemMeta(meta);
            return item;
        }

        // ── Cleanup ───────────────────────────────────────────────────────

        private void finish(boolean closeWheel) {
            sessions.remove(uuid);
            cancelQuietly(closeWheel);
        }

        void cancelQuietly(boolean closeWheel) {
            try { cancel(); } catch (IllegalStateException ignored) { /* never scheduled / already cancelled */ }
            if (closeWheel) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.getOpenInventory().getTopInventory().getHolder() == holder) p.closeInventory();
            }
        }
    }

    private static int indexOf(PotionType type) {
        for (int i = 0; i < WHEEL.length; i++) if (WHEEL[i] == type) return i;
        throw new IllegalStateException("PotionType not on wheel: " + type);
    }
}
