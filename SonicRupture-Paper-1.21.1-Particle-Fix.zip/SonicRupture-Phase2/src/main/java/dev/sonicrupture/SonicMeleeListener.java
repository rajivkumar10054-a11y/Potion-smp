package dev.sonicrupture;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/** Sonic Rupture-only melee rule. Normal Netherite Swords are untouched. */
public final class SonicMeleeListener implements Listener {
    private final SonicRupturePlugin plugin;

    public SonicMeleeListener(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player player)) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;
        if (!plugin.items().isSonic(player.getInventory().getItemInMainHand())) return;

        // A sneaking entity hit is also a SHIFT + LEFT CLICK activation. The
        // Inferno cooldown/state guard prevents duplicate activation.
        if (player.isSneaking()) plugin.abilities().tryInfernoBurst(player);
        if (target.isInvulnerable() || target.isDead()) return;

        // Keep the normal melee event/durability flow. A very large damage value
        // makes the hit lethal even after normal armor/damage reductions.
        e.setDamage(Math.max(e.getDamage(), 1000000.0));
    }
}
