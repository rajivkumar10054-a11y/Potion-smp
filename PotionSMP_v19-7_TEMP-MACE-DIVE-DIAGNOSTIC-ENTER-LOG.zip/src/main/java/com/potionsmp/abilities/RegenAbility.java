package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

public class RegenAbility implements Ability, Listener {

    @Override
    public PotionType type() { return PotionType.REGEN; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Don't grant the passive regen while inside an Abyss Domain — once
        // the player leaves (or the domain ends), EnderDomainManager itself
        // calls this same method again to restore it.
        if (plugin.getEnderDomainManager().isSuppressed(player.getUniqueId())) return;
        int amp = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, amp, false, false));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.REGENERATION);
        plugin.getRegenAbilityManager().clearCharge(player.getUniqueId());
        plugin.getRegenAbilityManager().closeWindow(player.getUniqueId());
        plugin.getVitalityParticleRenderer().stop(player.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        UUID uid = event.getEntity().getUniqueId();
        plugin.getRegenAbilityManager().clearTransient(uid);
        plugin.getVitalityParticleRenderer().stop(uid);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;
        UUID uid = event.getPlayer().getUniqueId();
        plugin.getRegenAbilityManager().clearTransient(uid);
        plugin.getVitalityParticleRenderer().stop(uid);
    }

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        plugin.getLogger().info("[MACE-DIVE-DIAG] RegenAbility.onHit ENTER "
                + "attacker=" + player.getName()
                + ", target=" + target.getName()
                + ", targetClass=" + target.getClass().getName()
                + ", targetIsPlayer=" + (target instanceof Player));
        // TEMPORARY DIAGNOSTIC ONLY: Mace Dive currently receives its target
        // from the normal EntityDamageByEntityEvent path; it does not perform
        // its own nearby-entity search here. Log the exact candidate handed
        // to Regen so we can determine whether Players reach this path.
        boolean charged = plugin.getRegenAbilityManager().isChargedForDive(player.getUniqueId());
        plugin.getLogger().info("[MACE-DIVE-DIAG] Candidate received by RegenAbility.onHit: "
                + "class=" + target.getClass().getName()
                + ", type=" + target.getType()
                + ", name=" + target.getName()
                + ", living=true"
                + ", player=" + (target instanceof Player)
                + ", charged=" + charged
                + ", accepted=" + charged
                + ", reason=" + (charged ? "charged Mace Dive; target handed off as final candidate"
                                          : "Mace Dive not charged; candidate rejected before trigger"));

        if (!charged) return;
        double dmg = plugin.getConfig().getDouble("potions.regen.mace-dive-damage", 10.0) * 2;
        plugin.getRegenAbilityManager().triggerMaceDive(player, target, dmg);
        plugin.getLogger().info("[MACE-DIVE-DIAG] Final selected target: "
                + "class=" + target.getClass().getName()
                + ", type=" + target.getType()
                + ", name=" + target.getName()
                + ", living=true"
                + ", player=" + (target instanceof Player));
        player.sendMessage(PotionUtils.msg("mace-dive-hit").replace("%target%", target.getName()));
    }

    /**
     * Vitality Surge is manually activated only by Sneak + Right Click.
     * The interaction itself is used as the trigger; no movement or jump
     * state is involved.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;

        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin == null) return;

        UUID uid = player.getUniqueId();
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.REGEN)) return;

        boolean firstLaunch = !plugin.getRegenAbilityManager().isWindowActive(uid);
        if (firstLaunch && plugin.getCooldownManager().isOnCooldown(uid, type())) return;

        triggerVitalitySurge(plugin, player);
    }

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        // Regen has no Slot 1 / Slot 2 activation path. Vitality Surge is
        // activated exclusively by Sneak + Right Click.
        return ActivationResult.SUCCESS;
    }

    public void triggerVitalitySurge(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        // Suppressed: refuse to launch while preserving the existing window.
        if (plugin.getEnderDomainManager().isSuppressed(uid)) return;

        boolean firstLaunch = !plugin.getRegenAbilityManager().isWindowActive(uid);

        int height = plugin.getConfig().getInt("potions.regen.active-jump-height", 10);
        int duration = plugin.getConfig().getInt("potions.regen.active-duration", 200);
        int amp = plugin.getConfig().getInt("potions.regen.regen-amplifier", 0);

        if (firstLaunch) {
            player.sendMessage(PotionUtils.msg("regen-active"));

            // Full particle-only Vitality Surge animation (awakening → heart
            // formation → surge → sustained loop), started ONCE here and
            // left running for the full active-duration window — it is
            // NOT restarted on subsequent re-launches within that window.
            plugin.getVitalityParticleRenderer().start(player);

            // Cooldown starts on this first real use, not on /slot press.
            int cooldown = plugin.getConfig().getInt("potions.regen.active-cooldown", 45);
            plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

            // Play the visual-only collapse animation once the window's
            // gameplay duration ends. Purely cosmetic — does not touch the
            // regeneration effect, glow, or Mace Dive charge timing.
            plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getVitalityParticleRenderer().playEndAnimation(player),
                duration);
        } else {
            player.sendMessage(PotionUtils.colorize("&a✦ Vitality Surge re-launched!"));
        }

        plugin.getRegenAbilityManager().launch(player, height, duration, amp + 1, firstLaunch);
    }
}
