package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles freezing entities in place - used both by Freeze's passive
 * (brief 1s "struck"/stun on every 10th hit) and its active Arctic Prison
 * (full 3s area freeze). Locks position every tick and applies heavy
 * Slowness/Mining Fatigue so the entity can't move, attack, mine, or act.
 */
public class FrozenPlayerManager {

    private final PotionSMP plugin;
    private final Map<UUID, Location> frozenEntities = new HashMap<>();
    private final Map<UUID, Integer> frozenTaskIds = new HashMap<>();

    private static final Particle.DustOptions FROST_LOCK_CYAN =
            new Particle.DustOptions(Color.fromRGB(185, 241, 255), 0.7f);

    public FrozenPlayerManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        Location loc = entity.getLocation().clone();
        frozenEntities.put(uid, loc);

        int dur = durationTicks + 5;
        if (entity instanceof Player player) {
            // Routed through EffectOwnershipManager so this never blindly
            // clobbers/deletes another PotionSMP ability's own claim on the
            // same effect type (e.g. Glitch's permanent Mining Fatigue) or a
            // vanilla/other-plugin effect the target already had.
            var ownership = plugin.getEffectOwnershipManager();
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
            ownership.apply(player, PotionType.FREEZE,
                new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false));
        } else {
            // Non-player targets (mobs) can't hold PotionSMP claims of
            // their own, so there's nothing to route through ownership for.
            entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
            entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
            entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false));
        }

        // Cancel any previous freeze task for this entity before starting a new one
        Integer existing = frozenTaskIds.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable lockTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks || !entity.isValid()) {
                    unfreeze(entity);
                    cancel();
                    return;
                }
                if (entity.getLocation().distanceSquared(loc) > 0.1) {
                    entity.teleport(loc);
                }
                entity.setVelocity(new Vector(0, 0, 0));

                // Sparse frost accent while locked — every 4th tick, single
                // cyan particle, instead of the old 9-particle-per-tick
                // SNOWFLAKE/ITEM_SNOWBALL cloud.
                if (ticks % 4 == 0) {
                    entity.getWorld().spawnParticle(Particle.DUST, entity.getLocation().add(0, 1, 0),
                            1, 0.2, 0.3, 0.2, 0, FROST_LOCK_CYAN);
                }

                ticks++;
            }
        };
        int taskId = lockTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        frozenTaskIds.put(uid, taskId);
    }

    public void unfreeze(LivingEntity entity) {
        UUID uid = entity.getUniqueId();
        frozenEntities.remove(uid);
        Integer taskId = frozenTaskIds.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);

        if (entity instanceof Player player) {
            var ownership = plugin.getEffectOwnershipManager();
            ownership.clear(player, PotionType.FREEZE, PotionEffectType.SLOWNESS);
            ownership.clear(player, PotionType.FREEZE, PotionEffectType.MINING_FATIGUE);
            ownership.clear(player, PotionType.FREEZE, PotionEffectType.JUMP_BOOST);
        } else {
            entity.removePotionEffect(PotionEffectType.SLOWNESS);
            entity.removePotionEffect(PotionEffectType.MINING_FATIGUE);
            entity.removePotionEffect(PotionEffectType.JUMP_BOOST);
        }
    }

    public boolean isFrozen(UUID uid) {
        return frozenEntities.containsKey(uid);
    }

    public void unfreezeAll() {
        for (int id : frozenTaskIds.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        frozenEntities.clear();
        frozenTaskIds.clear();
    }
}
