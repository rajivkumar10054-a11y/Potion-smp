package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Handles Regen Potion's active ability (Vitality Surge).
 * The activation trigger is owned by RegenAbility and is exclusively
 * Sneak + Right Click; this manager only handles the existing surge state,
 * launch, effects, cooldown window, and Mace Dive charge.
 */
public class RegenAbilityManager {

    private final PotionSMP plugin;

    // Players currently airborne+charged for a bonus Mace Dive hit
    private final Set<UUID> chargedForDive = new HashSet<>();

    // Players inside their active-duration window: opened by the FIRST
    // manual Surge launch, stays open for durationTicks, during which any
    // further manual activation re-triggers a launch (no new cooldown
    // needed). Closes automatically once the window's duration elapses.
    private final Set<UUID> windowActive = new HashSet<>();

    public RegenAbilityManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isWindowActive(UUID uuid) {
        return windowActive.contains(uuid);
    }

    /**
     * Opens the multi-use window for durationTicks. Called once, on the
     * first launch of a Vitality Surge cycle — re-launches inside the
     * window don't reopen/extend it.
     */
    private void openWindow(UUID uuid, int durationTicks) {
        windowActive.add(uuid);
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> windowActive.remove(uuid), durationTicks);
    }

    /** Cleanup — e.g. on unequip. */
    public void closeWindow(UUID uuid) {
        windowActive.remove(uuid);
    }

    /**
     * Clears all short-lived Vitality Surge state for lifecycle events such as
     * death or disconnect. Equipped potion slots remain untouched, so the
     * normal passive can still be reapplied after respawn/reconnect.
     */
    public void clearTransient(UUID uuid) {
        chargedForDive.remove(uuid);
        windowActive.remove(uuid);
    }

    public boolean isChargedForDive(UUID uuid) {
        return chargedForDive.contains(uuid);
    }

    public void clearCharge(UUID uuid) {
        chargedForDive.remove(uuid);
    }

    /**
     * Performs the launch + regen/glow window. On the FIRST launch of a
     * cycle (firstLaunch = true) this opens the multi-use window for
     * durationTicks. Re-launches during that window (firstLaunch = false)
     * just re-apply velocity/effects — they don't reopen the window.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier, boolean firstLaunch) {
        UUID uid = player.getUniqueId();

        if (firstLaunch) {
            openWindow(uid, durationTicks);
        }

        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));

        chargedForDive.add(uid);

        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, durationTicks, regenAmplifier, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationTicks, 0, false, false));

        Location loc = player.getLocation();
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 1f, 1.2f);

        runLandingWatcher(player);
    }

    private void runLandingWatcher(Player player) {
        UUID uid = player.getUniqueId();
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks > 200) {
                    cancel();
                    return;
                }
                if (player.isOnGround() && ticks > 2) {
                    chargedForDive.remove(uid);
                    cancel();
                    return;
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    public void triggerMaceDive(Player player, LivingEntity target, double diveDamage) {
        UUID uid = player.getUniqueId();
        chargedForDive.remove(uid);

        ProgrammaticDamageGuard.beginSuppression(uid);
        try {
            target.damage(diveDamage, player);
        } finally {
            ProgrammaticDamageGuard.endSuppression(uid);
        }

        Location loc = target.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 1, 0), 25, 0.6, 0.6, 0.6, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 30, 0.6, 0.4, 0.6, 0.3);

        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI * i) / 30;
            double x = loc.getX() + 1.5 * Math.cos(angle);
            double z = loc.getZ() + 1.5 * Math.sin(angle);
            loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, x, loc.getY() + 0.1, z, 1, 0, 0, 0, 0);
        }

        loc.getWorld().playSound(loc, Sound.ITEM_MACE_SMASH_GROUND, 1.2f, 1f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 0.5f);
    }
}
