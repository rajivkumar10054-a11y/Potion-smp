package dev.sonicrupture;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Per-player state: IDLE -> CHARGING -> COOLDOWN -> IDLE.
 * A player has an entry only while not IDLE, so a missing entry means IDLE.
 */
public final class AbilityManager {

    public enum State { IDLE, CHARGING, COOLDOWN }

    private static final class Data {
        State state = State.CHARGING;
        BukkitTask chargeTask;
        BukkitTask cooldownTask;
        long cooldownEndMillis;

        void cancelTasks() {
            if (chargeTask != null) chargeTask.cancel();
            if (cooldownTask != null) cooldownTask.cancel();
            chargeTask = null;
            cooldownTask = null;
        }
    }

    private final SonicRupturePlugin plugin;
    private final Map<UUID, Data> players = new HashMap<>();

    public AbilityManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public State stateOf(UUID id) {
        Data d = players.get(id);
        return d == null ? State.IDLE : d.state;
    }

    public void tryStartCharge(Player p) {
        UUID id = p.getUniqueId();
        Data existing = players.get(id);
        if (existing != null) {
            if (existing.state == State.COOLDOWN) {
                double left = Math.max(0, existing.cooldownEndMillis - System.currentTimeMillis()) / 1000.0;
                p.sendActionBar(plugin.cfg().cooldownMessage(String.format(Locale.ROOT, "%.1f", left)));
            }
            return; // already charging or cooling down
        }

        Data d = new Data();
        players.put(id, d);
        int total = plugin.cfg().chargeTicks();
        plugin.fx().onChargeStart(p);

        d.chargeTask = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                elapsed++;
                tickCharge(id, d, elapsed, total);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void tickCharge(UUID id, Data d, int elapsed, int total) {
        Player p = Bukkit.getPlayer(id);
        if (p == null || !p.isOnline() || p.isDead()
                || !plugin.items().isSonic(p.getInventory().getItemInMainHand())) {
            cancelCharge(id, p);
            return;
        }
        plugin.fx().onChargeTick(p, elapsed, total);
        if (elapsed >= total) release(id, d, p);
    }

    private void cancelCharge(UUID id, Player p) {
        Data d = players.get(id);
        if (d == null || d.state != State.CHARGING) return;
        d.cancelTasks();
        players.remove(id);
        if (p != null) plugin.fx().onChargeCancel(p);
    }

    private void release(UUID id, Data d, Player p) {
        d.chargeTask.cancel();
        d.chargeTask = null;

        Location eye = p.getEyeLocation();      // actual look direction at release
        Vector dir = eye.getDirection();
        plugin.fx().onRelease(p, eye, dir);
        plugin.projectiles().launch(p, eye, dir);

        int cd = plugin.cfg().cooldownTicks();
        if (cd <= 0) {
            players.remove(id);
            return;
        }
        d.state = State.COOLDOWN;
        d.cooldownEndMillis = System.currentTimeMillis() + cd * 50L;
        d.cooldownTask = Bukkit.getScheduler().runTaskLater(plugin, () -> players.remove(id, d), cd);
    }

    /** Clears only the cooldown. Returns false if the player wasn't cooling down. */
    public boolean clearCooldown(UUID id) {
        Data d = players.get(id);
        if (d == null || d.state != State.COOLDOWN) return false;
        d.cancelTasks();
        players.remove(id);
        return true;
    }

    /** Death / quit: drop everything for this player. */
    public void reset(Player p) {
        Data d = players.remove(p.getUniqueId());
        if (d == null) return;
        boolean wasCharging = d.state == State.CHARGING;
        d.cancelTasks();
        if (wasCharging) plugin.fx().onChargeCancel(p);
    }

    /** Plugin disable. */
    public void resetAll() {
        for (Map.Entry<UUID, Data> e : players.entrySet()) {
            Data d = e.getValue();
            boolean wasCharging = d.state == State.CHARGING;
            d.cancelTasks();
            Player p = Bukkit.getPlayer(e.getKey());
            if (wasCharging && p != null) plugin.fx().onChargeCancel(p);
        }
        players.clear();
    }
}
