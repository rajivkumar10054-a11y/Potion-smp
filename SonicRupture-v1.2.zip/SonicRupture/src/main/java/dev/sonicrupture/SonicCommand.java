package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Stream;

public final class SonicCommand implements TabExecutor {

    private final SonicRupturePlugin plugin;

    public SonicCommand(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("gui")) {
            if (!p.hasPermission("sonicrupture.gui")) {
                p.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
                return true;
            }
            new SonicGui().open(p);
            return true;
        }
        if (args.length >= 1 && args[0].equalsIgnoreCase("reset")) {
            if (!p.hasPermission("sonicrupture.reset")) {
                p.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
                return true;
            }
            Player target = p;
            if (args.length >= 2) {
                target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    p.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
                    return true;
                }
            }
            boolean cleared = plugin.abilities().clearCooldown(target.getUniqueId());
            p.sendMessage(Component.text(cleared
                    ? "Sonic Rupture cooldown removed" + (target == p ? "." : " for " + target.getName() + ".")
                    : "No active cooldown.", cleared ? NamedTextColor.AQUA : NamedTextColor.GRAY));
            return true;
        }
        p.sendMessage(Component.text("Usage: /sonic gui | /sonic reset [player]", NamedTextColor.RED));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            String a = args[0].toLowerCase();
            return Stream.of("gui", "reset").filter(s -> s.startsWith(a)).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("reset")) {
            String a = args[1].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(a)).toList();
        }
        return List.of();
    }
}
