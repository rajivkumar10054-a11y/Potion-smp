package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigManager {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final SonicRupturePlugin plugin;

    private int chargeTicks, cooldownTicks, lifetimeTicks;
    private double speed, maxRange, hitbox, damage, kbHorizontal, kbVertical;
    private boolean stopOnBlocks, sounds;
    private String msgCooldown, msgReceived, msgInventoryFull;

    public ConfigManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.reloadConfig();
        FileConfiguration c = plugin.getConfig();
        chargeTicks = Math.max(1, c.getInt("ability.charge-duration-ticks", 34));
        cooldownTicks = Math.max(0, c.getInt("ability.cooldown-ticks", 100));
        speed = Math.max(0.1, c.getDouble("projectile.speed", 2.0));
        maxRange = Math.max(1.0, c.getDouble("projectile.max-range", 40.0));
        lifetimeTicks = Math.max(1, c.getInt("projectile.max-lifetime-ticks", 60));
        hitbox = Math.max(0.0, c.getDouble("projectile.hitbox-size", 0.4));
        stopOnBlocks = c.getBoolean("projectile.stop-on-blocks", true);
        damage = Math.max(0.0, c.getDouble("damage.amount", 10.0));
        kbHorizontal = c.getDouble("damage.knockback-horizontal", 1.2);
        kbVertical = c.getDouble("damage.knockback-vertical", 0.3);
        sounds = c.getBoolean("sounds.enabled", true);
        msgCooldown = c.getString("messages.cooldown", "<red>Sonic Rupture is on cooldown (<seconds>s)");
        msgReceived = c.getString("messages.received", "<aqua>You received Sonic Rupture.");
        msgInventoryFull = c.getString("messages.inventory-full", "<red>Your inventory is full.");
    }

    public int chargeTicks() { return chargeTicks; }
    public int cooldownTicks() { return cooldownTicks; }
    public int lifetimeTicks() { return lifetimeTicks; }
    public double speed() { return speed; }
    public double maxRange() { return maxRange; }
    public double hitbox() { return hitbox; }
    public double damage() { return damage; }
    public double kbHorizontal() { return kbHorizontal; }
    public double kbVertical() { return kbVertical; }
    public boolean stopOnBlocks() { return stopOnBlocks; }
    public boolean sounds() { return sounds; }

    public Component cooldownMessage(String seconds) {
        return MM.deserialize(msgCooldown.replace("<seconds>", seconds));
    }
    public Component receivedMessage() { return MM.deserialize(msgReceived); }
    public Component inventoryFullMessage() { return MM.deserialize(msgInventoryFull); }
}
