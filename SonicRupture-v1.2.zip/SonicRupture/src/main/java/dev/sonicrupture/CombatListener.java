package dev.sonicrupture;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageModifier;

@SuppressWarnings("deprecation")
public final class CombatListener implements Listener {

    private final SonicRupturePlugin plugin;

    public CombatListener(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    /** Real lightning strike: remove armor / enchant-protection reduction. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onRealStrikeDamage(EntityDamageEvent e) {
        if (!plugin.lightning().isApplyingRealStrike()) return;
        zeroReductions(e, false);
    }

    /** Sonic Rupture melee: one-hit kill, armor ignored. Sonic Boom is excluded. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (plugin.projectiles().isApplyingBoomDamage()) return; // Sonic Boom must not be one-hit
        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity target)) return;
        if (!plugin.items().isSonic(p.getInventory().getItemInMainHand())) return;

        e.setDamage(DamageModifier.BASE, target.getHealth() + target.getAbsorptionAmount() + 1024.0);
        zeroReductions(e, true);
    }

    private static void zeroReductions(EntityDamageEvent e, boolean includePotion) {
        for (DamageModifier m : DamageModifier.values()) {
            if (m == DamageModifier.BASE || m == DamageModifier.ABSORPTION) continue;
            if (!includePotion && m == DamageModifier.RESISTANCE) continue;
            if (e.isApplicable(m)) e.setDamage(m, 0);
        }
    }
}
