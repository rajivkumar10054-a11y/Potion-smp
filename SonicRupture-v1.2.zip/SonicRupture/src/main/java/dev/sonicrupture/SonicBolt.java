package dev.sonicrupture;

import org.bukkit.World;
import org.bukkit.util.Vector;

import java.util.UUID;

/** One Sonic Boom projectile: TRAVELLING -> HIT / EXPIRED / CANCELLED. */
public final class SonicBolt {

    public enum State { TRAVELLING, HIT, EXPIRED, CANCELLED }

    private final UUID shooterId;
    private final World world;
    private final Vector position;
    private final Vector direction;
    private int age;
    private double travelled;
    private State state = State.TRAVELLING;

    SonicBolt(UUID shooterId, World world, Vector position, Vector direction) {
        this.shooterId = shooterId;
        this.world = world;
        this.position = position.clone();
        this.direction = direction.clone().normalize();
    }

    public UUID shooterId() { return shooterId; }
    public World world() { return world; }
    public Vector position() { return position; }
    public Vector direction() { return direction; }
    public int age() { return age; }
    public double travelled() { return travelled; }
    public State state() { return state; }

    void setState(State state) { this.state = state; }
    void tickAge() { age++; }
    void advance(double distance) {
        position.add(direction.clone().multiply(distance));
        travelled += distance;
    }
}
