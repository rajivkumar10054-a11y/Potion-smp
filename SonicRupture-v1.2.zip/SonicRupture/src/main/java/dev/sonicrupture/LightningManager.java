package dev.sonicrupture;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Shift + Right Click ability: 20 seconds (400 ticks), one cycle every 20 ticks.
 * Each cycle = 1 real strike (armor-ignoring damage to the nearest other player
 * within 5 blocks) + 3 visual-only strikes at random spots within 5 blocks.
 */
public final class LightningManager {

    public static final int DURATION_TICKS = 400;
    public static final int INTERVAL_TICKS = 20;
    public static final double RADIUS = 5.0;
    public static final int VISUAL_STRIKES = 3;
    private static final double MIN_SEPARATION = 1.5;

    private final SonicRupturePlugin plugin;
    private final Map<UUID, BukkitTask> active = new HashMap<>();
    private boolean applyingRealStrike;

    public LightningManager(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isActive(UUID id) {
        return active.containsKey(id);
    }

    /** True only while the real strike's damage call is on the stack. */
    public boolean isApplyingRealStrike() {
        return applyingRealStrike;
    }

    public void activate(Player owner) {
        UUID id = owner.getUniqueId();
        if (active.containsKey(id)) return; // no duplicate tasks

        int totalCycles = DURATION_TICKS / INTERVAL_TICKS;
        BukkitTask task = new BukkitRunnable() {
            int cycles = 0;

            @Override
            public void run() {
                Player p = Bukkit.getPlayer(id);
                if (p == null || !p.isOnline() || p.isDead()) {
                    stop(id);
                    return;
                }
                cycle(p);
                if (++cycles >= totalCycles) stop(id);
            }
        }.runTaskTimer(plugin, INTERVAL_TICKS, INTERVAL_TICKS);
        active.put(id, task);
    }

    public void stop(UUID id) {
        BukkitTask t = active.remove(id);
        if (t != null) t.cancel();
    }

    public void shutdown() {
        for (BukkitTask t : active.values()) t.cancel();
        active.clear();
    }

    private void cycle(Player owner) {
        World w = owner.getWorld();
        Location center = owner.getLocation();
        List<Location> placed = new ArrayList<>();

        // 1 real strike
        Player victim = findVictim(owner);
        if (victim != null) {
            Location vl = victim.getLocation();
            w.strikeLightningEffect(vl); // effect only: vanilla lightning damage/fire never happens
            double dmg = plugin.getConfig().getDouble("lightning.damage", 6.0);
            applyingRealStrike = true;   // CombatListener zeroes armor reduction for this call
            try {
                victim.damage(dmg);
            } finally {
                applyingRealStrike = false;
            }
            placed.add(vl);
        }

        // 3 visual-only strikes
        for (int i = 0; i < VISUAL_STRIKES; i++) {
            Location loc = null;
            for (int attempt = 0; attempt < 12; attempt++) {
                loc = randomPoint(w, center);
                if (farEnough(loc, placed)) break;
            }
            placed.add(loc);
            w.strikeLightningEffect(loc);
        }
    }

    private Player findVictim(Player owner) {
        Location oc = owner.getLocation();
        Player best = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : owner.getNearbyEntities(RADIUS, RADIUS, RADIUS)) {
            if (!(e instanceof Player t)) continue;
            if (t.isDead() || t.getGameMode() == GameMode.SPECTATOR || t.getGameMode() == GameMode.CREATIVE) continue;
            double d = t.getLocation().distanceSquared(oc);
            if (d > RADIUS * RADIUS) continue;
            if (d < bestD) {
                bestD = d;
                best = t;
            }
        }
        return best;
    }

    private Location randomPoint(World w, Location center) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double angle = r.nextDouble(Math.PI * 2);
        double dist = RADIUS * Math.sqrt(r.nextDouble()); // uniform over the disc
        double x = center.getX() + Math.cos(angle) * dist;
        double z = center.getZ() + Math.sin(angle) * dist;
        int gy = w.getHighestBlockYAt((int) Math.floor(x), (int) Math.floor(z));
        double y = Math.abs(gy - center.getY()) <= 4 ? gy + 1 : center.getY();
        return new Location(w, x, y, z);
    }

    private boolean farEnough(Location loc, List<Location> placed) {
        for (Location o : placed) {
            double dx = o.getX() - loc.getX();
            double dz = o.getZ() - loc.getZ();
            if (dx * dx + dz * dz < MIN_SEPARATION * MIN_SEPARATION) return false;
        }
        return true;
    }
}
