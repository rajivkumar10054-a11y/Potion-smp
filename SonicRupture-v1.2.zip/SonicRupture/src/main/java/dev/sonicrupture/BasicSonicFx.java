package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Phase 1: Warden sounds and an action-bar charge meter only. No particles or block effects. */
public final class BasicSonicFx implements SonicFx {

    private static final int BAR = 20;
    private final SonicRupturePlugin plugin;

    public BasicSonicFx(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onChargeStart(Player p) {
        if (!plugin.cfg().sounds()) return;
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.PLAYERS, 2f, 1f);
    }

    @Override
    public void onChargeTick(Player p, int elapsed, int total) {
        int filled = (int) Math.round((double) BAR * elapsed / total);
        p.sendActionBar(Component.text("█".repeat(filled), NamedTextColor.AQUA)
                .append(Component.text("█".repeat(BAR - filled), NamedTextColor.DARK_GRAY)));
    }

    @Override
    public void onChargeCancel(Player p) {
        p.sendActionBar(Component.empty());
        Location loc = p.getLocation();
        for (Player near : loc.getNearbyPlayers(48)) {
            near.stopSound(Sound.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.PLAYERS);
        }
    }

    @Override
    public void onRelease(Player p, Location origin, Vector direction) {
        p.sendActionBar(Component.empty());
        if (!plugin.cfg().sounds()) return;
        origin.getWorld().playSound(origin, Sound.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3f, 1f);
    }
}
