package dev.sonicrupture;

import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Presentation layer. The core ability only calls these hooks, so Phase 2
 * visuals (block scatter, trails, impact VFX) can be added by implementing
 * this interface and calling {@link SonicRupturePlugin#setFx(SonicFx)}.
 */
public interface SonicFx {
    default void onChargeStart(Player player) {}
    default void onChargeTick(Player player, int elapsed, int total) {}
    default void onChargeCancel(Player player) {}
    default void onRelease(Player player, Location origin, Vector direction) {}
    default void onProjectileTick(SonicBolt bolt, Location position) {}
    default void onHit(SonicBolt bolt, LivingEntity target, Location position) {}
    default void onExpire(SonicBolt bolt, Location position) {}
}
