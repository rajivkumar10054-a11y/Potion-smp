package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.ProgrammaticDamageGuard;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Handles Regen Potion's active ability (Vitality Surge).
 * The activation trigger is owned by RegenAbility (Shift + the trigger of
 * the slot containing Regen); this manager only handles the existing surge
 * state, launch, effects, cooldown window, and Mace Dive charge.
 */
public class RegenAbilityManager {

    private final PotionSMP plugin;

    // Players currently airborne+charged for a bonus Mace Dive hit
    private final Set<UUID> chargedForDive = new HashSet<>();

    // Players inside their shared Surge window: opened by the FIRST valid
    // activation and open for durationTicks (10s by default), during which
    // up to MAX_ACTIVATIONS presses are allowed. Closes automatically once
    // the window's duration elapses; activations #2/#3 never extend it.
    private final Set<UUID> windowActive = new HashSet<>();

    // Activations already spent in the current window (0..MAX_ACTIVATIONS).
    private final Map<UUID, Integer> activationCount = new HashMap<>();

    // Server tick of the last ACCEPTED activation, purely to stop a single
    // held/macro-spammed press from being read as several activations in
    // the same instant. Far below the multi-second gaps between presses in
    // the spec's own example, so normal spaced-out presses are unaffected.
    private final Map<UUID, Integer> lastActivationTick = new HashMap<>();
    private static final int MAX_ACTIVATIONS = 3;
    private static final int ACTIVATION_DEBOUNCE_TICKS = 4;

    // One scheduled task per player for the window's own lifetime, so
    // cleanup can cancel it and it can never be duplicated.
    private final Map<UUID, BukkitTask> windowTasks = new HashMap<>();

    public RegenAbilityManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isWindowActive(UUID uuid) {
        return windowActive.contains(uuid);
    }

    /**
     * Opens the shared window for durationTicks, starting the activation
     * count at 1. Called once, by tryConsumeActivation, on the first valid
     * press of a new window — never on activation #2 or #3, so the window
     * is never extended or reopened mid-window.
     *
     * At natural expiration this also resets the activation count (so a
     * later fresh press starts a brand-new window at count 1) and plays
     * the cosmetic end-of-window collapse animation exactly once. No
     * launch is ever scheduled here — only this cleanup — so nothing can
     * fire after the window has ended.
     */
    private void openWindow(UUID uuid, int durationTicks) {
        windowActive.add(uuid);
        activationCount.put(uuid, 1);
        BukkitTask previous = windowTasks.remove(uuid);
        if (previous != null) previous.cancel();
        windowTasks.put(uuid, plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            windowTasks.remove(uuid);
            windowActive.remove(uuid);
            activationCount.remove(uuid);
            lastActivationTick.remove(uuid);
            Player player = plugin.getServer().getPlayer(uuid);
            if (player != null && player.isOnline()) {
                plugin.getVitalityParticleRenderer().playEndAnimation(player);
            }
        }, durationTicks));
    }

    /**
     * Consumes one activation of the player's Vitality Surge window,
     * opening a fresh window (and starting its count at 1) if none is
     * currently open. Returns false — activation ignored — when the
     * window's 3 uses are already spent, or when this press arrives within
     * the anti-spam debounce of the last accepted one.
     */
    public boolean tryConsumeActivation(Player player, int windowDurationTicks) {
        UUID uid = player.getUniqueId();
        int now = plugin.getServer().getCurrentTick();

        Integer last = lastActivationTick.get(uid);
        if (last != null && now - last < ACTIVATION_DEBOUNCE_TICKS) return false;

        if (!windowActive.contains(uid)) {
            openWindow(uid, windowDurationTicks);
            lastActivationTick.put(uid, now);
            return true;
        }

        int count = activationCount.getOrDefault(uid, 0);
        if (count >= MAX_ACTIVATIONS) return false;

        activationCount.put(uid, count + 1);
        lastActivationTick.put(uid, now);
        return true;
    }

    /** Cleanup — e.g. on unequip, death, or quit. */
    public void closeWindow(UUID uuid) {
        windowActive.remove(uuid);
        activationCount.remove(uuid);
        lastActivationTick.remove(uuid);
        BukkitTask window = windowTasks.remove(uuid);
        if (window != null) window.cancel();
    }

    /**
     * Clears all short-lived Vitality Surge state for lifecycle events such as
     * death or disconnect. Equipped potion slots remain untouched, so the
     * normal passive can still be reapplied after respawn/reconnect.
     */
    public void clearTransient(UUID uuid) {
        chargedForDive.remove(uuid);
        closeWindow(uuid);
    }

    public boolean isChargedForDive(UUID uuid) {
        return chargedForDive.contains(uuid);
    }

    public void clearCharge(UUID uuid) {
        chargedForDive.remove(uuid);
    }

    /**
     * Performs the launch/jump + regen/glow effects. RegenAbility calls this
     * once per accepted activation (up to 3 times per shared window); the
     * window itself is opened separately, by tryConsumeActivation, so a
     * 2nd/3rd launch here never opens or extends it.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier) {
        UUID uid = player.getUniqueId();

        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));

        chargedForDive.add(uid);

        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, durationTicks, regenAmplifier, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationTicks, 0, false, false));

        Location loc = player.getLocation();
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 1f, 1.2f);

        runLandingWatcher(player);
    }

    private void runLandingWatcher(Player player) {
        UUID uid = player.getUniqueId();
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks > 200) {
                    cancel();
                    return;
                }
                if (player.isOnGround() && ticks > 2) {
                    chargedForDive.remove(uid);
                    cancel();
                    return;
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ── Mace Dive damage: vanilla 1.21.11 Mace smash-attack calculation ──
    // Vanilla Mace hit = 6.0 base attack damage + smash bonus from the
    // attacker's fall distance. The bonus applies only when fallDistance is
    // greater than 1.5 and the attacker is not gliding (vanilla
    // MaceItem#canSmashAttack), and has no upper cap:
    //   fall <= 3        : 4 * fall
    //   3 < fall <= 8    : 12 + 2 * (fall - 3)      (= 2*fall + 6)
    //   fall > 8         : 22 + (fall - 8)          (= fall + 14)
    // Density (an enchantment on the Mace item) does not apply: there is no
    // Mace item here. Critical-hit multiplication is not part of the smash
    // calculation and is not applied.
    private static final double MACE_BASE_DAMAGE = 6.0;
    private static final double SMASH_MIN_FALL   = 1.5;

    /**
     * Damage for the already-selected Mace Dive target, from the player's
     * actual fall distance. Paper's getFallDistance() is the same
     * fallDistance field vanilla's Mace reads: it only accumulates while the
     * player moves DOWN and is reset on ground contact, so the upward launch
     * is never counted, only the descent from the apex to the impact.
     */
    public double calculateMaceDiveDamage(Player player) {
        return MACE_BASE_DAMAGE + smashBonus(player.getFallDistance(), player.isGliding());
    }

    private static double smashBonus(double fallDistance, boolean gliding) {
        if (gliding || fallDistance <= SMASH_MIN_FALL) return 0.0;
        if (fallDistance <= 3.0) return 4.0 * fallDistance;
        if (fallDistance <= 8.0) return 12.0 + 2.0 * (fallDistance - 3.0);
        return 22.0 + (fallDistance - 8.0);
    }

    public void triggerMaceDive(Player player, LivingEntity target, double diveDamage) {
        UUID uid = player.getUniqueId();
        chargedForDive.remove(uid);

        ProgrammaticDamageGuard.beginSuppression(uid);
        try {
            target.damage(diveDamage, player);
        } finally {
            ProgrammaticDamageGuard.endSuppression(uid);
        }

        Location loc = target.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 1, 0), 25, 0.6, 0.6, 0.6, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 30, 0.6, 0.4, 0.6, 0.3);

        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI * i) / 30;
            double x = loc.getX() + 1.5 * Math.cos(angle);
            double z = loc.getZ() + 1.5 * Math.sin(angle);
            loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, x, loc.getY() + 0.1, z, 1, 0, 0, 0, 0);
        }

        loc.getWorld().playSound(loc, Sound.ITEM_MACE_SMASH_GROUND, 1.2f, 1f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 0.5f);
    }
}
