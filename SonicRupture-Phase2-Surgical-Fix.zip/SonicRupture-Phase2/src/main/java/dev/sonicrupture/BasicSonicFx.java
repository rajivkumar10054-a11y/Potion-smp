package dev.sonicrupture;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Phase 2 presentation layer.
 *
 * This class never changes blocks, entities, damage, movement, or projectile
 * state. It only renders particles/sounds from the existing SonicFx lifecycle.
 */
public final class BasicSonicFx implements SonicFx {

    private static final int BAR = 20;

    private final SonicRupturePlugin plugin;
    private final Map<SonicBolt, VisualState> states = new HashMap<>();

    private static final class VisualState {
        final Set<String> displayedBlocks = new HashSet<>();
        int particleEffectsThisTick;

        void resetTickBudget() {
            particleEffectsThisTick = 0;
        }
    }

    public BasicSonicFx(SonicRupturePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onChargeStart(Player p) {
        ConfigManager cfg = plugin.cfg();
        if (cfg.fxChargeEnabled()) {
            spawnParticle(p.getLocation().add(0, 1.0, 0), cfg.fxChargeParticle(),
                    cfg.fxChargeParticleCount(), cfg.fxChargeRadius(), cfg.fxChargeRadius(),
                    cfg.fxChargeRadius(), 0.01f);
        }

        if (cfg.sounds()) {
            playSound(p.getLocation(), cfg.fxChargeSound(),
                    cfg.fxChargeSoundVolume(), cfg.fxChargeSoundPitch());
        }
    }

    @Override
    public void onChargeTick(Player p, int elapsed, int total) {
        int filled = (int) Math.round((double) BAR * elapsed / total);
        p.sendActionBar(Component.text("█".repeat(filled), NamedTextColor.AQUA)
                .append(Component.text("█".repeat(BAR - filled), NamedTextColor.DARK_GRAY)));

        ConfigManager cfg = plugin.cfg();
        if (!cfg.fxChargeEnabled()) return;

        double progress = Math.min(1.0, Math.max(0.0, (double) elapsed / Math.max(1, total)));
        int count = (int) Math.round(
                cfg.fxChargeParticleCount()
                        + (cfg.fxChargeMaxParticleCount() - cfg.fxChargeParticleCount()) * progress);
        double radius = cfg.fxChargeRadius()
                + (cfg.fxChargeMaxRadius() - cfg.fxChargeRadius()) * progress;

        Location center = p.getLocation().add(0, 1.0, 0);
        spawnParticle(center, cfg.fxChargeParticle(), count, radius, radius, radius, 0.01f);

        // A light pulse near the end makes completion visually readable without
        // changing the existing charge timing.
        if (elapsed == total) {
            spawnParticle(center, "SONIC_BOOM", 1, 0, 0, 0, 0);
        }
    }

    @Override
    public void onChargeCancel(Player p) {
        p.sendActionBar(Component.empty());
        Location loc = p.getLocation();
        for (Player near : loc.getNearbyPlayers(48)) {
            near.stopSound(Sound.ENTITY_WARDEN_SONIC_CHARGE, SoundCategory.PLAYERS);
        }
    }

    @Override
    public void onRelease(Player p, Location origin, Vector direction) {
        p.sendActionBar(Component.empty());

        ConfigManager cfg = plugin.cfg();
        if (cfg.fxTravelEnabled()) {
            spawnParticle(origin, cfg.fxTravelParticle(), cfg.fxTravelParticleCount(),
                    0, 0, 0, 0);
        }

        // Preserve the Phase 1 release sound.
        if (cfg.sounds()) {
            origin.getWorld().playSound(origin, Sound.ENTITY_WARDEN_SONIC_BOOM,
                    SoundCategory.PLAYERS, 3f, 1f);
        }
    }

    @Override
    public void onProjectileTick(SonicBolt bolt, Location position) {
        ConfigManager cfg = plugin.cfg();
        VisualState state = states.computeIfAbsent(bolt, ignored -> new VisualState());
        state.resetTickBudget();

        // Exact movement segment supplied by SonicBolt: previous -> current.
        Location previous = bolt.previousPosition().toLocation(bolt.world());
        if (cfg.fxTravelEnabled()) {
            spawnParticleLimited(state, position, cfg.fxTravelParticle(),
                    cfg.fxTravelParticleCount(), 0, 0, 0, 0);
        }

        if (cfg.fxBlockScatterEnabled() && state.displayedBlocks.size() < cfg.fxScatterMaxBlocks()) {
            scatterAlongSegment(bolt, previous, position, state);
        }
    }

    @Override
    public void onHit(SonicBolt bolt, LivingEntity target, Location position) {
        ConfigManager cfg = plugin.cfg();

        if (cfg.fxImpactEnabled()) {
            spawnParticle(position, cfg.fxImpactParticle(), cfg.fxImpactParticleCount(),
                    cfg.fxImpactOffset(), cfg.fxImpactOffset(), cfg.fxImpactOffset(),
                    cfg.fxImpactSpeed());
            if (cfg.sounds()) {
                playSound(position, cfg.fxImpactSound(),
                        cfg.fxImpactSoundVolume(), cfg.fxImpactSoundPitch());
            }
        }

        states.remove(bolt);
    }

    @Override
    public void onExpire(SonicBolt bolt, Location position) {
        states.remove(bolt);
    }

    @Override
    public void onCancel(SonicBolt bolt, Location position) {
        states.remove(bolt);
    }

    private void scatterAlongSegment(SonicBolt bolt, Location from, Location to, VisualState state) {
        ConfigManager cfg = plugin.cfg();

        Vector delta = to.toVector().subtract(from.toVector());
        double length = delta.length();
        int samples = Math.max(1, (int) Math.ceil(length / Math.max(1, cfg.fxScatterSampleSpacing())));

        int effectsLeft = cfg.fxMaxParticlesPerTick() - state.particleEffectsThisTick;
        if (effectsLeft <= 0) return;

        for (int sample = 0; sample <= samples; sample++) {
            if (state.displayedBlocks.size() >= cfg.fxScatterMaxBlocks() || effectsLeft <= 0) return;

            double t = samples == 0 ? 0 : (double) sample / samples;
            Location center = from.clone().add(delta.clone().multiply(t));

            int radius = (int) Math.ceil(cfg.fxScatterRadius());
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        if (state.displayedBlocks.size() >= cfg.fxScatterMaxBlocks() || effectsLeft <= 0) return;
                        if (!candidateAllowed(dx, dy, dz, center, bolt.direction(), cfg.fxScatterRadius(),
                                cfg.fxScatterPattern())) continue;

                        Block block = center.getWorld().getBlockAt(
                                center.getBlockX() + dx,
                                center.getBlockY() + dy,
                                center.getBlockZ() + dz);

                        if (!eligible(block, cfg) || !state.displayedBlocks.add(blockKey(block))) continue;

                        BlockData data = block.getBlockData();
                        block.getWorld().spawnParticle(
                                Particle.BLOCK_CRACK,
                                block.getLocation().add(0.5, 0.5, 0.5),
                                cfg.fxScatterParticleCount(),
                                cfg.fxScatterOffset(),
                                cfg.fxScatterOffset(),
                                cfg.fxScatterOffset(),
                                cfg.fxScatterSpeed(),
                                data);
                        state.particleEffectsThisTick++;
                        effectsLeft--;

                        if (cfg.sounds()) {
                            playSound(block.getLocation().add(0.5, 0.5, 0.5),
                                    cfg.fxScatterSound(),
                                    cfg.fxScatterSoundVolume(),
                                    cfg.fxScatterSoundPitch());
                        }
                    }
                }
            }
        }
    }

    private boolean candidateAllowed(int dx, int dy, int dz, Location center, Vector direction,
                                     double radius, String pattern) {
        double distanceSquared = dx * dx + dy * dy + dz * dz;
        if (distanceSquared > radius * radius + 1.0E-6) return false;

        if (pattern.equals("random")) {
            return ThreadLocalRandom.current().nextDouble() <= 0.55;
        }

        if (pattern.equals("cone")) {
            Vector offset = new Vector(dx, dy, dz);
            if (offset.lengthSquared() < 1.0E-6) return true;
            // A forward-biased cone around the actual SonicBolt direction.
            double dot = offset.normalize().dot(direction.clone().normalize());
            return dot >= 0.0;
        }

        // line = full spherical sample around the real movement path.
        return true;
    }

    private boolean eligible(Block block, ConfigManager cfg) {
        Material type = block.getType();
        if (type.isAir() || !type.isSolid()) return false;

        String name = type.name();
        if (containsMaterial(cfg.fxScatterSkipBlocks(), name)) return false;

        return switch (cfg.fxScatterMode()) {
            case "custom" -> containsMaterial(cfg.fxScatterCustomBlocks(), name);
            case "natural" -> isNatural(type);
            default -> true;
        };
    }

    private boolean isNatural(Material type) {
        String n = type.name();

        // Conservative material-name classification: terrain, ores, vegetation,
        // logs/leaves, ice, clay and common natural stone/sand families.
        return n.contains("STONE") || n.contains("DEEPSLATE") || n.contains("ORE")
                || n.contains("DIRT") || n.contains("GRASS_BLOCK")
                || n.contains("SAND") || n.contains("GRAVEL")
                || n.contains("CLAY") || n.contains("TERRACOTTA")
                || n.contains("LOG") || n.contains("WOOD")
                || n.contains("LEAVES") || n.contains("MOSS")
                || n.contains("ICE") || n.equals("SNOW_BLOCK")
                || n.equals("NETHERRACK") || n.equals("SOUL_SAND")
                || n.equals("SOUL_SOIL") || n.equals("BASALT")
                || n.equals("BLACKSTONE") || n.equals("END_STONE")
                || n.equals("GLOWSTONE") || n.equals("CALCITE")
                || n.equals("TUFF") || n.equals("DRIPSTONE_BLOCK");
    }

    private boolean containsMaterial(Iterable<String> names, String materialName) {
        for (String raw : names) {
            if (raw != null && raw.trim().equalsIgnoreCase(materialName)) return true;
        }
        return false;
    }

    private String blockKey(Block block) {
        return block.getWorld().getUID() + ":" + block.getX() + ":"
                + block.getY() + ":" + block.getZ();
    }

    private void spawnParticle(Location location, String particleName, int count,
                               double ox, double oy, double oz, double speed) {
        if (count <= 0) return;
        Particle particle = particle(particleName);
        if (particle == null || location.getWorld() == null) return;
        location.getWorld().spawnParticle(particle, location, count, ox, oy, oz, speed);
    }

    private void spawnParticleLimited(VisualState state, Location location, String particleName,
                                      int count, double ox, double oy, double oz, double speed) {
        ConfigManager cfg = plugin.cfg();
        int allowed = Math.min(count, Math.max(0, cfg.fxMaxParticlesPerTick() - state.particleEffectsThisTick));
        if (allowed <= 0) return;
        spawnParticle(location, particleName, allowed, ox, oy, oz, speed);
        state.particleEffectsThisTick++;
    }

    private Particle particle(String name) {
        try {
            return Particle.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private void playSound(Location location, String soundName, float volume, float pitch) {
        try {
            Sound sound = Sound.valueOf(soundName.trim().toUpperCase(Locale.ROOT));
            location.getWorld().playSound(location, sound, SoundCategory.PLAYERS, volume, pitch);
        } catch (IllegalArgumentException ignored) {
            // Invalid configurable FX sound is ignored; gameplay is unaffected.
        }
    }
}
